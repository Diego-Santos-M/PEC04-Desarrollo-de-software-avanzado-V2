from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator, MinValueValidator


class TipoUsuario(models.Model):
	nombre = models.CharField(max_length=30, unique=True)

	class Meta:
		db_table = 'Tipos_usuarios'
		verbose_name = 'Tipo de usuario'
		verbose_name_plural = 'Tipos de usuario'

	def __str__(self):
		return self.nombre


class Grado(models.Model):
	nombre = models.CharField(max_length=120)

	class Meta:
		db_table = 'Grados'

	def __str__(self):
		return self.nombre


class Asignatura(models.Model):
	class TiposAsignatura(models.TextChoices):
		BASICA = 'B', 'B'
		OBLIGATORIA = 'OB', 'OB'
		OPTATIVA = 'OP', 'OP'
		TFG = 'TFG', 'TFG'

	nombre = models.CharField(max_length=120)
	tipo_asignatura = models.CharField(max_length=3, choices=TiposAsignatura.choices)

	class Meta:
		db_table = 'Asignaturas'

	def __str__(self):
		return self.nombre


class GradoAsignatura(models.Model):
	class Especialidades(models.TextChoices):
		INGENIERIA_SOFTWARE = 'IS', 'Ingeniería del Software'
		TECNOLOGIAS_INFORMACION = 'TI', 'Tecnologías de la Información'

	class Cuatrimestres(models.TextChoices):
		PRIMERO = '1', '1º'
		SEGUNDO = '2', '2º'

	grado = models.ForeignKey(Grado, on_delete=models.CASCADE, db_column='ID_Grado')
	asignatura = models.ForeignKey(Asignatura, on_delete=models.CASCADE, db_column='ID_Asignatura')
	especialidad = models.CharField(max_length=2, choices=Especialidades.choices, null=True, blank=True, db_column='Especialidad')
	anio = models.PositiveSmallIntegerField(
		default=1,
		db_column='Anio',
		validators=[MinValueValidator(1), MaxValueValidator(5)],
	)
	cuatrimestre = models.CharField(max_length=1, choices=Cuatrimestres.choices, default=Cuatrimestres.PRIMERO, db_column='Cuatrimestre')

	class Meta:
		db_table = 'Grado_Asignatura'
		unique_together = ('grado', 'asignatura')

	def clean(self):
		es_op = self.asignatura and self.asignatura.tipo_asignatura == Asignatura.TiposAsignatura.OPTATIVA
		es_grado_informatica = self.grado and self.grado.nombre.strip().lower() == 'ingeniería informática'

		if es_op and es_grado_informatica and not self.especialidad:
			raise ValidationError('Para asignaturas OP en Ingeniería Informática debes indicar la especialidad.')

		if not (es_op and es_grado_informatica):
			self.especialidad = None

	def __str__(self):
		return f'{self.grado} - {self.asignatura}'


class Profesor(models.Model):
	id = models.BigAutoField(primary_key=True)
	dni = models.CharField(max_length=12, unique=True, blank=True, db_column='DNI')
	nombre = models.CharField(max_length=120, db_column='Nombre')
	contrato_hasta = models.DateField(db_column='Contrato_hasta', null=True, blank=True)
	contrato_indefinido = models.BooleanField(default=False, db_column='Contrato_indefinido')

	class Meta:
		db_table = 'profesores'

	def clean(self):
		if self.contrato_indefinido:
			self.contrato_hasta = None
		elif not self.contrato_hasta:
			raise ValidationError('Debes indicar una fecha de contrato o marcar indefinido.')

	def save(self, *args, **kwargs):
		if not self.dni:
			dnies = Profesor.objects.exclude(dni='').values_list('dni', flat=True)
			numericos = [int(d) for d in dnies if d.isdigit()]
			siguiente = max(numericos, default=0) + 1
			self.dni = str(siguiente)
		super().save(*args, **kwargs)

	def __str__(self):
		return self.nombre


class AsignaturaProfesor(models.Model):
	dni = models.ForeignKey(Profesor, on_delete=models.CASCADE, db_column='Dni', to_field='dni')
	asignatura = models.ForeignKey(Asignatura, on_delete=models.CASCADE, db_column='ID_Asignatura')
	grado = models.ForeignKey(Grado, on_delete=models.SET_NULL, null=True, blank=True, db_column='ID_Grado')
	coincide_con_grado_relacionado = models.BooleanField(default=False, db_column='Coincide_con_grado_relacionado')
	grado_coincidente = models.ForeignKey(
		Grado,
		on_delete=models.SET_NULL,
		null=True,
		blank=True,
		related_name='asignatura_profesor_grado_coincidente',
		db_column='ID_Grado_coincidente',
	)

	class Meta:
		db_table = 'Asignaturas_Profesor'
		unique_together = ('dni', 'asignatura', 'grado')

	def clean(self):
		if not self.asignatura_id:
			return

		grados_asignatura = GradoAsignatura.objects.filter(asignatura_id=self.asignatura_id).values_list('grado_id', flat=True).distinct()
		total_grados = grados_asignatura.count()
		relaciones = AsignaturaProfesor.objects.filter(asignatura_id=self.asignatura_id)
		if self.pk:
			relaciones = relaciones.exclude(pk=self.pk)

		if total_grados <= 1 and relaciones.exists():
			raise ValidationError('Esta asignatura solo puede tener un profesor porque no pertenece a varios grados.')

		if total_grados > 1:
			if not self.grado_id:
				raise ValidationError('Debes indicar el grado para asignaturas que pertenecen a varios grados.')
			if self.grado_id not in grados_asignatura:
				raise ValidationError('El grado elegido no está asociado a esta asignatura.')

			relaciones_grado = relaciones.filter(grado_id=self.grado_id)
			if relaciones_grado.exists():
				raise ValidationError('Esta asignatura ya tiene profesor asignado para el grado seleccionado.')
		else:
			self.grado_id = grados_asignatura.first()

		es_doble_grado = self.grado and '+' in self.grado.nombre
		if es_doble_grado:
			if self.coincide_con_grado_relacionado:
				if not self.grado_coincidente_id:
					raise ValidationError('Debes indicar con qué grado coincide esta asignatura dentro del doble grado.')
				grados_relacionados = GradoAsignatura.objects.filter(asignatura_id=self.asignatura_id).exclude(grado_id=self.grado_id).values_list('grado_id', flat=True)
				if self.grado_coincidente_id not in grados_relacionados:
					raise ValidationError('El grado coincidente no está relacionado con la asignatura seleccionada.')
			else:
				self.grado_coincidente = None
		else:
			self.coincide_con_grado_relacionado = False
			self.grado_coincidente = None

	def __str__(self):
		if self.grado:
			return f'{self.dni} - {self.asignatura} ({self.grado})'
		return f'{self.dni} - {self.asignatura}'


class AusenciaProfesor(models.Model):
	class DiasSemana(models.TextChoices):
		LUNES = 'LUNES', 'Lunes'
		MARTES = 'MARTES', 'Martes'
		MIERCOLES = 'MIERCOLES', 'Miércoles'
		JUEVES = 'JUEVES', 'Jueves'
		VIERNES = 'VIERNES', 'Viernes'
		SABADO = 'SABADO', 'Sábado'
		DOMINGO = 'DOMINGO', 'Domingo'

	class Turnos(models.TextChoices):
		MANANA = 'MANANA', 'Mañana (9:00-15:00)'
		TARDE = 'TARDE', 'Tarde (15:30-21:30)'
		TODO_EL_DIA = 'TODO_EL_DIA', 'Todo el día'
		PERSONALIZADO = 'PERSONALIZADO', 'Personalizado'

	class HorasPredefinidas(models.TextChoices):
		# Mañana
		H09_11 = '09:00-11:00', '09:00 - 11:00'
		H11_13 = '11:00-13:00', '11:00 - 13:00'
		H13_15 = '13:00-15:00', '13:00 - 15:00'
		# Tarde
		H1530_1730 = '15:30-17:30', '15:30 - 17:30'
		H1730_1930 = '17:30-19:30', '17:30 - 19:30'
		H1930_2130 = '19:30-21:30', '19:30 - 21:30'

	class EstadoAusencia(models.TextChoices):
		PENDIENTE = 'PENDIENTE', 'Por decidir'
		APROBADA = 'APROBADA', 'Aprobada'
		RECHAZADA = 'RECHAZADA', 'Rechazada'

	class DuracionAusencia(models.TextChoices):
		PRIMER_CUATRIMESTRE = '1', '1º Cuatrimestre'
		SEGUNDO_CUATRIMESTRE = '2', '2º Cuatrimestre'
		TODO_EL_ANO = 'TODO', 'Todo el año'

	profesor = models.ForeignKey(Profesor, on_delete=models.CASCADE, db_column='ID_Profesor', related_name='ausencias')
	dia_de_la_semana = models.CharField(max_length=10, choices=DiasSemana.choices, db_column='Dia_de_la_semana')
	turno = models.CharField(max_length=20, choices=Turnos.choices, default=Turnos.PERSONALIZADO, db_column='Turno')
	hora_inicio = models.TimeField(db_column='Hora_inicio', null=True, blank=True)
	hora_fin = models.TimeField(db_column='Hora_fin', null=True, blank=True)
	creada_en = models.DateTimeField(auto_now_add=True, null=True, blank=True, db_column='Creada_en')
	estado = models.CharField(max_length=10, choices=EstadoAusencia.choices, default=EstadoAusencia.PENDIENTE, db_column='Estado')
	duracion_cuatrimestre = models.CharField(max_length=4, choices=DuracionAusencia.choices, default=DuracionAusencia.TODO_EL_ANO, db_column='Duracion_cuatrimestre')

	class Meta:
		db_table = 'Ausencia_profesor'
		ordering = ['dia_de_la_semana', 'hora_inicio']

	def get_horas_predefinidas_disponibles(self):
		"""Retorna opciones de horas según el turno."""
		if self.turno == self.Turnos.MANANA:
			return [(k, v) for k, v in self.HorasPredefinidas.choices if '09' in k or '11' in k or '13' in k]
		elif self.turno == self.Turnos.TARDE:
			return [(k, v) for k, v in self.HorasPredefinidas.choices if '15' in k or '17' in k or '19' in k]
		return []

	def clean(self):
		if self.turno != self.Turnos.PERSONALIZADO:
			self.hora_inicio = None
			self.hora_fin = None
		else:
			if not self.hora_inicio or not self.hora_fin:
				raise ValidationError('Debes indicar horas de inicio y fin para ausencia personalizada.')
			if self.hora_fin <= self.hora_inicio:
				raise ValidationError('La hora de fin debe ser posterior a la hora de inicio.')

	def get_horario_display(self):
		"""Devuelve una representación legible del horario de ausencia."""
		if self.turno == self.Turnos.MANANA:
			return '09:00 - 15:00 (Mañana)'
		elif self.turno == self.Turnos.TARDE:
			return '15:30 - 21:30 (Tarde)'
		elif self.turno == self.Turnos.TODO_EL_DIA:
			return 'Todo el día'
		else:
			return f'{self.hora_inicio.strftime("%H:%M")} - {self.hora_fin.strftime("%H:%M")} (Personalizado)' if self.hora_inicio and self.hora_fin else 'Sin especificar'

	def es_aprobada(self):
		return self.estado == self.EstadoAusencia.APROBADA

	def get_rango_horario(self):
		if self.turno == self.Turnos.MANANA:
			return (self._time(9, 0), self._time(15, 0))
		if self.turno == self.Turnos.TARDE:
			return (self._time(15, 30), self._time(21, 30))
		if self.turno == self.Turnos.TODO_EL_DIA:
			return None
		if self.hora_inicio and self.hora_fin:
			return (self.hora_inicio, self.hora_fin)
		return None

	def coincide_con_horario(self, hora_inicio, hora_fin, cuatrimestre=None):
		"""Verifica si la ausencia coincide con un horario.
		
		Args:
			hora_inicio: hora de inicio del horario
			hora_fin: hora de fin del horario
			cuatrimestre: cuatrimestre del horario ('1' o '2'). Si es None, se asume que aplica a todos.
		
		Returns:
			True si hay coincidencia en horario y cuatrimestre, False en caso contrario.
		"""
		# Verificar compatibilidad de cuatrimestres
		if cuatrimestre is not None and self.duracion_cuatrimestre != self.DuracionAusencia.TODO_EL_ANO:
			if str(cuatrimestre) != self.duracion_cuatrimestre:
				return False
		
		# Verificar coincidencia horaria
		rango = self.get_rango_horario()
		if rango is None:
			return True
		inicio_ausencia, fin_ausencia = rango
		return hora_inicio < fin_ausencia and hora_fin > inicio_ausencia

	@staticmethod
	def _time(hour, minute):
		from datetime import time
		return time(hour, minute)

	def __str__(self):
		return f'{self.profesor.nombre} - {self.get_dia_de_la_semana_display()} {self.get_horario_display()}'


class PerfilUsuario(models.Model):
	class CuatrimestresChoices(models.TextChoices):
		PRIMERO = '1', '1º'
		SEGUNDO = '2', '2º'

	usuario = models.OneToOneField(User, on_delete=models.CASCADE)
	tipo_usuario = models.ForeignKey(TipoUsuario, on_delete=models.PROTECT)
	profesor = models.ForeignKey(Profesor, on_delete=models.SET_NULL, null=True, blank=True, to_field='dni')
	forzar_cambio_contrasena = models.BooleanField(default=False)
	cuatrimestre_profesor_preferido = models.CharField(
		max_length=1,
		choices=CuatrimestresChoices.choices,
		default=CuatrimestresChoices.PRIMERO,
		null=True,
		blank=True
	)

	class Meta:
		db_table = 'Perfil_usuario'

	def __str__(self):
		return f'{self.usuario.username} - {self.tipo_usuario.nombre}'


class HorarioClase(models.Model):
	class DiasSemana(models.TextChoices):
		LUNES = 'LUNES', 'Lunes'
		MARTES = 'MARTES', 'Martes'
		MIERCOLES = 'MIERCOLES', 'Miércoles'
		JUEVES = 'JUEVES', 'Jueves'
		VIERNES = 'VIERNES', 'Viernes'
		SABADO = 'SABADO', 'Sábado'
		DOMINGO = 'DOMINGO', 'Domingo'

	grado = models.ForeignKey(Grado, on_delete=models.CASCADE)
	asignatura = models.ForeignKey(Asignatura, on_delete=models.CASCADE)
	grado_asignatura = models.ForeignKey(GradoAsignatura, on_delete=models.CASCADE, null=True, blank=True, related_name='horarios')
	profesor = models.ForeignKey(Profesor, on_delete=models.CASCADE, to_field='dni')
	dia_de_la_semana = models.CharField(max_length=10, choices=DiasSemana.choices)
	hora_inicio = models.TimeField()
	hora_fin = models.TimeField()
	aula = models.CharField(max_length=80, blank=True)
	lote_generacion = models.CharField(max_length=32, blank=True, default='', db_index=True)
	activo = models.BooleanField(default=True)

	class Meta:
		db_table = 'Horarios'
		ordering = ['dia_de_la_semana', 'hora_inicio']

	def clean(self):
		if self.hora_inicio and self.hora_fin and self.hora_fin <= self.hora_inicio:
			raise ValidationError('La hora de fin debe ser posterior a la hora de inicio.')
		if self.grado_id and self.asignatura_id and not self.grado_asignatura_id:
			try:
				self.grado_asignatura = GradoAsignatura.objects.get(grado=self.grado, asignatura=self.asignatura)
			except GradoAsignatura.DoesNotExist:
				raise ValidationError('No existe la relación grado-asignatura para este horario.')
		if self.dia_de_la_semana and self.hora_inicio and self.hora_fin:
			solapes = HorarioClase.objects.filter(
				dia_de_la_semana=self.dia_de_la_semana,
				hora_inicio__lt=self.hora_fin,
				hora_fin__gt=self.hora_inicio,
				activo=True,
			).exclude(pk=self.pk)

			if self.profesor_id and solapes.filter(profesor=self.profesor).exists():
				raise ValidationError('El profesor ya tiene una clase asignada en esa franja horaria.')

			if self.grado_id:
				if self.grado_asignatura_id:
					mismo_grupo = solapes.filter(
						grado=self.grado,
						grado_asignatura__anio=self.grado_asignatura.anio,
						grado_asignatura__cuatrimestre=self.grado_asignatura.cuatrimestre,
						activo=True,
					)
				else:
					mismo_grupo = solapes.filter(grado=self.grado, activo=True)

				if mismo_grupo.exists():
					raise ValidationError('Ya existe otra clase del mismo grupo en esa franja horaria.')
		if self.profesor_id and self.dia_de_la_semana and self.hora_inicio and self.hora_fin:
			ausencias = AusenciaProfesor.objects.filter(
				profesor=self.profesor,
				dia_de_la_semana=self.dia_de_la_semana,
				estado=AusenciaProfesor.EstadoAusencia.APROBADA,
			)
			# Obtener cuatrimestre del horario
			cuatrimestre = None
			if self.grado_asignatura:
				cuatrimestre = self.grado_asignatura.cuatrimestre
			
			for ausencia in ausencias:
				if ausencia.coincide_con_horario(self.hora_inicio, self.hora_fin, cuatrimestre):
					raise ValidationError(
						f'El profesor tiene una limitación aprobada el {ausencia.get_dia_de_la_semana_display()} '
						f'en {ausencia.get_horario_display()}.'
					)

	def save(self, *args, **kwargs):
		if self.grado_id and self.asignatura_id and not self.grado_asignatura_id:
			self.grado_asignatura = GradoAsignatura.objects.filter(grado=self.grado, asignatura=self.asignatura).first()
		super().save(*args, **kwargs)

	def __str__(self):
		return f'{self.asignatura.nombre} - {self.grado.nombre} ({self.get_dia_de_la_semana_display()})'


class SolicitudCambioProfesor(models.Model):
	class EstadoSolicitud(models.TextChoices):
		PENDIENTE = 'PENDIENTE', 'Pendiente'
		APROBADA = 'APROBADA', 'Aprobada'
		RECHAZADA = 'RECHAZADA', 'Rechazada'

	profesor = models.ForeignKey(Profesor, on_delete=models.CASCADE, to_field='dni')
	horario = models.ForeignKey(HorarioClase, on_delete=models.CASCADE)
	mensaje = models.TextField()
	estado = models.CharField(max_length=10, choices=EstadoSolicitud.choices, default=EstadoSolicitud.PENDIENTE)
	creada_en = models.DateTimeField(auto_now_add=True)

	class Meta:
		db_table = 'Solicitud_cambio_profesor'
		ordering = ['-creada_en']

	def __str__(self):
		return f'{self.profesor.dni} - {self.horario.id} - {self.estado}'
