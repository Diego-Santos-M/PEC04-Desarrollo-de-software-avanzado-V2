from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from collections import defaultdict

COLORES_ASIGNATURAS = [
    'FBE7EA',  # Rosa pálido
    'E8F2FD',  # Azul pálido
    'E9F8EF',  # Verde pálido
    'FFF4E8',  # Naranja pálido
    'F1ECFF',  # Púrpura pálido
    'E9F7F7',  # Cian pálido
    'FFF0F2',  # Rosa más oscuro
    'EEF5E7',  # Verde más oscuro
]

def hash_subject(subject):
    """Genera un hash para determinar el color de una asignatura."""
    hash_val = 0
    for char in subject.lower():
        hash_val = ((hash_val << 5) - hash_val) + ord(char)
        hash_val |= 0
    return abs(hash_val)

def get_color_for_subject(subject):
    """Retorna el color hexadecimal para una asignatura."""
    idx = hash_subject(subject) % len(COLORES_ASIGNATURAS)
    return COLORES_ASIGNATURAS[idx]

def crear_excel_lote(lote_id, horarios_data):
    """Crea un Excel con los horarios de un lote.
    
    Args:
        lote_id: ID del lote
        horarios_data: {
            'grado': 'Nombre Grado',
            'anio': 1,
            'cuatrimestre': '1',
            'horarios': [HorarioClase objects]
        }
    """
    wb = Workbook()
    ws = wb.active
    ws.title = 'Horarios'
    
    # Encabezado
    ws['A1'] = f"Lote: {lote_id}"
    ws['A1'].font = Font(bold=True, size=12)
    ws['A2'] = f"Grado: {horarios_data['grado']}"
    ws['A3'] = f"Año: {horarios_data['anio']}º - Cuatrimestre: {horarios_data['cuatrimestre']}"
    
    # Crear matriz de horarios
    dias = ['LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES']
    horas_set = set()
    
    for h in horarios_data['horarios']:
        horas_set.add((h.hora_inicio, h.hora_fin))
    
    horas_sorted = sorted(horas_set)
    
    # Encabezados de tabla
    ws['A5'] = 'HORA'
    ws['A5'].font = Font(bold=True)
    ws['A5'].fill = PatternFill(start_color='F4ECE6', end_color='F4ECE6', fill_type='solid')
    
    for col_idx, dia in enumerate(dias, start=2):
        col = get_column_letter(col_idx)
        ws[f'{col}5'] = dia
        ws[f'{col}5'].font = Font(bold=True)
        ws[f'{col}5'].fill = PatternFill(start_color='F4ECE6', end_color='F4ECE6', fill_type='solid')
    
    # Datos de horarios
    for row_idx, (hora_inicio, hora_fin) in enumerate(horas_sorted, start=6):
        ws[f'A{row_idx}'] = f'{hora_inicio} - {hora_fin}'
        ws[f'A{row_idx}'].font = Font(bold=True)
        
        for col_idx, dia in enumerate(dias, start=2):
            col = get_column_letter(col_idx)
            cell = ws[f'{col}{row_idx}']
            
            # Buscar TODOS los horarios para este dia y hora
            horarios_encontrados = []
            for h in horarios_data['horarios']:
                if h.dia_de_la_semana == dia and h.hora_inicio == hora_inicio and h.hora_fin == hora_fin:
                    horarios_encontrados.append(h)
            
            if horarios_encontrados:
                # Si hay múltiples asignaturas, mostrar todas separadas por líneas
                lineas = []
                color_principal = None
                for horario in horarios_encontrados:
                    asignatura = horario.asignatura.nombre
                    profesor = horario.profesor.nombre
                    especialidad = horario.grado_asignatura.especialidad if horario.grado_asignatura and horario.grado_asignatura.especialidad else ''
                    
                    if especialidad:
                        lineas.append(f'{asignatura} [{especialidad}]\n({profesor})')
                    else:
                        lineas.append(f'{asignatura}\n({profesor})')
                    
                    # Usar el color de la primera asignatura
                    if color_principal is None:
                        color_principal = get_color_for_subject(asignatura)
                
                cell.value = '\n---\n'.join(lineas)
                cell.fill = PatternFill(start_color=color_principal, end_color=color_principal, fill_type='solid')
                cell.alignment = Alignment(horizontal='center', vertical='top', wrap_text=True)
            else:
                cell.value = ''
                cell.fill = PatternFill(start_color='F9F5F3', end_color='F9F5F3', fill_type='solid')
            
            cell.border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )
    
    # Ajustar ancho de columnas
    ws.column_dimensions['A'].width = 15
    for col_idx in range(2, 7):
        ws.column_dimensions[get_column_letter(col_idx)].width = 25
    
    # Ajustar alto de filas (con más espacio para múltiples asignaturas)
    for row_idx in range(6, 6 + len(horas_sorted)):
        ws.row_dimensions[row_idx].height = 90
    
    return wb

def crear_excel_todos_horarios(lotes_data):
    """Crea un Excel con múltiples hojas para todos los horarios activos.
    
    Args:
        lotes_data: [{
            'lote_id': 'XXX',
            'grado': 'Nombre Grado',
            'grado_id': 1,
            'anio': 1,
            'cuatrimestre': '1',
            'horarios': [HorarioClase objects]
        }]
    """
    wb = Workbook()
    wb.remove(wb.active)  # Remover hoja por defecto
    
    dias = ['LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES']
    
    # Hoja general
    ws_general = wb.create_sheet('General')
    ws_general['A1'] = 'Información General de Horarios'
    ws_general['A1'].font = Font(bold=True, size=14)
    
    ws_general['A3'] = 'Lote'
    ws_general['B3'] = 'Grado'
    ws_general['C3'] = 'Año'
    ws_general['D3'] = 'Cuatrimestre'
    ws_general['E3'] = 'Total Clases'
    
    for col in ['A', 'B', 'C', 'D', 'E']:
        ws_general[f'{col}3'].font = Font(bold=True)
        ws_general[f'{col}3'].fill = PatternFill(start_color='F4ECE6', end_color='F4ECE6', fill_type='solid')
    
    for row_idx, lote in enumerate(lotes_data, start=4):
        ws_general[f'A{row_idx}'] = f"Lote {lote['lote_id']}"
        ws_general[f'B{row_idx}'] = lote['grado']
        ws_general[f'C{row_idx}'] = lote['anio']
        ws_general[f'D{row_idx}'] = lote['cuatrimestre']
        ws_general[f'E{row_idx}'] = len(lote['horarios'])
    
    ws_general.column_dimensions['A'].width = 15
    ws_general.column_dimensions['B'].width = 25
    ws_general.column_dimensions['C'].width = 10
    ws_general.column_dimensions['D'].width = 12
    ws_general.column_dimensions['E'].width = 15
    
    # Crear hoja para cada lote
    for lote in lotes_data:
        ws = wb.create_sheet(f"Lote_{lote['lote_id'][:8]}")
        
        # Encabezado
        ws['A1'] = f"Lote: {lote['lote_id']}"
        ws['A1'].font = Font(bold=True, size=12)
        ws['A2'] = f"Grado: {lote['grado']}"
        ws['A3'] = f"Año: {lote['anio']}º - Cuatrimestre: {lote['cuatrimestre']}"
        
        # Crear tabla
        horas_set = set()
        for h in lote['horarios']:
            horas_set.add((h.hora_inicio, h.hora_fin))
        
        horas_sorted = sorted(horas_set)
        
        ws['A5'] = 'HORA'
        ws['A5'].font = Font(bold=True)
        ws['A5'].fill = PatternFill(start_color='F4ECE6', end_color='F4ECE6', fill_type='solid')
        
        for col_idx, dia in enumerate(dias, start=2):
            col = get_column_letter(col_idx)
            ws[f'{col}5'] = dia
            ws[f'{col}5'].font = Font(bold=True)
            ws[f'{col}5'].fill = PatternFill(start_color='F4ECE6', end_color='F4ECE6', fill_type='solid')
        
        for row_idx, (hora_inicio, hora_fin) in enumerate(horas_sorted, start=6):
            ws[f'A{row_idx}'] = f'{hora_inicio} - {hora_fin}'
            ws[f'A{row_idx}'].font = Font(bold=True)
            
            for col_idx, dia in enumerate(dias, start=2):
                col = get_column_letter(col_idx)
                cell = ws[f'{col}{row_idx}']
                
                # Buscar TODOS los horarios para este dia y hora
                horarios_encontrados = []
                for h in lote['horarios']:
                    if h.dia_de_la_semana == dia and h.hora_inicio == hora_inicio and h.hora_fin == hora_fin:
                        horarios_encontrados.append(h)
                
                if horarios_encontrados:
                    # Si hay múltiples asignaturas, mostrar todas separadas por líneas
                    lineas = []
                    color_principal = None
                    for horario in horarios_encontrados:
                        asignatura = horario.asignatura.nombre
                        profesor = horario.profesor.nombre
                        especialidad = horario.grado_asignatura.especialidad if horario.grado_asignatura and horario.grado_asignatura.especialidad else ''
                        
                        if especialidad:
                            lineas.append(f'{asignatura} [{especialidad}]\n({profesor})')
                        else:
                            lineas.append(f'{asignatura}\n({profesor})')
                        
                        # Usar el color de la primera asignatura
                        if color_principal is None:
                            color_principal = get_color_for_subject(asignatura)
                    
                    cell.value = '\n---\n'.join(lineas)
                    cell.fill = PatternFill(start_color=color_principal, end_color=color_principal, fill_type='solid')
                    cell.alignment = Alignment(horizontal='center', vertical='top', wrap_text=True)
                else:
                    cell.value = ''
                    cell.fill = PatternFill(start_color='F9F5F3', end_color='F9F5F3', fill_type='solid')
                
                cell.border = Border(
                    left=Side(style='thin'),
                    right=Side(style='thin'),
                    top=Side(style='thin'),
                    bottom=Side(style='thin')
                )
        
        ws.column_dimensions['A'].width = 15
        for col_idx in range(2, 7):
            ws.column_dimensions[get_column_letter(col_idx)].width = 25
        
        for row_idx in range(6, 6 + len(horas_sorted)):
            ws.row_dimensions[row_idx].height = 90
    
    # Crear hoja por cada grado
    lotes_por_grado = defaultdict(list)
    for lote in lotes_data:
        lotes_por_grado[lote['grado_id']].append(lote)
    
    for grado_id, lotes_del_grado in lotes_por_grado.items():
        if not lotes_del_grado:
            continue
        
        grado_nombre = lotes_del_grado[0]['grado']
        ws = wb.create_sheet(f"Grado {grado_nombre[:12]}")
        
        ws['A1'] = f"Grado: {grado_nombre}"
        ws['A1'].font = Font(bold=True, size=12)
        
        # Resumen por lote
        row = 3
        for lote in lotes_del_grado:
            ws[f'A{row}'] = f"Lote {lote['lote_id']}"
            ws[f'A{row}'].font = Font(bold=True, size=11)
            row += 1
            
            horas_set = set()
            for h in lote['horarios']:
                horas_set.add((h.hora_inicio, h.hora_fin))
            
            horas_sorted = sorted(horas_set)
            
            ws[f'A{row}'] = 'HORA'
            ws[f'A{row}'].font = Font(bold=True)
            ws[f'A{row}'].fill = PatternFill(start_color='F4ECE6', end_color='F4ECE6', fill_type='solid')
            
            for col_idx, dia in enumerate(dias, start=2):
                col = get_column_letter(col_idx)
                ws[f'{col}{row}'] = dia
                ws[f'{col}{row}'].font = Font(bold=True)
                ws[f'{col}{row}'].fill = PatternFill(start_color='F4ECE6', end_color='F4ECE6', fill_type='solid')
            
            row += 1
            for hora_inicio, hora_fin in horas_sorted:
                ws[f'A{row}'] = f'{hora_inicio} a {hora_fin}'
                ws[f'A{row}'].font = Font(bold=True)
                
                for col_idx, dia in enumerate(dias, start=2):
                    col = get_column_letter(col_idx)
                    cell = ws[f'{col}{row}']
                    
                    # Buscar TODOS los horarios para este dia y hora
                    horarios_encontrados = []
                    for h in lote['horarios']:
                        if h.dia_de_la_semana == dia and h.hora_inicio == hora_inicio and h.hora_fin == hora_fin:
                            horarios_encontrados.append(h)
                    
                    if horarios_encontrados:
                        # Si hay múltiples asignaturas, mostrar todas separadas por líneas
                        lineas = []
                        color_principal = None
                        for horario in horarios_encontrados:
                            asignatura = horario.asignatura.nombre
                            profesor = horario.profesor.nombre
                            especialidad = horario.grado_asignatura.especialidad if horario.grado_asignatura and horario.grado_asignatura.especialidad else ''
                            
                            if especialidad:
                                lineas.append(f'{asignatura} [{especialidad}]\n({profesor})')
                            else:
                                lineas.append(f'{asignatura}\n({profesor})')
                            
                            # Usar el color de la primera asignatura
                            if color_principal is None:
                                color_principal = get_color_for_subject(asignatura)
                        
                        cell.value = '\n---\n'.join(lineas)
                        cell.fill = PatternFill(start_color=color_principal, end_color=color_principal, fill_type='solid')
                        cell.alignment = Alignment(horizontal='center', vertical='top', wrap_text=True)
                    else:
                        cell.value = ''
                        cell.fill = PatternFill(start_color='F9F5F3', end_color='F9F5F3', fill_type='solid')
                    
                    cell.border = Border(
                        left=Side(style='thin'),
                        right=Side(style='thin'),
                        top=Side(style='thin'),
                        bottom=Side(style='thin')
                    )
                
                row += 1
            
            row += 2
        
        ws.column_dimensions['A'].width = 15
        for col_idx in range(2, 7):
            ws.column_dimensions[get_column_letter(col_idx)].width = 25
    
    return wb
