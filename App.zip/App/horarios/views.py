from .resolver_automatico import resolver_conflictos_lote
from collections import defaultdict
import unicodedata
from datetime import datetime, time
from uuid import uuid4
from io import BytesIO

from django.contrib.auth import login, logout
from django.contrib.auth.models import User
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.views import LoginView, LogoutView
from django.db import transaction
from django.db.models import Count, Max, Min, Q
from django.http import JsonResponse, FileResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, FormView, ListView, TemplateView, UpdateView, View

from .forms import AdminUsuarioCreateForm, AdminUsuarioUpdateForm, AsignaturaForm, AsignaturaProfesorForm, AusenciaProfesorForm, CredencialesUsuarioForm, GenerarHorarioForm, GradoAsignaturaForm, ProfesorForm, RegistroUsuarioForm, SolicitudCambioProfesorForm
from .models import (
    Asignatura,
    AsignaturaProfesor,
    AusenciaProfesor,
    Grado,
    GradoAsignatura,
    HorarioClase,
    PerfilUsuario,
    Profesor,
    SolicitudCambioProfesor,
)
from .excel_generator import crear_excel_lote, crear_excel_todos_horarios


def obtener_rol(usuario):
    if usuario.is_superuser:
        return 'admin'
    try:
        return usuario.perfilusuario.tipo_usuario.nombre.lower()
    except PerfilUsuario.DoesNotExist:
        return None


def debe_forzar_cambio_contrasena(usuario):
    perfil = getattr(usuario, 'perfilusuario', None)
    return bool(perfil and perfil.forzar_cambio_contrasena)


def url_cambio_contrasena_forzado(usuario):
    rol = obtener_rol(usuario)
    if rol == 'admin':
        return f"{reverse_lazy('horarios:admin_credenciales')}?force_password_change=1"
    if rol == 'profesor':
        return f"{reverse_lazy('horarios:profesor_credenciales')}?force_password_change=1"
    return None


class RolRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    rol_requerido = None

    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated and debe_forzar_cambio_contrasena(request.user):
            nombre_vista = getattr(getattr(request, 'resolver_match', None), 'url_name', '')
            if nombre_vista not in {'admin_credenciales', 'profesor_credenciales', 'logout'}:
                destino = url_cambio_contrasena_forzado(request.user)
                if destino:
                    return redirect(destino)
        return super().dispatch(request, *args, **kwargs)

    def test_func(self):
        if self.request.user.is_superuser and self.rol_requerido == 'admin':
            return True
        return obtener_rol(self.request.user) == self.rol_requerido


class SugerenciasBusquedaView(RolRequiredMixin, View):
    rol_requerido = 'admin'
    modelo = None
    campo = 'nombre'

    def get_queryset(self):
        return self.modelo.objects.all().order_by(self.campo)

    def get(self, request, *args, **kwargs):
        termino = request.GET.get('q', '').strip()
        queryset = self.get_queryset()

        if termino:
            queryset = queryset.filter(**{f'{self.campo}__icontains': termino})

        sugerencias = list(queryset.values_list(self.campo, flat=True)[:8])
        return JsonResponse({'results': sugerencias})


class RegistroView(CreateView):
    form_class = RegistroUsuarioForm
    template_name = 'horarios/registro.html'
    success_url = reverse_lazy('horarios:inicio')

    def form_valid(self, form):
        usuario = form.save()
        PerfilUsuario.objects.create(
            usuario=usuario,
            tipo_usuario=form.cleaned_data['tipo_usuario'],
            profesor=form.cleaned_data.get('profesor'),
        )
        login(self.request, usuario)
        return redirect('horarios:inicio')


class InicioView(TemplateView):
    template_name = 'horarios/inicio.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        grado_id = self.request.GET.get('grado')
        anio = self.request.GET.get('anio')
        cuatrimestre = self.request.GET.get('cuatrimestre')

        horarios = (
            HorarioClase.objects.filter(activo=True)
            .exclude(lote_generacion='')
            .select_related('grado', 'asignatura', 'profesor', 'grado_asignatura')
        )

        if grado_id:
            horarios = horarios.filter(grado_asignatura__grado_id=grado_id)
        if anio:
            horarios = horarios.filter(grado_asignatura__anio=anio)
        if cuatrimestre:
            horarios = horarios.filter(grado_asignatura__cuatrimestre=cuatrimestre)

        horarios = horarios.distinct().order_by(
            'grado__nombre',
            'grado_asignatura__anio',
            'grado_asignatura__cuatrimestre',
            'dia_de_la_semana',
            'hora_inicio',
        )

        day_to_key = {
            'LUNES': 'l',
            'MARTES': 'm',
            'MIERCOLES': 'x',
            'JUEVES': 'j',
            'VIERNES': 'v',
        }

        grupos = {}
        for horario in horarios:
            relacion = horario.grado_asignatura or GradoAsignatura.objects.filter(grado=horario.grado, asignatura=horario.asignatura).first()
            if not relacion:
                continue

            group_key = (horario.grado.id, relacion.anio, relacion.cuatrimestre)
            if group_key not in grupos:
                grupos[group_key] = {
                    'titulo': f"{horario.grado.nombre} - {relacion.anio}º - {relacion.get_cuatrimestre_display()}",
                    'rows': {},
                }

            row_key = (horario.hora_inicio, horario.hora_fin)
            if row_key not in grupos[group_key]['rows']:
                grupos[group_key]['rows'][row_key] = {
                    'hora': f"{horario.hora_inicio.strftime('%H:%M')} - {horario.hora_fin.strftime('%H:%M')}",
                    'l': [],
                    'm': [],
                    'x': [],
                    'j': [],
                    'v': [],
                }

            raw_day = horario.dia_de_la_semana or ''
            normalized_day = unicodedata.normalize('NFKD', raw_day).encode('ascii', 'ignore').decode('ascii')
            day_key = day_to_key.get(normalized_day.strip().upper())
            if day_key:
                especialidad = relacion.especialidad if relacion else None
                if especialidad == 'TI':
                    especialidad_abreviada = 'IT'
                elif especialidad == 'IS':
                    especialidad_abreviada = 'IS'
                else:
                    especialidad_abreviada = ''

                grupos[group_key]['rows'][row_key][day_key].append(
                    {
                        'asignatura': horario.asignatura.nombre,
                        'texto': (
                            f"{horario.asignatura.nombre} [{especialidad_abreviada}] ({horario.profesor.nombre})"
                            if especialidad_abreviada
                            else f"{horario.asignatura.nombre} ({horario.profesor.nombre})"
                        ),
                    }
                )

        horarios_por_grupo = []
        for _, data in sorted(grupos.items(), key=lambda x: x[1]['titulo']):
            matriz = [data['rows'][key] for key in sorted(data['rows'].keys())]
            horarios_por_grupo.append({
                'titulo': data['titulo'],
                'matriz': matriz,
            })

        context['horarios_por_grupo'] = horarios_por_grupo
        context['grados'] = Grado.objects.order_by('nombre')
        context['anios'] = sorted(
            set(GradoAsignatura.objects.values_list('anio', flat=True)),
        ) or [1, 2, 3, 4, 5]
        context['cuatrimestres'] = GradoAsignatura.Cuatrimestres.choices
        context['grado_seleccionado'] = grado_id
        context['anio_seleccionado'] = anio
        context['cuatrimestre_seleccionado'] = cuatrimestre
        return context


class AppLoginView(LoginView):
    template_name = 'horarios/login.html'

    def get_success_url(self):
        if debe_forzar_cambio_contrasena(self.request.user):
            destino_forzado = url_cambio_contrasena_forzado(self.request.user)
            if destino_forzado:
                return destino_forzado
        rol = obtener_rol(self.request.user)
        if rol == 'admin':
            return reverse_lazy('horarios:admin_panel')
        if rol == 'profesor':
            return reverse_lazy('horarios:profesor_horarios')
        return reverse_lazy('horarios:inicio')


class AppLogoutView(LogoutView):
    next_page = reverse_lazy('horarios:login')


class CredencialesUsuarioBaseView(RolRequiredMixin, FormView):
    template_name = 'horarios/credenciales_formulario.html'
    form_class = CredencialesUsuarioForm
    titulo = 'Seguridad de la cuenta'
    descripcion = 'Actualiza tu usuario o contraseña verificando tu contraseña actual.'
    volver_url = 'horarios:inicio'
    volver_label = 'Volver'

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        kwargs['force_password_change'] = (
            self.request.GET.get('force_password_change') == '1'
            or debe_forzar_cambio_contrasena(self.request.user)
        )
        return kwargs

    def form_valid(self, form):
        form.save()
        logout(self.request)
        login_url = str(reverse_lazy('horarios:login'))
        return redirect(f'{login_url}?cred_updated=1')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['titulo'] = self.titulo
        context['descripcion'] = self.descripcion
        context['volver_url'] = self.volver_url
        context['volver_label'] = self.volver_label
        context['cambio_forzado'] = debe_forzar_cambio_contrasena(self.request.user) or self.request.GET.get('force_password_change') == '1'
        return context


class AdminCredencialesView(CredencialesUsuarioBaseView):
    rol_requerido = 'admin'
    titulo = 'Seguridad del administrador'
    descripcion = 'Confirma tu contraseña actual para cambiar usuario y/o contraseña de tu cuenta admin.'
    volver_url = 'horarios:admin_panel'
    volver_label = 'Volver al panel'


class ProfesorCredencialesView(CredencialesUsuarioBaseView):
    rol_requerido = 'profesor'
    titulo = 'Seguridad del profesor'
    descripcion = 'Confirma tu contraseña actual para cambiar usuario y/o contraseña de tu cuenta docente.'
    volver_url = 'horarios:profesor_horarios'
    volver_label = 'Volver a horarios'


class AdminPanelView(RolRequiredMixin, TemplateView):
    rol_requerido = 'admin'
    template_name = 'horarios/admin_panel.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        ultimo_login_admin = self.request.user.last_login
        pendientes = AusenciaProfesor.objects.filter(estado=AusenciaProfesor.EstadoAusencia.PENDIENTE)
        context['limitaciones_pendientes_count'] = pendientes.count()
        if ultimo_login_admin:
            context['limitaciones_nuevas_count'] = pendientes.filter(creada_en__gt=ultimo_login_admin).count()
        else:
            context['limitaciones_nuevas_count'] = pendientes.count()

        context['total_grados'] = Grado.objects.count()
        context['total_asignaturas'] = Asignatura.objects.count()
        context['total_profesores'] = Profesor.objects.count()
        context['total_cuentas'] = User.objects.count()
        context['total_horarios_activos'] = (
            HorarioClase.objects.exclude(lote_generacion='')
            .filter(activo=True)
            .values('lote_generacion')
            .distinct()
            .count()
        )

        return context


class AdminUsuarioListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = User
    template_name = 'horarios/usuario_lista.html'
    context_object_name = 'usuarios'
    paginate_by = 6

    def get_queryset(self):
        queryset = User.objects.select_related('perfilusuario__tipo_usuario', 'perfilusuario__profesor').order_by('username')
        search_query = self.request.GET.get('q', '').strip()
        if search_query:
            queryset = queryset.filter(
                Q(username__icontains=search_query)
                | Q(perfilusuario__tipo_usuario__nombre__icontains=search_query)
                | Q(perfilusuario__profesor__nombre__icontains=search_query)
            ).distinct()
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        usuarios_query = self.get_queryset()
        context['search_query'] = self.request.GET.get('q', '').strip()
        context['total_usuarios'] = usuarios_query.count()
        context['usuarios_admin'] = usuarios_query.filter(perfilusuario__tipo_usuario__nombre__iexact='admin').count()
        context['usuarios_profesor'] = usuarios_query.filter(perfilusuario__tipo_usuario__nombre__iexact='profesor').count()
        context['usuarios_superusuario'] = usuarios_query.filter(is_superuser=True).count()
        context['usuarios_sin_perfil'] = usuarios_query.filter(perfilusuario__isnull=True).count()
        context['usuarios_forzar_cambio'] = usuarios_query.filter(perfilusuario__forzar_cambio_contrasena=True).count()

        page_obj = context.get('page_obj')
        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        return context


class AdminUsuarioSuggestionsView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def get(self, request, *args, **kwargs):
        termino = request.GET.get('q', '').strip()
        sugerencias = []

        usuarios = User.objects.select_related('perfilusuario__tipo_usuario', 'perfilusuario__profesor').order_by('username')

        if termino:
            usuarios = usuarios.filter(
                Q(username__icontains=termino)
                | Q(perfilusuario__tipo_usuario__nombre__icontains=termino)
                | Q(perfilusuario__profesor__nombre__icontains=termino)
            ).distinct()

        sugerencias.extend(list(usuarios.values_list('username', flat=True)[:5]))
        sugerencias.extend(list(usuarios.values_list('perfilusuario__tipo_usuario__nombre', flat=True)[:3]))
        sugerencias.extend(list(usuarios.values_list('perfilusuario__profesor__nombre', flat=True)[:3]))

        vistos = []
        for sugerencia in sugerencias:
            if sugerencia and sugerencia not in vistos:
                vistos.append(sugerencia)

        return JsonResponse({'results': vistos[:8]})


class AdminUsuarioCreateView(RolRequiredMixin, FormView):
    rol_requerido = 'admin'
    template_name = 'horarios/usuario_formulario.html'
    form_class = AdminUsuarioCreateForm
    success_url = reverse_lazy('horarios:admin_usuarios')

    def form_valid(self, form):
        form.save()
        return redirect(self.success_url)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['es_edicion'] = False
        context['titulo'] = 'Crear cuenta'
        context['descripcion'] = 'Da de alta una nueva cuenta y asígnale su rol correspondiente.'
        return context


class AdminUsuarioUpdateView(RolRequiredMixin, FormView):
    rol_requerido = 'admin'
    template_name = 'horarios/usuario_formulario.html'
    form_class = AdminUsuarioUpdateForm
    success_url = reverse_lazy('horarios:admin_usuarios')

    def dispatch(self, request, *args, **kwargs):
        self.user_instance = get_object_or_404(User, pk=kwargs['pk'])
        return super().dispatch(request, *args, **kwargs)

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user_instance'] = self.user_instance
        return kwargs

    def form_valid(self, form):
        user = form.save()
        if user.pk == self.request.user.pk and form.cleaned_data.get('new_password1'):
            logout(self.request)
            login_url = str(reverse_lazy('horarios:login'))
            return redirect(f'{login_url}?cred_updated=1')
        return redirect(self.success_url)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['es_edicion'] = True
        context['titulo'] = f'Editar cuenta: {self.user_instance.username}'
        context['descripcion'] = 'Modifica el rol, usuario y, si quieres, la contraseña de esta cuenta.'
        context['user_obj'] = self.user_instance
        return context


class AdminUsuarioDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        user = get_object_or_404(User, pk=pk)
        if user.pk == request.user.pk:
            return redirect('horarios:admin_usuarios')
        user.delete()
        return redirect('horarios:admin_usuarios')


class GenerarHorarioView(RolRequiredMixin, View):
    rol_requerido = 'admin'
    template_name = 'horarios/generar_horario_formulario.html'

    def get(self, request, *args, **kwargs):
        initial = {
            'grado': request.GET.get('grado') or None,
            'anio': request.GET.get('anio') or None,
            'cuatrimestre': request.GET.get('cuatrimestre') or None,
            'turno': request.GET.get('turno') or None,
        }
        form = GenerarHorarioForm(initial=initial)
        return self.render_form(form)

    def post(self, request, *args, **kwargs):
        form = GenerarHorarioForm(request.POST)
        if not form.is_valid():
            return self.render_form(form)

        grado = form.cleaned_data['grado']
        anio = int(form.cleaned_data['anio'])
        cuatrimestre = form.cleaned_data['cuatrimestre']
        turno = form.cleaned_data['turno']
        resultado = self.generar_horario(grado, anio, cuatrimestre, turno)
        return self.render_form(GenerarHorarioForm(initial=form.cleaned_data), resultado, reset_filters=True)

    def render_form(self, form, resultado=None, reset_filters=False):
        grado = None
        anio = None
        cuatrimestre = None

        if form.is_bound and form.is_valid():
            grado = form.cleaned_data['grado']
            anio = int(form.cleaned_data['anio'])
            cuatrimestre = form.cleaned_data['cuatrimestre']
        elif form.initial.get('grado') and form.initial.get('anio') and form.initial.get('cuatrimestre'):
            try:
                grado = Grado.objects.get(pk=form.initial['grado'])
                anio = int(form.initial['anio'])
                cuatrimestre = str(form.initial['cuatrimestre'])
            except Exception:
                grado = None
                anio = None
                cuatrimestre = None

        lotes, horarios_generados = self.obtener_lotes_y_horarios(grado, anio, cuatrimestre)

        # Además, obtener todos los lotes disponibles globalmente (sin filtrar)
        qs_all = HorarioClase.objects.exclude(lote_generacion='').select_related('grado', 'grado_asignatura')
        lotes_all = list(
            qs_all.values(
                'lote_generacion',
                'grado_id',
                'grado__nombre',
                'grado_asignatura__anio',
                'grado_asignatura__cuatrimestre',
            )
            .annotate(clases=Count('id'), activo=Max('activo'), ultimo_horario_id=Max('id'))
            .order_by('-ultimo_horario_id')
        )

        for lote in lotes_all:
            lote['id'] = lote.pop('lote_generacion')
            lote['grado_nombre'] = lote.pop('grado__nombre')
            lote['anio'] = lote.pop('grado_asignatura__anio')
            lote['cuatrimestre'] = lote.pop('grado_asignatura__cuatrimestre')

        if reset_filters:
            filtro_lote = ''
            cuatrimestre_tabla = '1'
            grado_tabla = ''
            anio_tabla = ''
        else:
            filtro_lote = self.request.GET.get('filtro_lote', '').strip()
            grado_tabla = self.request.GET.get('grado_tabla', '').strip() or ''
            anio_tabla = self.request.GET.get('anio_tabla', '').strip() or ''
            
            if filtro_lote and lotes:
                lote_seleccionado = next((lote for lote in lotes if lote['id'] == filtro_lote), None)
                if lote_seleccionado is None:
                    filtro_lote = ''
                else:
                    horarios_generados = horarios_generados.filter(lote_generacion=filtro_lote)
                    cuatrimestre_tabla = str(lote_seleccionado['cuatrimestre'])
            else:
                cuatrimestre_tabla = self.request.GET.get('cuatrimestre_tabla', '1').strip() or '1'

                if cuatrimestre_tabla in {'1', '2'}:
                    horarios_generados = horarios_generados.filter(grado_asignatura__cuatrimestre=cuatrimestre_tabla)
                else:
                    cuatrimestre_tabla = 'todos'
            
            # Aplicar filtros de grado y año
            if grado_tabla:
                try:
                    horarios_generados = horarios_generados.filter(grado_id=int(grado_tabla))
                except (ValueError, TypeError):
                    grado_tabla = ''
            
            if anio_tabla:
                try:
                    horarios_generados = horarios_generados.filter(grado_asignatura__anio=int(anio_tabla))
                except (ValueError, TypeError):
                    anio_tabla = ''

        # Obtener ausencias aprobadas para detectar conflictos
        ausencias_aprobadas = AusenciaProfesor.objects.filter(
            estado=AusenciaProfesor.EstadoAusencia.APROBADA
        )
        
        matriz_horario = self.construir_matriz_horario(horarios_generados, ausencias_aprobadas, anio_tabla)
        
        # Obtener grados y años disponibles para los selects
        grados_disponibles = Grado.objects.order_by('nombre').values_list('id', 'nombre')
        anios_disponibles = sorted(set(
            GradoAsignatura.objects.values_list('anio', flat=True).distinct()
        ))

        resultado_masivo = self.request.session.pop('resultado_generacion_masiva', None)

        context = {
            'form': form,
            'resultado': resultado,
            'resultado_masivo': resultado_masivo,
            'lotes': lotes,
            'lotes_disponibles': lotes,
            'lotes_disponibles_all': lotes_all,
            'horarios_generados': horarios_generados,
            'filtro_lote': filtro_lote,
            'cuatrimestre_tabla': cuatrimestre_tabla,
            'grado_tabla': grado_tabla,
            'anio_tabla': anio_tabla,
            'grados_disponibles': grados_disponibles,
            'anios_disponibles': anios_disponibles,
            'matriz_horario': matriz_horario,
            'estado_lote': self.request.GET.get('estado_lote', ''),
            'resolver_resultado': self.request.session.pop('resolver_resultado', None),
        }
        return render(self.request, self.template_name, context)


    def construir_matriz_horario(self, horarios, ausencias_aprobadas=None, anio_tabla=''):
        if ausencias_aprobadas is None:
            ausencias_aprobadas = AusenciaProfesor.objects.filter(
                estado=AusenciaProfesor.EstadoAusencia.APROBADA
            )
        
        # Crear caché de ausencias por profesor y día para optimizar búsquedas
        ausencias_por_profesor_dia = {}
        for ausencia in ausencias_aprobadas:
            key = (ausencia.profesor_id, ausencia.dia_de_la_semana)
            if key not in ausencias_por_profesor_dia:
                ausencias_por_profesor_dia[key] = []
            ausencias_por_profesor_dia[key].append(ausencia)
        
        day_to_key = {
            'LUNES': 'l',
            'MARTES': 'm',
            'MIERCOLES': 'x',
            'JUEVES': 'j',
            'VIERNES': 'v',
        }

        rows = {}
        for horario in horarios:
            row_key = (horario.hora_inicio, horario.hora_fin)
            if row_key not in rows:
                rows[row_key] = {
                    'hora': f"{horario.hora_inicio.strftime('%H:%M')} - {horario.hora_fin.strftime('%H:%M')}",
                    'l': [],
                    'm': [],
                    'x': [],
                    'j': [],
                    'v': [],
                }

            col = day_to_key.get(horario.dia_de_la_semana)
            if col:
                especialidad = horario.grado_asignatura.especialidad if horario.grado_asignatura else None
                anio_asignatura = horario.grado_asignatura.anio if horario.grado_asignatura else None
                
                # Construir texto del item, agregando año si no se filtró por año
                if anio_tabla:
                    # Se filtró por año específico, no mostrar
                    if especialidad:
                        texto_base = f"{horario.asignatura.nombre} [{especialidad}] ({horario.profesor.nombre})"
                    else:
                        texto_base = f"{horario.asignatura.nombre} ({horario.profesor.nombre})"
                else:
                    # No se filtró por año, mostrar el año
                    if especialidad:
                        texto_base = f"{horario.asignatura.nombre} [{especialidad}] ({anio_asignatura}º) ({horario.profesor.nombre})"
                    else:
                        texto_base = f"{horario.asignatura.nombre} ({anio_asignatura}º) ({horario.profesor.nombre})"
                
                # Verificar si hay conflicto con ausencias aprobadas
                conflicto_ausencia = None
                profesor_id = horario.profesor.id  # Usar profesor.id en lugar de profesor_id
                ausencias_para_este_dia = ausencias_por_profesor_dia.get((profesor_id, horario.dia_de_la_semana), [])
                cuatrimestre = horario.grado_asignatura.cuatrimestre if horario.grado_asignatura else None
                
                for ausencia in ausencias_para_este_dia:
                    if ausencia.coincide_con_horario(horario.hora_inicio, horario.hora_fin, cuatrimestre):
                        conflicto_ausencia = ausencia
                        break
                
                item = {
                    'asignatura': horario.asignatura.nombre,
                    'especialidad': especialidad,
                    'profesor_nombre': horario.profesor.nombre,
                    'grado_nombre': horario.grado.nombre if horario.grado else '',
                    'texto': texto_base,
                    'tiene_conflicto': conflicto_ausencia is not None,
                    'conflicto_ausencia': conflicto_ausencia,
                }
                
                rows[row_key][col].append(item)

        return [rows[key] for key in sorted(rows.keys())]

    def generar_horario(self, grado, anio, cuatrimestre, turno):
        es_doble_grado = '+' in (grado.nombre or '')
        relaciones = list(
            GradoAsignatura.objects.filter(grado=grado, anio=anio, cuatrimestre=cuatrimestre)
            .select_related('asignatura')
            .order_by('asignatura__nombre')
        )

        slots = self.obtener_slots(turno)
        if not slots:
            return {'generados': 0, 'advertencias': ['No hay franjas horarias para el turno elegido.']}

        slot_indices = {slot: index for index, slot in enumerate(slots)}

        with transaction.atomic():
            lote_id = uuid4().hex[:12]

            ocupacion_profesor = defaultdict(list)
            ocupacion_grupo = defaultdict(list)
            horarios_existentes = HorarioClase.objects.filter(activo=True).select_related('profesor', 'grado_asignatura', 'asignatura', 'grado')
            for horario in horarios_existentes:
                if horario.profesor_id:
                    # Almacenar tambien asignatura_id y grado_id para permitir solapamientos controlados
                    cuatrimestre_horario = horario.grado_asignatura.cuatrimestre if horario.grado_asignatura else None
                    ocupacion_profesor[(horario.profesor_id, horario.dia_de_la_semana)].append(
                        (horario.hora_inicio, horario.hora_fin, horario.asignatura_id, horario.grado_id, cuatrimestre_horario)
                    )
                relacion_existente = horario.grado_asignatura or GradoAsignatura.objects.filter(grado=horario.grado, asignatura=horario.asignatura).select_related('asignatura').first()
                if (
                    horario.grado_id == grado.id
                    and relacion_existente
                    and relacion_existente.cuatrimestre == cuatrimestre
                    and relacion_existente.anio == anio
                ):
                    ocupacion_grupo[horario.dia_de_la_semana].append((horario.hora_inicio, horario.hora_fin, relacion_existente))

            advertencias = []
            programables = []
            for relacion in relaciones:
                profesor = self.obtener_profesor(relacion, grado)
                if not profesor:
                    advertencias.append(f'No hay profesor asignado para {relacion.asignatura.nombre}.')
                    continue
                programables.append((relacion, profesor))

            # No eliminar horarios de otros grados: solo usar las ocupaciones existentes como restricciones.

            preferred_days = ['LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES']
            asignaciones = self.resolver_programacion(
                programables,
                slots,
                ocupacion_profesor,
                ocupacion_grupo,
                preferred_days,
            )

            # Si falla la primera resolución, intentar varios reinicios aleatorios
            if asignaciones is None:
                import random
                for attempt in range(8):
                    # reordenar programables para variar branching
                    programables_shuffled = list(programables)
                    random.shuffle(programables_shuffled)
                    asignaciones = self.resolver_programacion(
                        programables_shuffled,
                        slots,
                        ocupacion_profesor,
                        ocupacion_grupo,
                        preferred_days,
                    )
                    if asignaciones is not None:
                        break

            # Si sigue fallando, relajar conflictos de grupo (permitir huecos en otros grados)
            if asignaciones is None:
                ocupacion_grupo_relajado = defaultdict(list)
                for dia, items in ocupacion_grupo.items():
                    # conservar solo ocupaciones pertenecientes al grado actual
                    for inicio, fin, relacion_existente in items:
                        try:
                            grado_id_existente = relacion_existente.grado_id
                        except Exception:
                            grado_id_existente = None
                        if grado_id_existente == grado.id:
                            ocupacion_grupo_relajado[dia].append((inicio, fin, relacion_existente))

                asignaciones = self.resolver_programacion(
                    programables,
                    slots,
                    ocupacion_profesor,
                    ocupacion_grupo_relajado,
                    preferred_days,
                )

            # Último recurso: algoritmo greedy que borra conflictos mínimos para forzar asignación
            if asignaciones is None:
                asignaciones = self.generar_horario_greedy(programables, slots, slot_indices, ocupacion_profesor, ocupacion_grupo, grado, anio, cuatrimestre)

            if asignaciones is None:
                advertencias.append('No se pudo generar un horario completo con las restricciones actuales.')
                return {'generados': 0, 'advertencias': advertencias, 'lote_id': lote_id}

            generados = 0
            for relacion, profesor, pareja in asignaciones:
                guardados = []
                for dia, inicio, fin in pareja:
                    horario = HorarioClase(
                        grado=grado,
                        asignatura=relacion.asignatura,
                        grado_asignatura=relacion,
                        profesor=profesor,
                        dia_de_la_semana=dia,
                        hora_inicio=inicio,
                        hora_fin=fin,
                        aula='',
                        lote_generacion=lote_id,
                        activo=False,
                    )
                    try:
                        horario.full_clean()
                        horario.save()
                    except Exception as exc:
                        advertencias.append(f'No se pudo guardar {relacion.asignatura.nombre}: {exc}')
                        for horario_guardado, _, _ in guardados:
                            horario_guardado.delete()
                        return {'generados': generados, 'advertencias': advertencias, 'lote_id': lote_id}
                    guardados.append((horario, dia, inicio, fin))

                for _, dia, inicio, fin in guardados:
                    ocupacion_profesor[(profesor.dni, dia)].append(
                        (inicio, fin, relacion.asignatura.id, relacion.grado.id, relacion.cuatrimestre)
                    )
                    ocupacion_grupo[dia].append((inicio, fin, relacion))
                    generados += 1

        return {'generados': generados, 'advertencias': advertencias, 'lote_id': lote_id}

    def generar_horarios_globales(self, cuatrimestre=None):
        relaciones_qs = GradoAsignatura.objects.select_related('grado', 'asignatura').order_by(
            'grado__nombre', 'anio', 'cuatrimestre', 'asignatura__nombre'
        )
        if cuatrimestre is not None:
            relaciones_qs = relaciones_qs.filter(cuatrimestre=cuatrimestre)

        relaciones = list(relaciones_qs)

        grupos = {}
        for relacion in relaciones:
            key = (relacion.grado_id, relacion.anio, relacion.cuatrimestre)
            if key not in grupos:
                grupos[key] = {
                    'grado': relacion.grado,
                    'anio': relacion.anio,
                    'cuatrimestre': relacion.cuatrimestre,
                    'relaciones': [],
                }
            grupos[key]['relaciones'].append(relacion)

        ordenados = sorted(
            grupos.values(),
            key=lambda item: (
                0 if '+' in (item['grado'].nombre or '') else 1,
                item['grado'].nombre or '',
                item['anio'],
                item['cuatrimestre'],
            ),
        )

        relaciones_info = {}
        grupos_objetivo = {}
        omitidos = 0
        advertencias = []

        for item in ordenados:
            grado = item['grado']
            anio = item['anio']
            cuatrimestre = item['cuatrimestre']
            relaciones_grupo = item['relaciones']

            sin_profesor = [
                relacion.asignatura.nombre
                for relacion in relaciones_grupo
                if not self.obtener_profesor(relacion, grado)
            ]

            if sin_profesor:
                omitidos += 1
                listado = ', '.join(sin_profesor[:6])
                if len(sin_profesor) > 6:
                    listado = f"{listado}..."
                advertencias.append(
                    f"Se omite {grado.nombre} {anio}º C{cuatrimestre}: faltan profesores en {listado}."
                )
                continue

            turno = self._inferir_turno_global(grado, anio, cuatrimestre)
            slots = self.obtener_slots(turno)
            if not slots:
                advertencias.append(
                    f"Se omite {grado.nombre} {anio}º C{cuatrimestre}: no hay franjas para el turno {turno}."
                )
                omitidos += 1
                continue

            grupos_objetivo[(grado.id, anio, cuatrimestre)] = {
                'grado': grado,
                'anio': anio,
                'cuatrimestre': cuatrimestre,
            }

            for relacion in relaciones_grupo:
                profesor = self.obtener_profesor(relacion, grado)
                relaciones_info[relacion.id] = {
                    'relacion': relacion,
                    'profesor': profesor,
                    'slots': slots,
                    'grupo_key': (grado.id, anio, cuatrimestre),
                }

        if not grupos_objetivo:
            return {
                'generados': 0,
                'procesados': 0,
                'omitidos': omitidos,
                'lotes': [],
                'advertencias': advertencias,
            }

        items = self._construir_items_compartidos(relaciones_info)
        ocupacion_profesor, ocupacion_grupo = self._construir_ocupacion_global(set(grupos_objetivo.keys()))

        asignaciones = self._resolver_items_global(items, relaciones_info, ocupacion_profesor, ocupacion_grupo)
        if asignaciones is None:
            advertencias.append('No se pudo generar un horario completo con las restricciones actuales.')
            return {
                'generados': 0,
                'procesados': len(grupos_objetivo),
                'omitidos': omitidos,
                'lotes': [],
                'advertencias': advertencias,
            }

        lotes_por_grupo = {key: uuid4().hex[:12] for key in grupos_objetivo.keys()}
        total_generados = 0
        for relacion_id, pareja in asignaciones.items():
            info = relaciones_info[relacion_id]
            relacion = info['relacion']
            profesor = info['profesor']
            lote_id = lotes_por_grupo[info['grupo_key']]
            guardados = []

            for dia, inicio, fin in pareja:
                horario = HorarioClase(
                    grado=relacion.grado,
                    asignatura=relacion.asignatura,
                    grado_asignatura=relacion,
                    profesor=profesor,
                    dia_de_la_semana=dia,
                    hora_inicio=inicio,
                    hora_fin=fin,
                    aula='',
                    lote_generacion=lote_id,
                    activo=False,
                )
                try:
                    horario.full_clean()
                    horario.save()
                except Exception as exc:
                    for horario_guardado in guardados:
                        horario_guardado.delete()
                    advertencias.append(
                        f"{relacion.grado.nombre} {relacion.anio}º C{relacion.cuatrimestre}: "
                        f"no se pudo guardar {relacion.asignatura.nombre}: {exc}"
                    )
                    break
                guardados.append(horario)
                total_generados += 1

        return {
            'generados': total_generados,
            'procesados': len(grupos_objetivo),
            'omitidos': omitidos,
            'lotes': list(lotes_por_grupo.values()),
            'advertencias': advertencias,
        }

    def _construir_items_compartidos(self, relaciones_info):
        parent = {rel_id: rel_id for rel_id in relaciones_info.keys()}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a, b):
            ra = find(a)
            rb = find(b)
            if ra != rb:
                parent[rb] = ra

        relaciones_ids = set(relaciones_info.keys())
        for relacion_id, info in relaciones_info.items():
            relacion = info['relacion']
            relacionada = self._buscar_relacion_compartida(relacion)
            if relacionada and relacionada.id in relaciones_ids:
                union(relacion_id, relacionada.id)

        grupos = {}
        for relacion_id in relaciones_info.keys():
            root = find(relacion_id)
            grupos.setdefault(root, []).append(relacion_id)

        return list(grupos.values())

    @staticmethod
    def _buscar_relacion_compartida(relacion):
        asignacion = AsignaturaProfesor.objects.filter(
            asignatura=relacion.asignatura,
            coincide_con_grado_relacionado=True,
        ).filter(
            Q(grado=relacion.grado) | Q(grado_coincidente=relacion.grado)
        ).select_related('grado', 'grado_coincidente').first()

        if not asignacion:
            return None

        grado_relacionado = (
            asignacion.grado_coincidente
            if asignacion.grado == relacion.grado
            else asignacion.grado
        )
        if not grado_relacionado:
            return None

        qs = GradoAsignatura.objects.filter(
            grado=grado_relacionado,
            asignatura=relacion.asignatura,
            cuatrimestre=relacion.cuatrimestre,
        )

        if '+' not in (grado_relacionado.nombre or ''):
            qs = qs.filter(anio=relacion.anio)

        return qs.first()

    def _construir_ocupacion_global(self, grupos_objetivo):
        ocupacion_profesor = defaultdict(list)
        ocupacion_grupo = defaultdict(list)
        horarios_existentes = HorarioClase.objects.filter(activo=True).select_related(
            'profesor', 'grado_asignatura', 'asignatura', 'grado'
        )

        for horario in horarios_existentes:
            if not horario.grado_asignatura:
                continue

            grupo_key = (
                horario.grado_id,
                horario.grado_asignatura.anio,
                horario.grado_asignatura.cuatrimestre,
            )

            if grupo_key in grupos_objetivo:
                continue

            ocupacion_grupo[(
                horario.grado_id,
                horario.grado_asignatura.anio,
                horario.grado_asignatura.cuatrimestre,
                horario.dia_de_la_semana,
            )].append((horario.hora_inicio, horario.hora_fin, horario.grado_asignatura))

            if horario.profesor_id:
                cuatrimestre_horario = horario.grado_asignatura.cuatrimestre
                ocupacion_profesor[(horario.profesor_id, horario.dia_de_la_semana)].append(
                    (horario.hora_inicio, horario.hora_fin, horario.asignatura_id, horario.grado_id, cuatrimestre_horario)
                )

        return ocupacion_profesor, ocupacion_grupo

    def _resolver_items_global(self, items, relaciones_info, ocupacion_profesor, ocupacion_grupo):
        if not items:
            return {}

        mejores = None
        mejor_item = None
        for item in items:
            candidatas = self._obtener_candidatas_item(item, relaciones_info, ocupacion_profesor, ocupacion_grupo)
            if not candidatas:
                return None
            if mejores is None or len(candidatas) < len(mejores):
                mejores = candidatas
                mejor_item = item

        restantes = [item for item in items if item is not mejor_item]
        for pareja in mejores:
            occ_prof = defaultdict(list, {k: list(v) for k, v in ocupacion_profesor.items()})
            occ_grupo = defaultdict(list, {k: list(v) for k, v in ocupacion_grupo.items()})
            for relacion_id in mejor_item:
                info = relaciones_info[relacion_id]
                self._aplicar_reserva_global(occ_prof, occ_grupo, info['profesor'], info['relacion'], info['grupo_key'], pareja)

            solucion = self._resolver_items_global(restantes, relaciones_info, occ_prof, occ_grupo)
            if solucion is not None:
                for relacion_id in mejor_item:
                    solucion[relacion_id] = pareja
                return solucion

        return None

    def _obtener_candidatas_item(self, item, relaciones_info, ocupacion_profesor, ocupacion_grupo):
        relaciones = [relaciones_info[item_id] for item_id in item]
        if not relaciones:
            return []

        slots_comunes = list(relaciones[0]['slots'])
        for info in relaciones[1:]:
            slots_set = set(info['slots'])
            slots_comunes = [slot for slot in slots_comunes if slot in slots_set]

        candidatas = []
        for idx, slot_a in enumerate(slots_comunes):
            for slot_b in slots_comunes[idx + 1:]:
                if slot_a[0] == slot_b[0]:
                    continue
                if self._pareja_valida_item(relaciones, slot_a, slot_b, ocupacion_profesor, ocupacion_grupo):
                    candidatas.append([slot_a, slot_b])

        return candidatas

    def _pareja_valida_item(self, relaciones, slot_a, slot_b, ocupacion_profesor, ocupacion_grupo):
        for slot in (slot_a, slot_b):
            for info in relaciones:
                if not self._slot_valido_relacion(info, slot, ocupacion_profesor, ocupacion_grupo):
                    return False
        return True

    def _slot_valido_relacion(self, info, slot, ocupacion_profesor, ocupacion_grupo):
        relacion = info['relacion']
        profesor = info['profesor']
        grupo_key = info['grupo_key']

        for inicio, fin, relacion_existente in ocupacion_grupo.get((grupo_key[0], grupo_key[1], grupo_key[2], slot[0]), []):
            if relacion_existente and relacion_existente.asignatura_id == relacion.asignatura_id:
                return False
            if self.solapa(slot[1], slot[2], inicio, fin):
                if not self.puede_compartir_franja_por_especialidad(relacion, relacion_existente):
                    return False

        if self.profesor_ocupado(profesor, slot, ocupacion_profesor, relacion):
            return False
        if self.profesor_en_ausencia(profesor, slot):
            return False

        return True

    def _aplicar_reserva_global(self, ocupacion_profesor, ocupacion_grupo, profesor, relacion, grupo_key, pareja):
        for dia, inicio, fin in pareja:
            ocupacion_profesor[(profesor.dni, dia)].append(
                (inicio, fin, relacion.asignatura.id, relacion.grado.id, relacion.cuatrimestre)
            )
            ocupacion_grupo[(grupo_key[0], grupo_key[1], grupo_key[2], dia)].append(
                (inicio, fin, relacion)
            )

    @staticmethod
    def _inferir_turno_global(grado, anio, cuatrimestre):
        hora_min = (
            HorarioClase.objects.filter(
                grado=grado,
                grado_asignatura__anio=anio,
                grado_asignatura__cuatrimestre=cuatrimestre,
                activo=True,
            ).aggregate(Min('hora_inicio'))['hora_inicio__min']
        )
        if hora_min is None:
            return 'MANANA'
        return 'MANANA' if hora_min < time(15, 0) else 'TARDE'


    def generar_horario_greedy(self, programables, slots, slot_indices, ocupacion_profesor, ocupacion_grupo, grado, anio, cuatrimestre):
        """Algoritmo sencillo y determinista que asigna la primera pareja válida posible.
        Si no hay parejas válidas, elimina horarios conflictivos de otros grados para liberar franjas.
        Devuelve la lista de asignaciones (relacion, profesor, pareja) o None si imposible.
        """
        asignaciones = []
        # Hacer copia modificable de ocupaciones
        occ_prof = defaultdict(list, {k: list(v) for k, v in ocupacion_profesor.items()})
        occ_grupo = defaultdict(list, {k: list(v) for k, v in ocupacion_grupo.items()})

        for relacion, profesor in programables:
            # buscar candidatos normales
            candidatas = self.obtener_candidatas(relacion, slots, slot_indices, occ_prof, occ_grupo, profesor, ['LUNES','MARTES','MIERCOLES','JUEVES','VIERNES'])
            if not candidatas:
                es_compartida = AsignaturaProfesor.objects.filter(
                    asignatura=relacion.asignatura,
                    coincide_con_grado_relacionado=True,
                ).filter(
                    Q(grado=relacion.grado) | Q(grado_coincidente=relacion.grado)
                ).exists()
                es_doble_grado = '+' in (relacion.grado.nombre or '')

                if es_compartida and not es_doble_grado:
                    return None

                # intentar forzar borrando conflictos por cada posible pareja
                found = False
                for i, slot_a in enumerate(slots):
                    for slot_b in slots[i+1:]:
                        if slot_a[0] == slot_b[0]:
                            continue
                        if self.pareja_valida(slot_a, slot_b, profesor, occ_prof, occ_grupo, relacion):
                            pareja = [slot_a, slot_b]
                            found = True
                            break
                    if found:
                        break
                if not found:
                    return None
            else:
                pareja = candidatas[0]

            # aplicar reserva en occ_prof y occ_grupo
            for dia, inicio, fin in pareja:
                occ_prof[(profesor.dni, dia)].append(
                    (inicio, fin, relacion.asignatura.id, relacion.grado.id, relacion.cuatrimestre)
                )
                occ_grupo[dia].append((inicio, fin, relacion))

            asignaciones.append((relacion, profesor, pareja))

        return asignaciones

    def obtener_slots(self, turno):
        if turno == 'MANANA':
            return [
                ('LUNES', time(9, 0), time(11, 0)),
                ('LUNES', time(11, 0), time(13, 0)),
                ('LUNES', time(13, 0), time(15, 0)),
                ('MARTES', time(9, 0), time(11, 0)),
                ('MARTES', time(11, 0), time(13, 0)),
                ('MARTES', time(13, 0), time(15, 0)),
                ('MIERCOLES', time(9, 0), time(11, 0)),
                ('MIERCOLES', time(11, 0), time(13, 0)),
                ('MIERCOLES', time(13, 0), time(15, 0)),
                ('JUEVES', time(9, 0), time(11, 0)),
                ('JUEVES', time(11, 0), time(13, 0)),
                ('JUEVES', time(13, 0), time(15, 0)),
                ('VIERNES', time(9, 0), time(11, 0)),
                ('VIERNES', time(11, 0), time(13, 0)),
                ('VIERNES', time(13, 0), time(15, 0)),
            ]
        if turno == 'TARDE':
            return [
                ('LUNES', time(15, 30), time(17, 30)),
                ('LUNES', time(17, 30), time(19, 30)),
                ('LUNES', time(19, 30), time(21, 30)),
                ('MARTES', time(15, 30), time(17, 30)),
                ('MARTES', time(17, 30), time(19, 30)),
                ('MARTES', time(19, 30), time(21, 30)),
                ('MIERCOLES', time(15, 30), time(17, 30)),
                ('MIERCOLES', time(17, 30), time(19, 30)),
                ('MIERCOLES', time(19, 30), time(21, 30)),
                ('JUEVES', time(15, 30), time(17, 30)),
                ('JUEVES', time(17, 30), time(19, 30)),
                ('JUEVES', time(19, 30), time(21, 30)),
                ('VIERNES', time(15, 30), time(17, 30)),
                ('VIERNES', time(17, 30), time(19, 30)),
                ('VIERNES', time(19, 30), time(21, 30)),
            ]
        return []

    def obtener_profesor(self, relacion, grado):
        asignacion = AsignaturaProfesor.objects.filter(asignatura=relacion.asignatura, grado=grado).select_related('dni').first()
        if asignacion:
            return asignacion.dni

        asignacion = AsignaturaProfesor.objects.filter(
            asignatura=relacion.asignatura,
            grado__isnull=True,
        ).select_related('dni').first()
        if asignacion:
            return asignacion.dni

        asignacion = AsignaturaProfesor.objects.filter(
            asignatura=relacion.asignatura,
            coincide_con_grado_relacionado=True,
            grado_coincidente=grado,
        ).select_related('dni').first()
        if asignacion:
            return asignacion.dni
        return None

    def obtener_pareja_compartida(self, relacion, grado, anio, cuatrimestre, turno):
        asignacion_compartida = AsignaturaProfesor.objects.filter(
            asignatura=relacion.asignatura,
            coincide_con_grado_relacionado=True,
        ).filter(
            Q(grado=grado) | Q(grado_coincidente=grado)
        ).select_related('grado', 'grado_coincidente').first()

        if not asignacion_compartida:
            return None

        grado_compartido = asignacion_compartida.grado_coincidente if asignacion_compartida.grado == grado else asignacion_compartida.grado
        es_doble_grado = '+' in (grado_compartido.nombre or '')
        horarios_qs = HorarioClase.objects.filter(
            grado=grado_compartido,
            grado_asignatura__cuatrimestre=cuatrimestre,
            asignatura=relacion.asignatura,
            activo=True,
        )

        if not es_doble_grado:
            horarios_qs = horarios_qs.filter(grado_asignatura__anio=anio)

        if turno == 'MANANA':
            horarios_qs = horarios_qs.filter(hora_inicio__lt=time(15, 0))
        elif turno == 'TARDE':
            horarios_qs = horarios_qs.filter(hora_inicio__gte=time(15, 30))

        horarios_compartidos = list(horarios_qs.order_by('dia_de_la_semana', 'hora_inicio'))

        if len(horarios_compartidos) != 2:
            return None

        return [
            (horario.dia_de_la_semana, horario.hora_inicio, horario.hora_fin)
            for horario in horarios_compartidos
        ]

    def encontrar_pareja(self, relacion, slots, slot_indices, ocupacion_profesor, ocupacion_grupo, profesor, preferred_days):
        candidatas = self.obtener_candidatas(relacion, slots, slot_indices, ocupacion_profesor, ocupacion_grupo, profesor, preferred_days)
        return candidatas[0] if candidatas else None

    def obtener_candidatas(self, relacion, slots, slot_indices, ocupacion_profesor, ocupacion_grupo, profesor, preferred_days):
        candidatas = []

        turno = 'MANANA' if any(slot[1] < time(15, 0) for slot in slots) else 'TARDE'
        pareja_compartida = self.obtener_pareja_compartida(relacion, relacion.grado, relacion.anio, relacion.cuatrimestre, turno)
        # Si la asignatura es compartida, exigir una pareja exacta del grado relacionado
        # solo cuando el grado NO es doble grado.
        es_compartida = AsignaturaProfesor.objects.filter(
            asignatura=relacion.asignatura,
            coincide_con_grado_relacionado=True,
        ).filter(
            Q(grado=relacion.grado) | Q(grado_coincidente=relacion.grado)
        ).exists()
        es_doble_grado = '+' in (relacion.grado.nombre or '')

        if es_compartida and not es_doble_grado and not pareja_compartida:
            return []

        # Si existe una pareja compartida en el grado relacionado, forzar su uso exclusivamente.
        if pareja_compartida:
            # Pareja esperada de 2 franjas
            if len(pareja_compartida) == 2:
                if self.pareja_valida(pareja_compartida[0], pareja_compartida[1], profesor, ocupacion_profesor, ocupacion_grupo, relacion):
                    return [pareja_compartida]
                return []

            # Si por algún motivo hay solo una franja (caso excepcional), validar y devolverla como única candidata
            if len(pareja_compartida) == 1:
                if self.pareja_valida(pareja_compartida[0], pareja_compartida[0], profesor, ocupacion_profesor, ocupacion_grupo, relacion):
                    return [pareja_compartida]
                return []

        # Si no hay pareja compartida, buscar libremente
        for i, slot_a in enumerate(slots):
            for slot_b in slots[i + 1:]:
                if slot_a[0] == slot_b[0]:
                    continue
                if not self.pareja_valida(slot_a, slot_b, profesor, ocupacion_profesor, ocupacion_grupo, relacion):
                    continue
                puntuacion = self.puntuar_pareja(relacion, slot_a, slot_b, slot_indices, ocupacion_profesor, ocupacion_grupo, profesor, preferred_days)
                candidatas.append((puntuacion, [slot_a, slot_b]))

        candidatas.sort(key=lambda item: item[0])
        return [pareja for _, pareja in candidatas]

    def resolver_programacion(self, relaciones_programables, slots, ocupacion_profesor, ocupacion_grupo, preferred_days):
        if not relaciones_programables:
            return []

        slot_indices = {slot: index for index, slot in enumerate(slots)}
        mejor_indice = None
        mejor_relacion = None
        mejor_profesor = None
        mejores_candidatas = None

        for indice, (relacion, profesor) in enumerate(relaciones_programables):
            candidatas = self.obtener_candidatas(
                relacion,
                slots,
                slot_indices,
                ocupacion_profesor,
                ocupacion_grupo,
                profesor,
                preferred_days,
            )
            if not candidatas:
                return None

            if mejores_candidatas is None or len(candidatas) < len(mejores_candidatas):
                mejor_indice = indice
                mejor_relacion = relacion
                mejor_profesor = profesor
                mejores_candidatas = candidatas

        if mejores_candidatas is None:
            return None

        restantes = relaciones_programables[:mejor_indice] + relaciones_programables[mejor_indice + 1:]
        for pareja in mejores_candidatas:
            ocupacion_profesor_siguiente = defaultdict(list, {clave: list(valores) for clave, valores in ocupacion_profesor.items()})
            ocupacion_grupo_siguiente = defaultdict(list, {clave: list(valores) for clave, valores in ocupacion_grupo.items()})
            self.aplicar_reserva(ocupacion_profesor_siguiente, ocupacion_grupo_siguiente, mejor_profesor, mejor_relacion, pareja)

            solucion_restante = self.resolver_programacion(
                restantes,
                slots,
                ocupacion_profesor_siguiente,
                ocupacion_grupo_siguiente,
                preferred_days,
            )
            if solucion_restante is not None:
                return [(mejor_relacion, mejor_profesor, pareja)] + solucion_restante

        return None

    def aplicar_reserva(self, ocupacion_profesor, ocupacion_grupo, profesor, relacion, pareja):
        for dia, inicio, fin in pareja:
            # Guardar reserva con metadatos de asignatura y grado para permitir comprobaciones más precisas
            ocupacion_profesor[(profesor.dni, dia)].append(
                (inicio, fin, relacion.asignatura.id, relacion.grado.id, relacion.cuatrimestre)
            )
            ocupacion_grupo[dia].append((inicio, fin, relacion))

    def prioridad_relacion(self, relacion, slots, ocupacion_profesor, ocupacion_grupo, preferred_days):
        profesor = self.obtener_profesor(relacion, relacion.grado)
        if not profesor:
            return (999, relacion.asignatura.nombre)

        disponibles = 0
        for i, slot_a in enumerate(slots):
            for slot_b in slots[i + 1:]:
                if slot_a[0] == slot_b[0]:
                    continue
                if self.pareja_valida(slot_a, slot_b, profesor, ocupacion_profesor, ocupacion_grupo, relacion):
                    disponibles += 1

        return (disponibles, relacion.asignatura.nombre)

    def puntuar_pareja(self, relacion, slot_a, slot_b, slot_indices, ocupacion_profesor, ocupacion_grupo, profesor, preferred_days):
        dias = (slot_a[0], slot_b[0])
        dias_ocupados = {dia for dia, registros in ocupacion_grupo.items() if registros}
        dias_ocupados_profesor = sum(1 for dia in dias if ocupacion_profesor.get((profesor.dni, dia), []))
        usados_despues = len(dias_ocupados | set(dias))
        dias_nuevos = len(set(dias) - dias_ocupados)

        bloques_antes = self.contar_bloques_por_dia(ocupacion_grupo, slot_indices)
        bloques_despues = bloques_antes.copy()
        for dia, slot in ((slot_a[0], slot_a), (slot_b[0], slot_b)):
            bloques_despues[dia] = self.contar_bloques_dia(
                list(ocupacion_grupo.get(dia, [])) + [(slot[1], slot[2])],
                slot_indices,
            )

        fragmentacion_antes = sum(bloques_antes.values())
        fragmentacion_despues = sum(bloques_despues.values())

        preferencia_dias = sum(1 for dia in dias if dia in preferred_days)
        reutiliza_dias = sum(1 for dia in dias if dia in dias_ocupados)

        return (
            usados_despues,
            dias_ocupados_profesor,
            dias_nuevos,
            fragmentacion_despues,
            fragmentacion_despues - fragmentacion_antes,
            -reutiliza_dias,
            -preferencia_dias,
            slot_a[1],
            slot_b[1],
            relacion.asignatura.nombre,
        )

    def contar_bloques_por_dia(self, ocupacion_grupo, slot_indices):
        bloques = {}
        for dia, registros in ocupacion_grupo.items():
            bloques[dia] = self.contar_bloques_dia(registros, slot_indices)
        return bloques

    def contar_bloques_dia(self, registros, slot_indices):
        indices = sorted({indice for inicio, fin, *resto in registros for indice in [self.indice_slot(inicio, fin, slot_indices)] if indice is not None})
        if not indices:
            return 0

        bloques = 1
        for indice_anterior, indice_actual in zip(indices, indices[1:]):
            if indice_actual != indice_anterior + 1:
                bloques += 1
        return bloques

    @staticmethod
    def indice_slot(inicio, fin, slot_indices):
        for slot, indice in slot_indices.items():
            if slot[1] == inicio and slot[2] == fin:
                return indice
        return None

    def pareja_valida(self, slot_a, slot_b, profesor, ocupacion_profesor, ocupacion_grupo, relacion):
        if slot_a[0] == slot_b[0]:
            return False
        for slot in [slot_a, slot_b]:
            # Evitar que otra sesión de la misma asignatura ya exista en el mismo día
            for inicio_e, fin_e, relacion_existente in ocupacion_grupo.get(slot[0], []):
                try:
                    asign_id_exist = relacion_existente.asignatura.id if relacion_existente else None
                except Exception:
                    asign_id_exist = None
                if asign_id_exist is not None and asign_id_exist == relacion.asignatura.id:
                    return False
            if self.profesor_ocupado(profesor, slot, ocupacion_profesor, relacion):
                return False
            if self.grupo_ocupado(slot, ocupacion_grupo, relacion):
                return False
            if self.profesor_en_ausencia(profesor, slot):
                return False
        return True

    def profesor_ocupado(self, profesor, slot, ocupacion, relacion=None):
        # Las entradas en 'ocupacion' pueden ser (inicio, fin) o (inicio, fin, asignatura_id, grado_id, cuatrimestre).
        for entry in ocupacion.get((profesor.dni, slot[0]), []):
            inicio = entry[0]
            fin = entry[1]
            if not self.solapa(slot[1], slot[2], inicio, fin):
                continue

            if len(entry) >= 5 and relacion is not None:
                cuatrimestre_entry = entry[4]
                if cuatrimestre_entry and relacion.cuatrimestre and cuatrimestre_entry != relacion.cuatrimestre:
                    continue

            # Solo permitir solape si es una pareja compartida real entre grados relacionados.
            if len(entry) >= 4 and relacion is not None:
                asignatura_id = entry[2]
                grado_id_existente = entry[3]
                if asignatura_id == relacion.asignatura.id and self.es_pareja_compartida_real(relacion, grado_id_existente):
                    continue

            return True
        return False

    def es_pareja_compartida_real(self, relacion, grado_id_existente):
        return AsignaturaProfesor.objects.filter(
            asignatura=relacion.asignatura,
            coincide_con_grado_relacionado=True,
        ).filter(
            Q(grado=relacion.grado, grado_coincidente_id=grado_id_existente)
            | Q(grado_id=grado_id_existente, grado_coincidente=relacion.grado)
        ).exists()

    def grupo_ocupado(self, slot, ocupacion_grupo, relacion_actual):
        for inicio, fin, relacion_existente in ocupacion_grupo.get(slot[0], []):
            if not self.solapa(slot[1], slot[2], inicio, fin):
                continue

            if self.puede_compartir_franja_por_especialidad(relacion_actual, relacion_existente):
                continue

            return True
        return False

    @staticmethod
    def puede_compartir_franja_por_especialidad(relacion_a, relacion_b):
        if not relacion_a or not relacion_b:
            return False

        if relacion_a.grado_id != relacion_b.grado_id:
            return False

        if relacion_a.asignatura.tipo_asignatura != Asignatura.TiposAsignatura.OPTATIVA:
            return False

        if relacion_b.asignatura.tipo_asignatura != Asignatura.TiposAsignatura.OPTATIVA:
            return False

        if not relacion_a.especialidad or not relacion_b.especialidad:
            return False

        return relacion_a.especialidad != relacion_b.especialidad

    def profesor_en_ausencia(self, profesor, slot):
        es_manana = slot[1] < time(15, 0)
        es_tarde = slot[1] >= time(15, 30)

        qs = AusenciaProfesor.objects.filter(
            profesor=profesor,
            dia_de_la_semana=slot[0],
            estado=AusenciaProfesor.EstadoAusencia.APROBADA,
        )

        if qs.filter(turno=AusenciaProfesor.Turnos.TODO_EL_DIA).exists():
            return True

        if es_manana and qs.filter(turno=AusenciaProfesor.Turnos.MANANA).exists():
            return True

        if es_tarde and qs.filter(turno=AusenciaProfesor.Turnos.TARDE).exists():
            return True

        return qs.filter(
            turno=AusenciaProfesor.Turnos.PERSONALIZADO,
            hora_inicio__lt=slot[2],
            hora_fin__gt=slot[1],
        ).exists()

    @staticmethod
    def solapa(inicio_a, fin_a, inicio_b, fin_b):
        return inicio_a < fin_b and fin_a > inicio_b

    def _contar_solapes_en_bloques(self, bloques, ignore_different_specialties=False):
        total = 0
        for items in bloques.values():
            n = len(items)
            for i in range(n):
                for j in range(i + 1, n):
                    if self.solapa(items[i].hora_inicio, items[i].hora_fin, items[j].hora_inicio, items[j].hora_fin):
                        # Si ignore_different_specialties es True, no contar como solape
                        # si tienen especialidades diferentes (son grupos distintos)
                        if ignore_different_specialties:
                            spec_i = items[i].grado_asignatura.especialidad if items[i].grado_asignatura else None
                            spec_j = items[j].grado_asignatura.especialidad if items[j].grado_asignatura else None
                            if spec_i != spec_j and (spec_i or spec_j):
                                # Especialidades diferentes = grupos diferentes, no es conflicto
                                continue
                        total += 1
        return total

    def obtener_lotes_y_horarios(self, grado=None, anio=None, cuatrimestre=None):
        qs = HorarioClase.objects.exclude(lote_generacion='').select_related('asignatura', 'profesor', 'grado', 'grado_asignatura')

        if grado is not None:
            qs = qs.filter(grado=grado)
        if anio is not None:
            qs = qs.filter(grado_asignatura__anio=anio)
        if cuatrimestre is not None:
            qs = qs.filter(grado_asignatura__cuatrimestre=cuatrimestre)

        lotes = list(
            qs.values(
                'lote_generacion',
                'grado_id',
                'grado__nombre',
                'grado_asignatura__anio',
                'grado_asignatura__cuatrimestre',
            )
            .annotate(clases=Count('id'), activo=Max('activo'), ultimo_horario_id=Max('id'))
            .order_by('-ultimo_horario_id')
        )

        for lote in lotes:
            lote['id'] = lote.pop('lote_generacion')
            lote['grado_nombre'] = lote.pop('grado__nombre')
            lote['anio'] = lote.pop('grado_asignatura__anio')
            lote['cuatrimestre'] = lote.pop('grado_asignatura__cuatrimestre')

        activos_por_scope = {}
        for lote in lotes:
            scope = (lote['grado_id'], lote['anio'], lote['cuatrimestre'])
            if lote['activo']:
                activos_por_scope[scope] = activos_por_scope.get(scope, 0) + 1

        for lote in lotes:
            scope = (lote['grado_id'], lote['anio'], lote['cuatrimestre'])
            lote['puede_activar'] = lote['activo'] or activos_por_scope.get(scope, 0) == 0

        # Calcular conflictos visibles para cada lote
        self._agregar_conflictos_a_lotes(lotes, qs)

        horarios = qs.order_by('-lote_generacion', 'dia_de_la_semana', 'hora_inicio')
        return lotes, horarios

    def _agregar_conflictos_a_lotes(self, lotes, qs_horarios):
        """Agrega conflictos por ausencias y fallos de solapes a cada lote."""
        ausencias_aprobadas = AusenciaProfesor.objects.filter(
            estado=AusenciaProfesor.EstadoAusencia.APROBADA
        )
        
        # Crear caché de ausencias por profesor y día
        ausencias_por_profesor_dia = {}
        for ausencia in ausencias_aprobadas:
            key = (ausencia.profesor_id, ausencia.dia_de_la_semana)
            if key not in ausencias_por_profesor_dia:
                ausencias_por_profesor_dia[key] = []
            ausencias_por_profesor_dia[key].append(ausencia)
        
        for lote in lotes:
            lote['tiene_conflictos'] = False
            lote['conflictos_count'] = 0
            lote['tiene_fallos'] = False
            lote['fallos_count'] = 0
            lote['fallos_profesor_count'] = 0
            lote['fallos_grupo_count'] = 0
            lote['fallos_compartidos_count'] = 0
            
            # Obtener todos los horarios del lote
            horarios_lote = list(qs_horarios.filter(lote_generacion=lote['id']))
            
            for horario in horarios_lote:
                profesor_id = horario.profesor.id
                ausencias_para_este_dia = ausencias_por_profesor_dia.get((profesor_id, horario.dia_de_la_semana), [])
                cuatrimestre = horario.grado_asignatura.cuatrimestre if horario.grado_asignatura else None
                
                for ausencia in ausencias_para_este_dia:
                    if ausencia.coincide_con_horario(horario.hora_inicio, horario.hora_fin, cuatrimestre):
                        lote['tiene_conflictos'] = True
                        lote['conflictos_count'] += 1
                        break

            # Detectar fallos de solape por profesor
            bloques_profesor = defaultdict(list)
            for horario in horarios_lote:
                cuatrimestre_horario = horario.grado_asignatura.cuatrimestre if horario.grado_asignatura else None
                bloques_profesor[(horario.profesor.id, horario.dia_de_la_semana, cuatrimestre_horario)].append(horario)

            fallos_profesor = self._contar_solapes_en_bloques(bloques_profesor)

            # Detectar fallos de solape por grupo (grado, año, cuatrimestre, día)
            # Ignorar especialidades diferentes porque pertenecen a grupos distintos
            bloques_grupo = defaultdict(list)
            for horario in horarios_lote:
                anio_horario = horario.grado_asignatura.anio if horario.grado_asignatura else None
                cuatrimestre_horario = horario.grado_asignatura.cuatrimestre if horario.grado_asignatura else None
                bloques_grupo[(horario.grado_id, anio_horario, cuatrimestre_horario, horario.dia_de_la_semana)].append(horario)

            fallos_grupo = self._contar_solapes_en_bloques(bloques_grupo, ignore_different_specialties=True)

            # Detectar fallos de asignaturas compartidas (el resto se adapta al doble grado)
            fallos_compartidos = 0
            compartidos_revisados = set()
            for horario in horarios_lote:
                if '+' in (horario.grado.nombre or ''):
                    continue

                if not horario.grado_asignatura:
                    continue

                relacion_compartida = AsignaturaProfesor.objects.filter(
                    asignatura=horario.asignatura,
                    coincide_con_grado_relacionado=True,
                ).filter(
                    Q(grado=horario.grado, grado_coincidente__isnull=False)
                    | Q(grado_coincidente=horario.grado)
                ).select_related('grado', 'grado_coincidente').first()

                if not relacion_compartida:
                    continue

                grado_relacionado = (
                    relacion_compartida.grado_coincidente
                    if relacion_compartida.grado == horario.grado
                    else relacion_compartida.grado
                )

                if not grado_relacionado:
                    continue

                clave = (
                    horario.asignatura_id,
                    horario.grado_id,
                    grado_relacionado.id,
                    horario.dia_de_la_semana,
                    horario.hora_inicio,
                    horario.hora_fin,
                )
                if clave in compartidos_revisados:
                    continue

                compartidos_revisados.add(clave)
                es_doble_grado_rel = '+' in (grado_relacionado.nombre or '')
                horarios_rel_qs = qs_horarios.filter(
                    grado=grado_relacionado,
                    asignatura=horario.asignatura,
                    grado_asignatura__cuatrimestre=horario.grado_asignatura.cuatrimestre,
                    activo=True,
                )

                if not es_doble_grado_rel:
                    horarios_rel_qs = horarios_rel_qs.filter(grado_asignatura__anio=horario.grado_asignatura.anio)

                if horario.hora_inicio < time(15, 0):
                    horarios_rel_qs = horarios_rel_qs.filter(hora_inicio__lt=time(15, 0))
                else:
                    horarios_rel_qs = horarios_rel_qs.filter(hora_inicio__gte=time(15, 30))

                coincide = horarios_rel_qs.filter(
                    dia_de_la_semana=horario.dia_de_la_semana,
                    hora_inicio=horario.hora_inicio,
                    hora_fin=horario.hora_fin,
                ).exists()

                if not coincide:
                    fallos_compartidos += 1

            lote['fallos_profesor_count'] = fallos_profesor
            lote['fallos_grupo_count'] = fallos_grupo
            lote['fallos_compartidos_count'] = fallos_compartidos
            lote['fallos_count'] = fallos_profesor + fallos_grupo + fallos_compartidos
            lote['tiene_fallos'] = lote['fallos_count'] > 0


class GenerarTodoHorarioView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, *args, **kwargs):
        generador = GenerarHorarioView()
        generador.request = request

        resultado_c1 = generador.generar_horarios_globales(cuatrimestre='1')
        resultado_c2 = generador.generar_horarios_globales(cuatrimestre='2')

        request.session['resultado_generacion_masiva'] = {
            'generados': resultado_c1.get('generados', 0) + resultado_c2.get('generados', 0),
            'procesados': resultado_c1.get('procesados', 0) + resultado_c2.get('procesados', 0),
            'omitidos': resultado_c1.get('omitidos', 0) + resultado_c2.get('omitidos', 0),
            'lotes': (resultado_c1.get('lotes', []) + resultado_c2.get('lotes', [])),
            'advertencias': (resultado_c1.get('advertencias', []) + resultado_c2.get('advertencias', [])),
        }

        return redirect('horarios:admin_horario_generar')


class ActivarLoteHorarioView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request):
        grado_id = request.POST.get('grado_id')
        anio = request.POST.get('anio')
        cuatrimestre = request.POST.get('cuatrimestre')
        lote_id = request.POST.get('lote_id')

        if not (grado_id and anio and cuatrimestre and lote_id):
            return redirect('horarios:admin_horario_generar')

        redirect_url = f"{reverse_lazy('horarios:admin_horario_generar')}?cuatrimestre_tabla=todos"

        qs = HorarioClase.objects.filter(
            grado_id=grado_id,
            grado_asignatura__anio=anio,
            grado_asignatura__cuatrimestre=cuatrimestre,
        ).exclude(lote_generacion='')

        if qs.filter(lote_generacion=lote_id, activo=True).exists():
            return redirect(f'{redirect_url}&estado_lote=ya_activo')

        if qs.exclude(lote_generacion=lote_id).filter(activo=True).exists():
            return redirect(f'{redirect_url}&estado_lote=otro_activo')

        qs.filter(lote_generacion=lote_id).update(activo=True)

        return redirect(f'{redirect_url}&estado_lote=activado')


class DesactivarLoteHorarioView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request):
        grado_id = request.POST.get('grado_id')
        anio = request.POST.get('anio')
        cuatrimestre = request.POST.get('cuatrimestre')
        lote_id = request.POST.get('lote_id')

        if not (grado_id and anio and cuatrimestre and lote_id):
            return redirect('horarios:admin_horario_generar')

        redirect_url = f"{reverse_lazy('horarios:admin_horario_generar')}?cuatrimestre_tabla=todos"

        qs = HorarioClase.objects.filter(
            grado_id=grado_id,
            grado_asignatura__anio=anio,
            grado_asignatura__cuatrimestre=cuatrimestre,
            lote_generacion=lote_id,
        ).exclude(lote_generacion='')

        if not qs.filter(activo=True).exists():
            return redirect(f'{redirect_url}&estado_lote=ya_inactivo')

        qs.update(activo=False)

        return redirect(f'{redirect_url}&estado_lote=desactivado')


class EliminarLoteHorarioView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request):
        grado_id = request.POST.get('grado_id')
        anio = request.POST.get('anio')
        cuatrimestre = request.POST.get('cuatrimestre')
        lote_id = request.POST.get('lote_id')

        if not (grado_id and anio and cuatrimestre and lote_id):
            return redirect('horarios:admin_horario_generar')

        HorarioClase.objects.filter(
            grado_id=grado_id,
            grado_asignatura__anio=anio,
            grado_asignatura__cuatrimestre=cuatrimestre,
            lote_generacion=lote_id,
        ).delete()

        return redirect(f"{reverse_lazy('horarios:admin_horario_generar')}?cuatrimestre_tabla=todos&estado_lote=eliminado")


class EditarLoteHorariosView(RolRequiredMixin, TemplateView):
    rol_requerido = 'admin'
    template_name = 'horarios/editar_lote_horarios.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        lote_id = self.kwargs.get('lote_id')
        context['lote_id'] = lote_id
        
        # Obtener todos los horarios del lote
        horarios = HorarioClase.objects.filter(
            lote_generacion=lote_id
        ).select_related(
            'grado', 'asignatura', 'profesor', 'grado_asignatura'
        ).order_by('dia_de_la_semana', 'hora_inicio')
        
        if not horarios.exists():
            context['sin_horarios'] = True
            return context
        
        primer_horario = horarios.first()
        context['lote_grado'] = primer_horario.grado.nombre
        context['lote_anio'] = primer_horario.grado_asignatura.anio if primer_horario.grado_asignatura else '-'
        context['lote_cuatrimestre'] = primer_horario.grado_asignatura.cuatrimestre if primer_horario.grado_asignatura else '-'
        
        # Construir matriz de horarios
        day_to_key = {
            'LUNES': 'l',
            'MARTES': 'm',
            'MIERCOLES': 'x',
            'JUEVES': 'j',
            'VIERNES': 'v',
        }
        
        day_order = ['LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES']
        
        horarios_por_dia_hora = {}
        for horario in horarios:
            key = (horario.dia_de_la_semana, horario.hora_inicio, horario.hora_fin)
            horarios_por_dia_hora[key] = horario
        
        # Obtener franja horaria única
        horas = sorted(set((h.hora_inicio, h.hora_fin) for h in horarios))
        
        # Construir matriz
        matriz = []
        for hora_inicio, hora_fin in horas:
            fila = {
                'hora': f"{hora_inicio.strftime('%H:%M')} - {hora_fin.strftime('%H:%M')}",
                'hora_inicio': hora_inicio.strftime('%H:%M'),
                'hora_fin': hora_fin.strftime('%H:%M'),
                'horarios': {}
            }
            for dia in day_order:
                key = (dia, hora_inicio, hora_fin)
                if key in horarios_por_dia_hora:
                    horario = horarios_por_dia_hora[key]
                    fila['horarios'][dia] = {
                        'id': horario.pk,
                        'asignatura': horario.asignatura.nombre,
                        'profesor': horario.profesor.nombre,
                        'especialidad': horario.grado_asignatura.especialidad if horario.grado_asignatura else None,
                        'aula': horario.aula,
                    }
                else:
                    fila['horarios'][dia] = None
            matriz.append(fila)
        
        context['matriz'] = matriz
        context['dias'] = day_order
        context['horarios_dict'] = {h.pk: h for h in horarios}
        
        return context


class IntercambiarHorariosView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def _aplicar_movimiento(self, horario1_id, target_dia, target_hora_inicio, target_hora_fin, lote_id=None):
        if not horario1_id:
            raise ValueError('Debes seleccionar una clase para mover.')

        horario1 = get_object_or_404(HorarioClase.objects.select_for_update(), pk=horario1_id)

        if lote_id and horario1.lote_generacion != lote_id:
            raise ValueError('La clase seleccionada no pertenece al lote.')

        if not (target_dia and target_hora_inicio and target_hora_fin):
            raise ValueError('Debes elegir un hueco destino valido.')

        try:
            hora_inicio_destino = datetime.strptime(target_hora_inicio, '%H:%M').time()
            hora_fin_destino = datetime.strptime(target_hora_fin, '%H:%M').time()
        except (TypeError, ValueError):
            raise ValueError('Formato de hora invalido.')

        if (
            horario1.dia_de_la_semana == target_dia
            and horario1.hora_inicio == hora_inicio_destino
            and horario1.hora_fin == hora_fin_destino
        ):
            return 'La clase ya estaba en ese hueco.'

        filtros_destino = {
            'dia_de_la_semana': target_dia,
            'hora_inicio': hora_inicio_destino,
            'hora_fin': hora_fin_destino,
        }
        if lote_id:
            filtros_destino['lote_generacion'] = lote_id

        horario_destino = (
            HorarioClase.objects.select_for_update()
            .filter(**filtros_destino)
            .exclude(pk=horario1.pk)
            .first()
        )

        origen_1 = (horario1.dia_de_la_semana, horario1.hora_inicio, horario1.hora_fin)

        if horario_destino:
            estado_original_destino = horario_destino.activo
            if horario_destino.activo:
                horario_destino.activo = False
                horario_destino.save(update_fields=['activo'])

            horario1.dia_de_la_semana = target_dia
            horario1.hora_inicio = hora_inicio_destino
            horario1.hora_fin = hora_fin_destino
            horario1.save(update_fields=['dia_de_la_semana', 'hora_inicio', 'hora_fin'])

            horario_destino.dia_de_la_semana, horario_destino.hora_inicio, horario_destino.hora_fin = origen_1
            horario_destino.activo = estado_original_destino
            horario_destino.save(update_fields=['dia_de_la_semana', 'hora_inicio', 'hora_fin', 'activo'])

            return 'Hueco ocupado: clases intercambiadas correctamente.'

        horario1.dia_de_la_semana = target_dia
        horario1.hora_inicio = hora_inicio_destino
        horario1.hora_fin = hora_fin_destino
        horario1.save(update_fields=['dia_de_la_semana', 'hora_inicio', 'hora_fin'])

        return 'Clase movida correctamente al nuevo hueco.'
    
    def post(self, request):
        import json
        
        try:
            data = json.loads(request.body)
            lote_id = data.get('lote_id')
            cambios = data.get('cambios')

            # Nuevo flujo: guardar todos los cambios al final
            if isinstance(cambios, list):
                if not cambios:
                    return JsonResponse({'success': False, 'error': 'No hay cambios para guardar.'}, status=400)

                with transaction.atomic():
                    for cambio in cambios:
                        self._aplicar_movimiento(
                            horario1_id=cambio.get('horario1_id'),
                            target_dia=cambio.get('target_dia'),
                            target_hora_inicio=cambio.get('target_hora_inicio'),
                            target_hora_fin=cambio.get('target_hora_fin'),
                            lote_id=lote_id or cambio.get('lote_id'),
                        )

                return JsonResponse({'success': True, 'message': f'{len(cambios)} cambio(s) guardado(s) correctamente.'})

            # Compatibilidad con guardado individual
            mensaje = self._aplicar_movimiento(
                horario1_id=data.get('horario1_id'),
                target_dia=data.get('target_dia'),
                target_hora_inicio=data.get('target_hora_inicio'),
                target_hora_fin=data.get('target_hora_fin'),
                lote_id=lote_id,
            )

            return JsonResponse({'success': True, 'message': mensaje})
        except ValueError as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400)
        except Exception as e:
            return JsonResponse({'success': False, 'error': f'Error al guardar cambios: {str(e)}'}, status=400)


class GradoListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = Grado
    template_name = 'horarios/grado_lista.html'
    context_object_name = 'grados'
    paginate_by = 6

    def get_queryset(self):
        queryset = Grado.objects.all().order_by('nombre')
        search_query = self.request.GET.get('q', '').strip()
        if search_query:
            queryset = queryset.filter(nombre__icontains=search_query)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        grados_query = self.get_queryset()
        context['search_query'] = self.request.GET.get('q', '').strip()
        context['total_grados'] = grados_query.count()

        page_obj = context.get('page_obj')
        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        return context
    paginate_by = 6

    def get_queryset(self):
        queryset = Grado.objects.all().order_by('nombre')
        search_query = self.request.GET.get('q', '').strip()
        if search_query:
            queryset = queryset.filter(nombre__icontains=search_query)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        grados_query = self.get_queryset()
        context['search_query'] = self.request.GET.get('q', '').strip()
        context['total_grados'] = grados_query.count()

        page_obj = context.get('page_obj')
        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        return context


class GradoCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'admin'
    model = Grado
    fields = ['nombre']
    template_name = 'horarios/formulario_generico.html'
    success_url = reverse_lazy('horarios:admin_grados')


class GradoUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'admin'
    model = Grado
    fields = ['nombre']
    template_name = 'horarios/formulario_generico.html'
    success_url = reverse_lazy('horarios:admin_grados')


class GradoDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        grado = get_object_or_404(Grado, pk=pk)
        grado.delete()
        return redirect('horarios:admin_grados')


class AsignaturaListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = Asignatura
    template_name = 'horarios/asignatura_lista.html'
    context_object_name = 'asignaturas'
    paginate_by = 6

    def get_queryset(self):
        queryset = Asignatura.objects.all().order_by('nombre')
        search_query = self.request.GET.get('q', '').strip()
        if search_query:
            queryset = queryset.filter(nombre__icontains=search_query)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        asignaturas_query = self.get_queryset()
        context['search_query'] = self.request.GET.get('q', '').strip()
        context['total_asignaturas'] = asignaturas_query.count()
        page_obj = context.get('page_obj')

        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        return context


class AsignaturaCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'admin'
    model = Asignatura
    form_class = AsignaturaForm
    template_name = 'horarios/asignatura_formulario.html'
    success_url = reverse_lazy('horarios:admin_asignaturas')


class AsignaturaUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'admin'
    model = Asignatura
    form_class = AsignaturaForm
    template_name = 'horarios/asignatura_formulario.html'
    success_url = reverse_lazy('horarios:admin_asignaturas')


class AsignaturaDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        asignatura = get_object_or_404(Asignatura, pk=pk)
        asignatura.delete()
        return redirect('horarios:admin_asignaturas')


class ProfesorListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = Profesor
    template_name = 'horarios/profesor_lista.html'
    context_object_name = 'profesores'
    paginate_by = 6

    def get_queryset(self):
        queryset = Profesor.objects.all().order_by('nombre')
        search_query = self.request.GET.get('q', '').strip()
        if search_query:
            queryset = queryset.filter(Q(nombre__icontains=search_query) | Q(dni__icontains=search_query))
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profesores_query = self.get_queryset()
        context['search_query'] = self.request.GET.get('q', '').strip()
        context['total_profesores'] = profesores_query.count()
        context['profesores_indefinidos'] = profesores_query.filter(contrato_indefinido=True).count()
        context['profesores_temporales'] = profesores_query.filter(contrato_indefinido=False).count()

        page_obj = context.get('page_obj')
        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        return context


class ProfesorCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'admin'
    model = Profesor
    form_class = ProfesorForm
    template_name = 'horarios/profesor_formulario.html'
    success_url = reverse_lazy('horarios:admin_profesores')


class ProfesorUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'admin'
    model = Profesor
    form_class = ProfesorForm
    template_name = 'horarios/profesor_formulario.html'
    success_url = reverse_lazy('horarios:admin_profesores')


class ProfesorDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        profesor = get_object_or_404(Profesor, pk=pk)
        profesor.delete()
        return redirect('horarios:admin_profesores')


class GradoSuggestionsView(SugerenciasBusquedaView):
    modelo = Grado


class AsignaturaSuggestionsView(SugerenciasBusquedaView):
    modelo = Asignatura


class ProfesorSuggestionsView(SugerenciasBusquedaView):
    modelo = Profesor


class HorarioAdminListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = HorarioClase
    template_name = 'horarios/horario_admin_lista.html'
    context_object_name = 'horarios'


class HorarioAdminCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'admin'
    model = HorarioClase
    fields = ['grado', 'asignatura', 'profesor', 'dia_de_la_semana', 'hora_inicio', 'hora_fin', 'aula', 'activo']
    template_name = 'horarios/formulario_generico.html'
    success_url = reverse_lazy('horarios:admin_horarios')


class HorarioAdminUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'admin'
    model = HorarioClase
    fields = ['grado', 'asignatura', 'profesor', 'dia_de_la_semana', 'hora_inicio', 'hora_fin', 'aula', 'activo']
    template_name = 'horarios/formulario_generico.html'
    success_url = reverse_lazy('horarios:admin_horarios')


class HorarioAdminDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        horario = get_object_or_404(HorarioClase, pk=pk)
        horario.delete()
        return redirect('horarios:admin_horarios')


class GradoAsignaturaListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = GradoAsignatura
    template_name = 'horarios/grado_asignatura_lista.html'
    context_object_name = 'relaciones'
    paginate_by = 6

    def get_queryset(self):
        queryset = GradoAsignatura.objects.select_related('grado', 'asignatura').order_by('grado__nombre', 'anio', 'cuatrimestre', 'asignatura__nombre')

        grado_id = self.request.GET.get('grado', '').strip()
        anio = self.request.GET.get('anio', '').strip()
        cuatrimestre = self.request.GET.get('cuatrimestre', '').strip()
        turno = self.request.GET.get('turno', '').strip()

        if grado_id:
            queryset = queryset.filter(grado_id=grado_id)

        if anio:
            queryset = queryset.filter(anio=anio)

        if cuatrimestre:
            queryset = queryset.filter(cuatrimestre=cuatrimestre)

        if turno == 'MANANA':
            queryset = queryset.filter(
                horarios__hora_inicio__lt=time(15, 0),
                horarios__hora_fin__gt=time(9, 0),
            )
        elif turno == 'TARDE':
            queryset = queryset.filter(
                horarios__hora_inicio__lt=time(21, 30),
                horarios__hora_fin__gt=time(15, 30),
            )

        return queryset.distinct()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        relaciones_query = self.get_queryset()

        context['filtro_grado'] = self.request.GET.get('grado', '').strip()
        context['filtro_anio'] = self.request.GET.get('anio', '').strip()
        context['filtro_cuatrimestre'] = self.request.GET.get('cuatrimestre', '').strip()
        context['filtro_turno'] = self.request.GET.get('turno', '').strip()

        context['grados_disponibles'] = Grado.objects.order_by('nombre')
        context['anios_disponibles'] = [1, 2, 3, 4, 5]
        context['cuatrimestres_disponibles'] = GradoAsignatura.Cuatrimestres.choices
        context['total_relaciones_filtradas'] = relaciones_query.count()

        page_obj = context.get('page_obj')
        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        return context


class GradoAsignaturaCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'admin'
    model = GradoAsignatura
    form_class = GradoAsignaturaForm
    template_name = 'horarios/grado_asignatura_formulario.html'
    success_url = reverse_lazy('horarios:admin_grado_asignaturas')


class GradoAsignaturaUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'admin'
    model = GradoAsignatura
    form_class = GradoAsignaturaForm
    template_name = 'horarios/grado_asignatura_formulario.html'
    success_url = reverse_lazy('horarios:admin_grado_asignaturas')


class AsignaturasDisponiblesPorGradoView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def get(self, request, grado_id):
        asignatura_actual_id = request.GET.get('actual')
        usadas = GradoAsignatura.objects.filter(grado_id=grado_id).values_list('asignatura_id', flat=True)
        queryset = Asignatura.objects.exclude(id__in=usadas)
        if asignatura_actual_id:
            queryset = (Asignatura.objects.filter(id=asignatura_actual_id) | queryset).distinct()

        data = [
            {
                'id': asignatura.id,
                'nombre': asignatura.nombre,
                'tipo_asignatura': asignatura.tipo_asignatura,
            }
            for asignatura in queryset.order_by('nombre')
        ]
        return JsonResponse({'asignaturas': data})


class GradoAsignaturaDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        relacion = get_object_or_404(GradoAsignatura, pk=pk)
        relacion.delete()
        return redirect('horarios:admin_grado_asignaturas')


class AsignaturaProfesorListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = AsignaturaProfesor
    template_name = 'horarios/asignatura_profesor_lista.html'
    context_object_name = 'relaciones'
    paginate_by = 6

    def get_queryset(self):
        queryset = AsignaturaProfesor.objects.select_related('dni', 'asignatura', 'grado', 'grado_coincidente').order_by('dni__nombre', 'asignatura__nombre')
        search_query = self.request.GET.get('q', '').strip()
        if search_query:
            queryset = queryset.filter(
                Q(dni__nombre__icontains=search_query)
                | Q(asignatura__nombre__icontains=search_query)
                | Q(grado__nombre__icontains=search_query)
                | Q(grado_coincidente__nombre__icontains=search_query)
            )
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        relaciones_query = self.get_queryset()
        context['search_query'] = self.request.GET.get('q', '').strip()
        context['total_relaciones'] = relaciones_query.count()
        context['profesores_relacionados'] = relaciones_query.values_list('dni__nombre', flat=True).distinct().count()
        context['asignaturas_relacionadas'] = relaciones_query.values_list('asignatura__nombre', flat=True).distinct().count()

        page_obj = context.get('page_obj')
        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        return context


class AsignaturaProfesorCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'admin'
    model = AsignaturaProfesor
    form_class = AsignaturaProfesorForm
    template_name = 'horarios/asignatura_profesor_formulario.html'
    success_url = reverse_lazy('horarios:admin_asignatura_profesores')


class AsignaturaProfesorUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'admin'
    model = AsignaturaProfesor
    form_class = AsignaturaProfesorForm
    template_name = 'horarios/asignatura_profesor_formulario.html'
    success_url = reverse_lazy('horarios:admin_asignatura_profesores')


class AsignaturaProfesorSuggestionsView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def get(self, request, *args, **kwargs):
        termino = request.GET.get('q', '').strip()
        sugerencias = []

        profesores = Profesor.objects.all().order_by('nombre')
        asignaturas = Asignatura.objects.all().order_by('nombre')
        grados = Grado.objects.all().order_by('nombre')

        if termino:
            profesores = profesores.filter(nombre__icontains=termino)
            asignaturas = asignaturas.filter(nombre__icontains=termino)
            grados = grados.filter(nombre__icontains=termino)

        sugerencias.extend(list(profesores.values_list('nombre', flat=True)[:3]))
        sugerencias.extend(list(asignaturas.values_list('nombre', flat=True)[:3]))
        sugerencias.extend(list(grados.values_list('nombre', flat=True)[:2]))

        vistos = []
        for sugerencia in sugerencias:
            if sugerencia not in vistos:
                vistos.append(sugerencia)

        return JsonResponse({'results': vistos[:8]})


class GradosDisponiblesPorAsignaturaView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def get(self, request, asignatura_id):
        relacion_actual_id = request.GET.get('actual_relacion')

        grados_ids = list(GradoAsignatura.objects.filter(asignatura_id=asignatura_id).values_list('grado_id', flat=True).distinct())
        total_grados = len(grados_ids)

        if total_grados <= 1:
            return JsonResponse({'requiere_grado': False, 'grados': []})

        relaciones = AsignaturaProfesor.objects.filter(asignatura_id=asignatura_id)
        if relacion_actual_id:
            relaciones = relaciones.exclude(pk=relacion_actual_id)

        grados_asignados = set(relaciones.exclude(grado__isnull=True).values_list('grado_id', flat=True))
        disponibles_ids = [grado_id for grado_id in grados_ids if grado_id not in grados_asignados]

        grado_actual = None
        if relacion_actual_id:
            try:
                grado_actual = AsignaturaProfesor.objects.values_list('grado_id', flat=True).get(pk=relacion_actual_id)
            except AsignaturaProfesor.DoesNotExist:
                grado_actual = None
            if grado_actual:
                disponibles_ids.append(grado_actual)

        grados = Grado.objects.filter(id__in=set(disponibles_ids)).order_by('nombre')
        data = [{'id': grado.id, 'nombre': grado.nombre} for grado in grados]
        return JsonResponse({'requiere_grado': True, 'grados': data})


class GradosCoincidentesPorAsignaturaView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def get(self, request, asignatura_id, grado_id):
        grados = Grado.objects.filter(
            id__in=GradoAsignatura.objects.filter(asignatura_id=asignatura_id).exclude(grado_id=grado_id).values_list('grado_id', flat=True)
        ).order_by('nombre')
        data = [{'id': grado.id, 'nombre': grado.nombre} for grado in grados]
        return JsonResponse({'grados': data})


class AsignaturaProfesorDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        relacion = get_object_or_404(AsignaturaProfesor, pk=pk)
        relacion.delete()
        return redirect('horarios:admin_asignatura_profesores')


class AlumnoHorarioListView(RolRequiredMixin, ListView):
    rol_requerido = 'alumno'
    model = HorarioClase
    template_name = 'horarios/alumno_horarios.html'
    context_object_name = 'horarios'

    def get_queryset(self):
        return HorarioClase.objects.filter(activo=True).select_related('grado', 'asignatura', 'profesor')


class ProfesorHorarioListView(RolRequiredMixin, TemplateView):
    rol_requerido = 'profesor'
    template_name = 'horarios/profesor_horarios.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        perfil = self.request.user.perfilusuario
        
        if not perfil.profesor:
            context['horarios'] = []
            context['horarios_por_grupo'] = []
            context['cuatrimestres'] = [('1', '1º'), ('2', '2º')]
            context['cuatrimestre'] = '1'
            return context

        # Obtener el cuatrimestre del filtro o la preferencia guardada
        cuatrimestre = self.request.GET.get('cuatrimestre')
        if cuatrimestre:
            # Guardar preferencia en BD si el usuario selecciona explícitamente
            perfil.cuatrimestre_profesor_preferido = cuatrimestre
            perfil.save(update_fields=['cuatrimestre_profesor_preferido'])
        else:
            # Usar la preferencia guardada o por defecto el cuatrimestre 1º
            cuatrimestre = perfil.cuatrimestre_profesor_preferido or '1'

        # Obtener todos los horarios del profesor y filtrar por cuatrimestre en Python
        horarios = HorarioClase.objects.filter(
            profesor=perfil.profesor,
            activo=True
        ).select_related('grado', 'asignatura', 'profesor', 'grado_asignatura').order_by(
            'dia_de_la_semana', 'hora_inicio'
        )

        # Filtrar por cuatrimestre si grado_asignatura existe
        horarios = [h for h in horarios if h.grado_asignatura and h.grado_asignatura.cuatrimestre == cuatrimestre]

        day_to_key = {
            'LUNES': 'l',
            'MARTES': 'm',
            'MIERCOLES': 'x',
            'JUEVES': 'j',
            'VIERNES': 'v',
        }

        # Construir matriz semanal
        rows = {}
        for horario in horarios:
            row_key = (horario.hora_inicio, horario.hora_fin)
            if row_key not in rows:
                rows[row_key] = {
                    'hora': f"{horario.hora_inicio.strftime('%H:%M')} - {horario.hora_fin.strftime('%H:%M')}",
                    'l': [],
                    'm': [],
                    'x': [],
                    'j': [],
                    'v': [],
                }

            day_key = day_to_key.get(horario.dia_de_la_semana)
            if day_key:
                relacion = horario.grado_asignatura
                especialidad = relacion.especialidad if relacion else None
                if especialidad == 'TI':
                    especialidad_abreviada = 'IT'
                elif especialidad == 'IS':
                    especialidad_abreviada = 'IS'
                else:
                    especialidad_abreviada = ''

                rows[row_key][day_key].append({
                    'asignatura': horario.asignatura.nombre,
                    'grado': horario.grado.nombre,
                    'aula': horario.aula,
                    'especialidad_abreviada': especialidad_abreviada,
                    'texto': (
                        f"{horario.asignatura.nombre} [{especialidad_abreviada}] ({horario.grado.nombre})"
                        if especialidad_abreviada
                        else f"{horario.asignatura.nombre} ({horario.grado.nombre})"
                    ),
                    'dia_semana': horario.get_dia_de_la_semana_display(),
                    'horario_id': horario.id,
                })

        matriz = [rows[key] for key in sorted(rows.keys())]
        cuatrimestre_label = dict(GradoAsignatura.Cuatrimestres.choices).get(cuatrimestre, cuatrimestre)
        horarios_por_grupo = [{
            'titulo': f'Mi horario - {cuatrimestre_label} cuatrimestre',
            'matriz': matriz,
        }] if matriz else []
        
        context['horarios'] = horarios
        context['matriz'] = matriz
        context['horarios_por_grupo'] = horarios_por_grupo
        context['cuatrimestre'] = cuatrimestre
        context['cuatrimestres'] = [('1', '1º'), ('2', '2º')]
        
        return context


class SolicitudProfesorCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'profesor'
    form_class = SolicitudCambioProfesorForm
    template_name = 'horarios/solicitud_formulario.html'
    success_url = reverse_lazy('horarios:profesor_horarios')

    def dispatch(self, request, *args, **kwargs):
        self.horario = get_object_or_404(HorarioClase, pk=kwargs['horario_id'])
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        perfil = self.request.user.perfilusuario
        if not perfil.profesor:
            form.add_error(None, 'Tu usuario no está vinculado a un profesor.')
            return self.form_invalid(form)
        solicitud = form.save(commit=False)
        solicitud.profesor = perfil.profesor
        solicitud.horario = self.horario
        solicitud.save()
        self.object = solicitud
        return redirect(self.success_url)


class SolicitudAdminListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    template_name = 'horarios/solicitudes_admin.html'
    context_object_name = 'profesores'
    paginate_by = 6

    def get_queryset(self):
        queryset = Profesor.objects.all().order_by('nombre')
        search_query = self.request.GET.get('q', '').strip()
        if search_query:
            queryset = queryset.filter(Q(nombre__icontains=search_query) | Q(dni__icontains=search_query))
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profesores = list(context['profesores'])
        ultimo_login_admin = self.request.user.last_login
        profesor_id = self.request.GET.get('profesor')
        context['search_query'] = self.request.GET.get('q', '').strip()
        filtered_queryset = self.get_queryset()

        profesores_info = []
        for profesor in profesores:
            ausencias_profesor = AusenciaProfesor.objects.filter(profesor=profesor)
            pendientes = ausencias_profesor.filter(estado=AusenciaProfesor.EstadoAusencia.PENDIENTE)
            nuevas_pendientes = pendientes
            if ultimo_login_admin:
                nuevas_pendientes = pendientes.filter(creada_en__gt=ultimo_login_admin)
            profesores_info.append({
                'profesor': profesor,
                'pendientes': pendientes.count(),
                'nuevas_pendientes': nuevas_pendientes.count(),
            })

        profesor_seleccionado = None
        if profesor_id:
            profesor_seleccionado = filtered_queryset.filter(pk=profesor_id).first()
        elif profesores:
            profesor_seleccionado = profesores[0]

        context['profesor_seleccionado'] = profesor_seleccionado
        context['profesores_info'] = profesores_info
        context['ultimo_login_admin'] = ultimo_login_admin

        if profesor_seleccionado:
            ausencias = list(
                AusenciaProfesor.objects.filter(profesor=profesor_seleccionado).order_by('estado', 'dia_de_la_semana', 'turno', 'hora_inicio')
            )
            for ausencia in ausencias:
                if ultimo_login_admin and ausencia.creada_en:
                    ausencia.es_nueva_desde_ultimo_login = (
                        ausencia.creada_en > ultimo_login_admin
                        and ausencia.estado == AusenciaProfesor.EstadoAusencia.PENDIENTE
                    )
                else:
                    ausencia.es_nueva_desde_ultimo_login = ausencia.estado == AusenciaProfesor.EstadoAusencia.PENDIENTE
            context['ausencias'] = ausencias
        else:
            context['ausencias'] = []

        page_obj = context.get('page_obj')
        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        context['total_profesores_filtrados'] = filtered_queryset.count()
        pendientes_qs = AusenciaProfesor.objects.filter(
            profesor__in=filtered_queryset,
            estado=AusenciaProfesor.EstadoAusencia.PENDIENTE,
        )
        context['total_pendientes_filtradas'] = pendientes_qs.count()

        pendientes_por_profesor = {
            profesor_id_val: total
            for profesor_id_val, total in pendientes_qs.values_list('profesor_id').annotate(total=Count('id'))
        }
        profesores_con_pendientes = []
        for profesor in filtered_queryset:
            total = pendientes_por_profesor.get(profesor.id, 0)
            if total:
                profesores_con_pendientes.append({'profesor': profesor, 'pendientes': total})

        profesores_con_pendientes.sort(key=lambda item: (-item['pendientes'], item['profesor'].nombre.lower()))
        context['profesores_con_pendientes'] = profesores_con_pendientes

        try:
            pendiente_idx = int(self.request.GET.get('pendiente_idx', '0'))
        except ValueError:
            pendiente_idx = 0

        total_pendientes_profesores = len(profesores_con_pendientes)
        if total_pendientes_profesores > 0:
            pendiente_idx = max(0, min(pendiente_idx, total_pendientes_profesores - 1))
            context['pendiente_actual'] = profesores_con_pendientes[pendiente_idx]
        else:
            pendiente_idx = 0
            context['pendiente_actual'] = None

        context['pendiente_idx'] = pendiente_idx
        context['total_profesores_con_pendientes'] = total_pendientes_profesores
        return context


class AusenciaProfesorCambiarEstadoView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk, estado):
        ausencia = get_object_or_404(AusenciaProfesor, pk=pk)
        if estado in AusenciaProfesor.EstadoAusencia.values:
            ausencia.estado = estado
            ausencia.save(update_fields=['estado'])
        return redirect(f"{reverse_lazy('horarios:admin_solicitudes')}?profesor={ausencia.profesor_id}")


class SolicitudCambiarEstadoView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, solicitud_id, estado):
        solicitud = get_object_or_404(SolicitudCambioProfesor, pk=solicitud_id)
        if estado in ['APROBADA', 'RECHAZADA']:
            solicitud.estado = estado
            solicitud.save(update_fields=['estado'])
        return redirect('horarios:admin_solicitudes')


class SolicitudDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, solicitud_id):
        solicitud = get_object_or_404(SolicitudCambioProfesor, pk=solicitud_id)
        solicitud.delete()
        return redirect('horarios:admin_solicitudes')


class AusenciaProfesorListView(RolRequiredMixin, ListView):
    rol_requerido = 'profesor'
    model = AusenciaProfesor
    template_name = 'horarios/ausencia_profesor_lista.html'
    context_object_name = 'ausencias'
    paginate_by = 6

    def get_queryset(self):
        perfil = self.request.user.perfilusuario
        if perfil.profesor:
            queryset = AusenciaProfesor.objects.filter(profesor=perfil.profesor).order_by('estado', 'dia_de_la_semana', 'turno', 'hora_inicio')

            search_query = self.request.GET.get('q', '').strip()
            estado_filter = self.request.GET.get('estado', '').strip().upper()

            if search_query:
                queryset = queryset.filter(
                    Q(dia_de_la_semana__icontains=search_query)
                    | Q(turno__icontains=search_query)
                    | Q(estado__icontains=search_query)
                )

            if estado_filter in {'PENDIENTE', 'APROBADA', 'RECHAZADA'}:
                queryset = queryset.filter(estado=estado_filter)

            return queryset
        return AusenciaProfesor.objects.none()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        perfil = self.request.user.perfilusuario
        base_queryset = AusenciaProfesor.objects.none()
        if perfil.profesor:
            base_queryset = AusenciaProfesor.objects.filter(profesor=perfil.profesor)

        filtered_queryset = self.get_queryset()

        context['search_query'] = self.request.GET.get('q', '').strip()
        context['estado_filter'] = self.request.GET.get('estado', '').strip().upper()

        context['total_ausencias'] = filtered_queryset.count()
        context['total_aprobadas'] = filtered_queryset.filter(estado='APROBADA').count()
        context['total_pendientes'] = filtered_queryset.filter(estado='PENDIENTE').count()

        context['total_global'] = base_queryset.count()

        page_obj = context.get('page_obj')
        if page_obj:
            block_size = 10
            current_page = page_obj.number
            start_block = ((current_page - 1) // block_size) * block_size + 1
            end_block = min(start_block + block_size - 1, page_obj.paginator.num_pages)

            context['page_block_range'] = range(start_block, end_block + 1)
            context['previous_block_page'] = start_block - block_size if start_block > 1 else None
            context['next_block_page'] = end_block + 1 if end_block < page_obj.paginator.num_pages else None

        return context


class AusenciaProfesorCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'profesor'
    model = AusenciaProfesor
    form_class = AusenciaProfesorForm
    template_name = 'horarios/ausencia_profesor_formulario.html'
    success_url = reverse_lazy('horarios:profesor_limitaciones')

    def form_valid(self, form):
        perfil = self.request.user.perfilusuario
        if not perfil.profesor:
            form.add_error(None, 'Tu usuario no está vinculado a un profesor.')
            return self.form_invalid(form)
        ausencia = form.save(commit=False)
        ausencia.profesor = perfil.profesor
        ausencia.save()
        return redirect(self.success_url)


class AusenciaProfesorUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'profesor'
    model = AusenciaProfesor
    form_class = AusenciaProfesorForm
    template_name = 'horarios/ausencia_profesor_formulario.html'
    success_url = reverse_lazy('horarios:profesor_limitaciones')

    def get_queryset(self):
        perfil = self.request.user.perfilusuario
        if perfil.profesor:
            return AusenciaProfesor.objects.filter(profesor=perfil.profesor)
        return AusenciaProfesor.objects.none()

    def form_valid(self, form):
        ausencia = self.get_object()
        
        # Si la ausencia estaba aprobada y el formulario fue modificado, cambiar a PENDIENTE
        if ausencia.estado == AusenciaProfesor.EstadoAusencia.APROBADA:
            form.instance.estado = AusenciaProfesor.EstadoAusencia.PENDIENTE
        
        return super().form_valid(form)


class AusenciaProfesorDeleteView(RolRequiredMixin, View):
    rol_requerido = 'profesor'

    def post(self, request, pk):
        perfil = request.user.perfilusuario
        if not perfil.profesor:
            return redirect('horarios:profesor_limitaciones')
        ausencia = get_object_or_404(AusenciaProfesor, pk=pk, profesor=perfil.profesor)
        ausencia.delete()
        return redirect('horarios:profesor_limitaciones')


class ExportarLoteExcelView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def get(self, request, *args, **kwargs):
        lote_id = request.GET.get('lote_id')
        
        if not lote_id:
            return redirect('horarios:admin_horario_generar')
        
        horarios = (
            HorarioClase.objects
            .filter(lote_generacion=lote_id)
            .select_related('grado', 'asignatura', 'profesor', 'grado_asignatura')
        )
        
        if not horarios.exists():
            return redirect('horarios:admin_horario_generar')
        
        try:
            primer_horario = horarios.first()
            horarios_data = {
                'grado': primer_horario.grado.nombre,
                'anio': primer_horario.grado_asignatura.anio if primer_horario.grado_asignatura else None,
                'cuatrimestre': primer_horario.grado_asignatura.cuatrimestre if primer_horario.grado_asignatura else None,
                'horarios': list(horarios)
            }
            
            workbook = crear_excel_lote(lote_id, horarios_data)
            
            buffer = BytesIO()
            workbook.save(buffer)
            buffer.seek(0)
            
            response = FileResponse(
                buffer,
                content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )
            response['Content-Disposition'] = f'attachment; filename="lote_{lote_id}.xlsx"'
            return response
        except Exception as e:
            import traceback
            print(f"ERROR en ExportarLoteExcelView: {str(e)}")
            traceback.print_exc()
            return redirect(f"{reverse_lazy('horarios:admin_horario_generar')}?error=export")


class ExportarTodosHorariosExcelView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def get(self, request, *args, **kwargs):
        try:
            horarios = (
                HorarioClase.objects
                .filter(activo=True)
                .exclude(lote_generacion='')
                .select_related('grado', 'asignatura', 'profesor', 'grado_asignatura')
            )
            
            if not horarios.exists():
                return redirect('horarios:admin_horario_generar')
            
            # Group by lote
            lotes_dict = {}
            for horario in horarios:
                lote_id = horario.lote_generacion
                if lote_id not in lotes_dict:
                    lotes_dict[lote_id] = []
                lotes_dict[lote_id].append(horario)
            
            # Prepare data as list of dicts
            datos_lotes = []
            for lote_id, horarios_lote in lotes_dict.items():
                if horarios_lote:
                    primer_horario = horarios_lote[0]
                    lote_data = {
                        'lote_id': lote_id,
                        'grado': primer_horario.grado.nombre,
                        'grado_id': primer_horario.grado.id,
                        'anio': primer_horario.grado_asignatura.anio if primer_horario.grado_asignatura else None,
                        'cuatrimestre': primer_horario.grado_asignatura.cuatrimestre if primer_horario.grado_asignatura else None,
                        'horarios': horarios_lote,
                    }
                    datos_lotes.append(lote_data)
            
            workbook = crear_excel_todos_horarios(datos_lotes)
            
            buffer = BytesIO()
            workbook.save(buffer)
            buffer.seek(0)
            
            response = FileResponse(
                buffer,
                content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )
            response['Content-Disposition'] = 'attachment; filename="horarios_completos.xlsx"'
            return response
        except Exception as e:
            import traceback
            print(f"ERROR en ExportarTodosHorariosExcelView: {str(e)}")
            traceback.print_exc()
            return redirect(f"{reverse_lazy('horarios:admin_horario_generar')}?error=export")


class ResolverLoteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, *args, **kwargs):
        lote_id = request.POST.get('lote_id')
        grado_id = request.POST.get('grado_id')
        anio = request.POST.get('anio')
        cuatrimestre = request.POST.get('cuatrimestre')
        
        if not lote_id:
            return redirect('horarios:admin_horario_generar')
        
        try:
            # Obtener el lote actual para extraer sus datos
            lote_horarios = HorarioClase.objects.filter(lote_generacion=lote_id)
            if not lote_horarios.exists():
                return redirect('horarios:admin_horario_generar')
            
            # Obtener datos del lote
            primer_horario = lote_horarios.first()
            grado = primer_horario.grado
            anio_int = int(anio) if anio else primer_horario.grado_asignatura.anio
            cuatrimestre_str = str(cuatrimestre) if cuatrimestre else str(primer_horario.grado_asignatura.cuatrimestre)
            
            # Determinar turno basado en las horas existentes
            hora_min = lote_horarios.aggregate(Min('hora_inicio'))['hora_inicio__min']
            turno = 'MANANA' if hora_min and hora_min < time(15, 0) else 'TARDE'
            
            # Eliminar el lote actual
            lote_horarios.delete()
            
            # Regenerar el horario
            view = GenerarHorarioView()
            view.request = request
            resultado = view.generar_horario(grado, anio_int, cuatrimestre_str, turno)
            
            # Guardar resultado en sesión
            request.session['resolver_resultado'] = {
                'resueltos': resultado.get('generados', 0),
                'no_resueltos': 0,
                'movimientos': [{'asignatura': 'Horario regenerado', 'desde': 'Lote anterior', 'hacia': resultado.get('lote_id', 'nuevo')}]
            }
            
            # Redirigir de vuelta
            params = f'?grado={grado.id}&anio={anio_int}&cuatrimestre={cuatrimestre_str}'
            return redirect(f"{reverse_lazy('horarios:admin_horario_generar')}{params}")
            
        except Exception as e:
            import traceback
            print(f"ERROR en ResolverLoteView: {str(e)}")
            traceback.print_exc()
            return redirect(f"{reverse_lazy('horarios:admin_horario_generar')}?error=resolver")
