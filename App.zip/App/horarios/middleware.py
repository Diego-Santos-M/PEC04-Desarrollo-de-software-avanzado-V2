from django.conf import settings


class LogoutOnServerStartMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        self.startup_token = getattr(settings, "SERVER_STARTUP_TOKEN", None)

    def __call__(self, request):
        if self.startup_token:
            session_token = request.session.get("_server_startup_token")
            if session_token != self.startup_token:
                if request.user.is_authenticated:
                    request.session.flush()
                request.session["_server_startup_token"] = self.startup_token
        return self.get_response(request)
