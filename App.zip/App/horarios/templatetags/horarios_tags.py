from django import template

register = template.Library()

@register.filter
def get_item(dictionary, key):
    """
    Permite acceder a un diccionario usando una clave en templates Django
    Uso: {{ diccionario|get_item:clave }}
    """
    if isinstance(dictionary, dict):
        return dictionary.get(key)
    return None
