from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from horarios.models import PerfilUsuario, Profesor


class Command(BaseCommand):
    help = 'Asigna la contraseña "1234" a todos los profesores excepto "ejemplo"'

    def handle(self, *args, **options):
        # Obtener todos los PerfilUsuario de tipo profesor
        perfiles_profesor = PerfilUsuario.objects.filter(
            tipo_usuario__nombre__iexact='profesor'
        ).select_related('usuario', 'profesor')

        contador = 0
        for perfil in perfiles_profesor:
            # Saltar si el profesor se llama "ejemplo"
            if perfil.profesor and perfil.profesor.nombre.lower() == 'ejemplo':
                self.stdout.write(
                    self.style.WARNING(f'Saltando: {perfil.usuario.username} ({perfil.profesor.nombre})')
                )
                continue

            # Actualizar la contraseña
            usuario = perfil.usuario
            usuario.set_password('1234')
            usuario.save()
            contador += 1
            self.stdout.write(
                self.style.SUCCESS(f'✓ Contraseña actualizada: {usuario.username} ({perfil.profesor.nombre if perfil.profesor else "Sin profesor"})')
            )

        self.stdout.write(
            self.style.SUCCESS(f'\n{contador} profesores han recibido la contraseña "1234"')
        )
