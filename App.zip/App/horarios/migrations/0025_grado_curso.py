from django.db import migrations, models
import django.db.models.deletion
from django.core.validators import MaxValueValidator, MinValueValidator


class Migration(migrations.Migration):

    dependencies = [
        ('horarios', '0024_perfilusuario_cuatrimestre_profesor_preferido'),
    ]

    operations = [
        migrations.CreateModel(
            name='GradoCurso',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('anio', models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])),
                ('turno', models.CharField(choices=[('MANANA', 'Manana'), ('TARDE', 'Tarde')], default='MANANA', max_length=6)),
                ('grado', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='horarios.grado')),
            ],
            options={
                'db_table': 'Grados_Cursos',
                'unique_together': {('grado', 'anio')},
            },
        ),
    ]
