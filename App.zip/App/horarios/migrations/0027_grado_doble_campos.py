from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('horarios', '0026_merge_20260526_1518'),
    ]

    operations = [
        migrations.AddField(
            model_name='grado',
            name='es_doble_grado',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='grado',
            name='grado_base_1',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='dobles_grado_base_1', to='horarios.grado'),
        ),
        migrations.AddField(
            model_name='grado',
            name='grado_base_2',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='dobles_grado_base_2', to='horarios.grado'),
        ),
    ]
