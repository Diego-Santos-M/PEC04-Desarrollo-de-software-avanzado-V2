from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password

from .models import Asignatura, AsignaturaProfesor, AusenciaProfesor, Grado, GradoAsignatura, GradoCurso, PerfilUsuario, Profesor, SolicitudCambioProfesor, TipoUsuario


class RegistroUsuarioForm(UserCreationForm):
    tipo_usuario = forms.ModelChoiceField(queryset=TipoUsuario.objects.all())
    profesor = forms.ModelChoiceField(queryset=Profesor.objects.all(), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for nombre_tipo in ['admin', 'profesor']:
            TipoUsuario.objects.get_or_create(nombre=nombre_tipo)
        self.fields['tipo_usuario'].queryset = TipoUsuario.objects.filter(nombre__in=['admin', 'profesor']).order_by('nombre')
        self.fields['profesor'].queryset = Profesor.objects.all().order_by('nombre')

    class Meta:
        model = User
        fields = ('username', 'password1', 'password2', 'tipo_usuario', 'profesor')

    def clean(self):
        cleaned_data = super().clean()
        tipo_usuario = cleaned_data.get('tipo_usuario')
        profesor = cleaned_data.get('profesor')

        if tipo_usuario and tipo_usuario.nombre.lower() == 'profesor' and not profesor:
            self.add_error('profesor', 'Debes vincular un profesor para este tipo de usuario.')

        return cleaned_data


class CredencialesUsuarioForm(forms.Form):
    username = forms.CharField(max_length=150, required=False, label='Nuevo usuario')
    current_password = forms.CharField(widget=forms.PasswordInput, label='Contraseña actual')
    new_password1 = forms.CharField(widget=forms.PasswordInput, required=False, label='Nueva contraseña')
    new_password2 = forms.CharField(widget=forms.PasswordInput, required=False, label='Repite la nueva contraseña')

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user')
        self.force_password_change = kwargs.pop('force_password_change', False)
        super().__init__(*args, **kwargs)
        self.fields['username'].initial = self.user.username

    def clean_username(self):
        username = self.cleaned_data.get('username', '').strip()
        if not username:
            return self.user.username

        if User.objects.filter(username__iexact=username).exclude(pk=self.user.pk).exists():
            raise forms.ValidationError('Ese nombre de usuario ya está en uso.')

        return username

    def clean(self):
        cleaned_data = super().clean()
        current_password = cleaned_data.get('current_password')
        username = cleaned_data.get('username')
        new_password1 = cleaned_data.get('new_password1')
        new_password2 = cleaned_data.get('new_password2')

        if current_password and not self.user.check_password(current_password):
            self.add_error('current_password', 'La contraseña actual no es correcta.')

        password_change_requested = bool(new_password1 or new_password2)
        username_change_requested = bool(username and username != self.user.username)

        if self.force_password_change and not password_change_requested:
            self.add_error('new_password1', 'Debes cambiar la contraseña antes de continuar.')

        if password_change_requested:
            if not new_password1 or not new_password2:
                raise forms.ValidationError('Debes rellenar y confirmar la nueva contraseña.')
            if new_password1 != new_password2:
                self.add_error('new_password2', 'Las contraseñas nuevas no coinciden.')
            else:
                try:
                    validate_password(new_password1, self.user)
                except forms.ValidationError as exc:
                    self.add_error('new_password1', exc)

        if not username_change_requested and not password_change_requested:
            raise forms.ValidationError('Debes cambiar el usuario o la contraseña para guardar.')

        return cleaned_data

    def save(self):
        username = self.cleaned_data['username']
        new_password = self.cleaned_data.get('new_password1')

        if username != self.user.username:
            self.user.username = username

        if new_password:
            self.user.set_password(new_password)
            perfil = PerfilUsuario.objects.filter(usuario=self.user).first()
            if perfil:
                perfil.forzar_cambio_contrasena = False
                perfil.save(update_fields=['forzar_cambio_contrasena'])

        self.user.save()
        return self.user


class AdminUsuarioCreateForm(forms.Form):
    username = forms.CharField(max_length=150, label='Usuario')
    password1 = forms.CharField(widget=forms.PasswordInput, label='Contraseña')
    password2 = forms.CharField(widget=forms.PasswordInput, label='Repetir contraseña')
    tipo_usuario = forms.ModelChoiceField(queryset=TipoUsuario.objects.none(), label='Rol')
    profesor = forms.ModelChoiceField(queryset=Profesor.objects.none(), required=False, label='Profesor asociado')
    forzar_cambio_contrasena = forms.BooleanField(required=False, label='Pedir cambio de contraseña al entrar')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for nombre_tipo in ['admin', 'profesor']:
            TipoUsuario.objects.get_or_create(nombre=nombre_tipo)
        self.fields['tipo_usuario'].queryset = TipoUsuario.objects.filter(nombre__in=['admin', 'profesor']).order_by('nombre')
        self.fields['tipo_usuario'].empty_label = 'Selecciona un rol'
        self.fields['profesor'].empty_label = 'Selecciona un profesor'
        self.profesores_ocupados_ids = list(
            PerfilUsuario.objects.filter(
                tipo_usuario__nombre__iexact='profesor'
            ).exclude(profesor__isnull=True).values_list('profesor__id', flat=True)
        )

        tipo_usuario_id = self.data.get(self.add_prefix('tipo_usuario')) if self.is_bound else None
        tipo_usuario = TipoUsuario.objects.filter(pk=tipo_usuario_id).first() if tipo_usuario_id else None

        if tipo_usuario and tipo_usuario.nombre.lower() == 'profesor':
            self.fields['profesor'].queryset = Profesor.objects.exclude(pk__in=self.profesores_ocupados_ids).order_by('nombre')
        elif tipo_usuario:
            self.fields['profesor'].queryset = Profesor.objects.order_by('nombre')
        else:
            self.fields['profesor'].queryset = Profesor.objects.order_by('nombre')

    def clean_username(self):
        username = self.cleaned_data.get('username', '').strip()
        if not username:
            raise forms.ValidationError('Debes indicar un usuario.')
        if User.objects.filter(username__iexact=username).exists():
            raise forms.ValidationError('Ese nombre de usuario ya está en uso.')
        return username

    def clean(self):
        cleaned_data = super().clean()
        tipo_usuario = cleaned_data.get('tipo_usuario')
        profesor = cleaned_data.get('profesor')
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')

        if password1 and password2 and password1 != password2:
            self.add_error('password2', 'Las contraseñas no coinciden.')

        if tipo_usuario and tipo_usuario.nombre.lower() == 'profesor' and not profesor:
            self.add_error('profesor', 'Debes vincular un profesor para usuarios con rol profesor.')

        if tipo_usuario and profesor:
            if PerfilUsuario.objects.filter(tipo_usuario=tipo_usuario, profesor=profesor).exists():
                self.add_error('profesor', 'Este profesor ya tiene una cuenta asignada con ese rol.')

        return cleaned_data

    def save(self):
        username = self.cleaned_data['username']
        password = self.cleaned_data['password1']
        tipo_usuario = self.cleaned_data['tipo_usuario']
        profesor = self.cleaned_data.get('profesor')
        forzar_cambio_contrasena = self.cleaned_data.get('forzar_cambio_contrasena', False)

        user = User.objects.create_user(username=username, password=password)
        PerfilUsuario.objects.create(
            usuario=user,
            tipo_usuario=tipo_usuario,
            profesor=profesor,
            forzar_cambio_contrasena=forzar_cambio_contrasena,
        )
        return user


class AdminUsuarioUpdateForm(forms.Form):
    username = forms.CharField(max_length=150, label='Usuario')
    new_password1 = forms.CharField(widget=forms.PasswordInput, required=False, label='Nueva contraseña')
    new_password2 = forms.CharField(widget=forms.PasswordInput, required=False, label='Repetir nueva contraseña')
    tipo_usuario = forms.ModelChoiceField(queryset=TipoUsuario.objects.none(), label='Rol')
    profesor = forms.ModelChoiceField(queryset=Profesor.objects.none(), required=False, label='Profesor asociado')
    forzar_cambio_contrasena = forms.BooleanField(required=False, label='Pedir cambio de contraseña al entrar')

    def __init__(self, *args, **kwargs):
        self.user_instance = kwargs.pop('user_instance')
        super().__init__(*args, **kwargs)
        for nombre_tipo in ['admin', 'profesor']:
            TipoUsuario.objects.get_or_create(nombre=nombre_tipo)
        self.fields['tipo_usuario'].queryset = TipoUsuario.objects.filter(nombre__in=['admin', 'profesor']).order_by('nombre')
        self.fields['tipo_usuario'].empty_label = 'Selecciona un rol'
        self.fields['profesor'].empty_label = 'Selecciona un profesor'
        self.perfil = PerfilUsuario.objects.filter(usuario=self.user_instance).first()
        self.profesores_ocupados_ids = list(
            PerfilUsuario.objects.filter(
                tipo_usuario__nombre__iexact='profesor'
            ).exclude(profesor__isnull=True).exclude(usuario=self.user_instance).values_list('profesor__id', flat=True)
        )

        tipo_usuario_id = self.data.get(self.add_prefix('tipo_usuario')) if self.is_bound else None
        if tipo_usuario_id:
            tipo_usuario = TipoUsuario.objects.filter(pk=tipo_usuario_id).first()
        elif self.perfil:
            tipo_usuario = self.perfil.tipo_usuario
        else:
            tipo_usuario = None

        if tipo_usuario and tipo_usuario.nombre.lower() == 'profesor':
            profesores_queryset = Profesor.objects.exclude(pk__in=self.profesores_ocupados_ids).order_by('nombre')
            if self.perfil and self.perfil.profesor:
                profesores_queryset = (profesores_queryset | Profesor.objects.filter(pk=self.perfil.profesor.pk)).distinct().order_by('nombre')
        else:
            profesores_queryset = Profesor.objects.order_by('nombre')

        self.fields['profesor'].queryset = profesores_queryset

        self.fields['username'].initial = self.user_instance.username
        if self.perfil:
            self.fields['tipo_usuario'].initial = self.perfil.tipo_usuario_id
            self.fields['profesor'].initial = self.perfil.profesor.pk if self.perfil.profesor else None
            self.fields['forzar_cambio_contrasena'].initial = self.perfil.forzar_cambio_contrasena
        elif self.user_instance.is_superuser:
            tipo_admin = TipoUsuario.objects.filter(nombre='admin').first()
            self.fields['tipo_usuario'].initial = tipo_admin.id if tipo_admin else None
            self.fields['profesor'].initial = None

    def clean_username(self):
        username = self.cleaned_data.get('username', '').strip()
        if not username:
            raise forms.ValidationError('Debes indicar un usuario.')

        if User.objects.filter(username__iexact=username).exclude(pk=self.user_instance.pk).exists():
            raise forms.ValidationError('Ese nombre de usuario ya está en uso.')
        return username

    def clean(self):
        cleaned_data = super().clean()
        tipo_usuario = cleaned_data.get('tipo_usuario')
        profesor = cleaned_data.get('profesor')
        password1 = cleaned_data.get('new_password1')
        password2 = cleaned_data.get('new_password2')

        if password1 or password2:
            if password1 != password2:
                self.add_error('new_password2', 'Las contraseñas no coinciden.')
            else:
                try:
                    validate_password(password1, self.user_instance)
                except forms.ValidationError as exc:
                    self.add_error('new_password1', exc)

        if tipo_usuario and tipo_usuario.nombre.lower() == 'profesor' and not profesor:
            self.add_error('profesor', 'Debes vincular un profesor para usuarios con rol profesor.')

        if tipo_usuario and profesor:
            if PerfilUsuario.objects.filter(tipo_usuario=tipo_usuario, profesor=profesor).exclude(usuario=self.user_instance).exists():
                self.add_error('profesor', 'Este profesor ya tiene una cuenta asignada con ese rol.')

        return cleaned_data

    def save(self):
        username = self.cleaned_data['username']
        password = self.cleaned_data.get('new_password1')
        tipo_usuario = self.cleaned_data['tipo_usuario']
        profesor = self.cleaned_data.get('profesor')
        forzar_cambio_contrasena = self.cleaned_data.get('forzar_cambio_contrasena', False)

        self.user_instance.username = username
        if password:
            self.user_instance.set_password(password)
        self.user_instance.save()

        perfil, _ = PerfilUsuario.objects.get_or_create(
            usuario=self.user_instance,
            defaults={'tipo_usuario': tipo_usuario, 'profesor': profesor},
        )
        perfil.tipo_usuario = tipo_usuario
        perfil.profesor = profesor
        perfil.forzar_cambio_contrasena = forzar_cambio_contrasena
        perfil.save()

        return self.user_instance


class SolicitudCambioProfesorForm(forms.ModelForm):
    class Meta:
        model = SolicitudCambioProfesor
        fields = ['mensaje']
        widgets = {
            'mensaje': forms.Textarea(attrs={'rows': 4}),
        }


class GenerarHorarioForm(forms.Form):
    grado = forms.ModelChoiceField(queryset=Grado.objects.all())
    anio = forms.ChoiceField(choices=[(i, str(i)) for i in range(1, 6)])
    cuatrimestre = forms.ChoiceField(choices=GradoAsignatura.Cuatrimestres.choices)
    turno = forms.ChoiceField(choices=[('MANANA', 'Mañana'), ('TARDE', 'Tarde')], widget=forms.RadioSelect)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['grado'].label = 'Grado'
        self.fields['anio'].label = 'Año'
        self.fields['cuatrimestre'].label = 'Cuatrimestre'
        self.fields['turno'].label = 'Turno'


class GradoCreateForm(forms.Form):
    TURNO_CHOICES = [
        (GradoCurso.Turnos.MANANA, 'Manana'),
        (GradoCurso.Turnos.TARDE, 'Tarde'),
    ]

    nombre = forms.CharField(max_length=120, label='Nombre')
    es_doble_grado = forms.BooleanField(required=False, label='Es doble grado')
    grado_base_1 = forms.ModelChoiceField(
        queryset=Grado.objects.all(),
        required=False,
        label='Grado base 1',
    )
    grado_base_2 = forms.ModelChoiceField(
        queryset=Grado.objects.all(),
        required=False,
        label='Grado base 2',
    )
    numero_anios = forms.ChoiceField(
        choices=[(i, f'{i} ano' if i == 1 else f'{i} anos') for i in range(1, 6)],
        label='Numero de anos',
        initial='4',
    )

    turno_1 = forms.ChoiceField(choices=TURNO_CHOICES, label='Turno 1er ano', initial=GradoCurso.Turnos.MANANA)
    turno_2 = forms.ChoiceField(choices=TURNO_CHOICES, label='Turno 2o ano', initial=GradoCurso.Turnos.MANANA)
    turno_3 = forms.ChoiceField(choices=TURNO_CHOICES, label='Turno 3er ano', initial=GradoCurso.Turnos.MANANA)
    turno_4 = forms.ChoiceField(choices=TURNO_CHOICES, label='Turno 4o ano', initial=GradoCurso.Turnos.MANANA)
    turno_5 = forms.ChoiceField(choices=TURNO_CHOICES, label='Turno 5o ano', initial=GradoCurso.Turnos.MANANA)

    def __init__(self, *args, **kwargs):
        self.instance = kwargs.pop('instance', None)
        super().__init__(*args, **kwargs)

        if self.instance:
            self.fields['grado_base_1'].queryset = Grado.objects.exclude(pk=self.instance.pk)
            self.fields['grado_base_2'].queryset = Grado.objects.exclude(pk=self.instance.pk)

        if self.instance:
            self.fields['nombre'].initial = self.instance.nombre
            self.fields['es_doble_grado'].initial = self.instance.es_doble_grado
            self.fields['grado_base_1'].initial = self.instance.grado_base_1_id
            self.fields['grado_base_2'].initial = self.instance.grado_base_2_id
            cursos = list(
                GradoCurso.objects.filter(grado=self.instance).order_by('anio')
            )
            if cursos:
                self.fields['numero_anios'].initial = str(cursos[-1].anio)
            for curso in cursos:
                field_name = f'turno_{curso.anio}'
                if field_name in self.fields:
                    self.fields[field_name].initial = curso.turno

    def clean_numero_anios(self):
        value = int(self.cleaned_data['numero_anios'])
        if value < 1 or value > 5:
            raise forms.ValidationError('El numero de anos debe estar entre 1 y 5.')
        return value

    def clean(self):
        cleaned_data = super().clean()
        es_doble_grado = cleaned_data.get('es_doble_grado')
        grado_base_1 = cleaned_data.get('grado_base_1')
        grado_base_2 = cleaned_data.get('grado_base_2')

        if es_doble_grado:
            if not grado_base_1 or not grado_base_2:
                raise forms.ValidationError('Debes seleccionar los dos grados base del doble grado.')
            if grado_base_1 == grado_base_2:
                raise forms.ValidationError('Los grados base deben ser diferentes.')
        else:
            cleaned_data['grado_base_1'] = None
            cleaned_data['grado_base_2'] = None

        return cleaned_data

    def save(self):
        nombre = self.cleaned_data['nombre'].strip()
        numero_anios = self.cleaned_data['numero_anios']
        es_doble_grado = self.cleaned_data.get('es_doble_grado', False)
        grado_base_1 = self.cleaned_data.get('grado_base_1')
        grado_base_2 = self.cleaned_data.get('grado_base_2')

        if self.instance:
            self.instance.nombre = nombre
            self.instance.es_doble_grado = es_doble_grado
            self.instance.grado_base_1 = grado_base_1 if es_doble_grado else None
            self.instance.grado_base_2 = grado_base_2 if es_doble_grado else None
            self.instance.save(update_fields=['nombre', 'es_doble_grado', 'grado_base_1', 'grado_base_2'])
            grado = self.instance
        else:
            grado = Grado.objects.create(
                nombre=nombre,
                es_doble_grado=es_doble_grado,
                grado_base_1=grado_base_1 if es_doble_grado else None,
                grado_base_2=grado_base_2 if es_doble_grado else None,
            )

        existentes = {curso.anio: curso for curso in GradoCurso.objects.filter(grado=grado)}
        for anio in range(1, numero_anios + 1):
            turno = self.cleaned_data.get(f'turno_{anio}', GradoCurso.Turnos.MANANA)
            if anio in existentes:
                curso = existentes[anio]
                if curso.turno != turno:
                    curso.turno = turno
                    curso.save(update_fields=['turno'])
            else:
                GradoCurso.objects.create(grado=grado, anio=anio, turno=turno)

        for anio in list(existentes.keys()):
            if anio > numero_anios:
                existentes[anio].delete()

        return grado


class AsignaturaForm(forms.ModelForm):
    tipo_asignatura = forms.ChoiceField(choices=[('B', 'B'), ('OB', 'OB'), ('OP', 'OP'), ('TFG', 'TFG')])

    class Meta:
        model = Asignatura
        fields = ['nombre', 'tipo_asignatura']


class ProfesorForm(forms.ModelForm):
    contrato_indefinido = forms.BooleanField(required=False)
    contrato_hasta = forms.DateField(
        input_formats=['%d/%m/%Y'],
        widget=forms.DateInput(format='%d/%m/%Y', attrs={'placeholder': 'dd/mm/aaaa'}),
        required=False,
    )

    class Meta:
        model = Profesor
        fields = ['nombre', 'contrato_indefinido', 'contrato_hasta']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['contrato_indefinido'].label = 'Indefinido'
        self.fields['contrato_hasta'].help_text = 'Formato: dd/mm/aaaa. Déjalo vacío si es indefinido.'

    def clean(self):
        cleaned_data = super().clean()
        contrato_indefinido = cleaned_data.get('contrato_indefinido')
        contrato_hasta = cleaned_data.get('contrato_hasta')

        if contrato_indefinido:
            cleaned_data['contrato_hasta'] = None
        elif not contrato_hasta:
            self.add_error('contrato_hasta', 'Debes indicar una fecha en formato dd/mm/aaaa o marcar indefinido.')

        return cleaned_data

    def save(self, commit=True):
        profesor = super().save(commit=False)
        profesor.contrato_indefinido = self.cleaned_data.get('contrato_indefinido', False)
        profesor.contrato_hasta = self.cleaned_data.get('contrato_hasta')
        if commit:
            profesor.save()
        return profesor


class GradoAsignaturaForm(forms.ModelForm):
    anio = forms.ChoiceField(choices=[(i, str(i)) for i in range(1, 6)])
    cuatrimestre = forms.ChoiceField(choices=[('1', '1º'), ('2', '2º')])

    class Meta:
        model = GradoAsignatura
        fields = ['grado', 'asignatura', 'anio', 'cuatrimestre', 'especialidad']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['asignatura'].queryset = Asignatura.objects.none()
        self.fields['especialidad'].required = False

        grado_id = self.data.get('grado')
        if grado_id:
            usadas = GradoAsignatura.objects.filter(grado_id=grado_id).values_list('asignatura_id', flat=True)
            queryset = Asignatura.objects.exclude(id__in=usadas)
            if self.instance and self.instance.pk and str(self.instance.grado_id) == str(grado_id):
                queryset = Asignatura.objects.filter(id=self.instance.asignatura_id) | queryset
            self.fields['asignatura'].queryset = queryset.distinct().order_by('nombre')
        elif self.instance and self.instance.pk:
            self.fields['asignatura'].queryset = Asignatura.objects.filter(id=self.instance.asignatura_id)

    def clean(self):
        cleaned_data = super().clean()
        grado = cleaned_data.get('grado')
        asignatura = cleaned_data.get('asignatura')
        if not grado or not asignatura:
            return cleaned_data

        existe = GradoAsignatura.objects.filter(grado=grado, asignatura=asignatura)
        if self.instance and self.instance.pk:
            existe = existe.exclude(pk=self.instance.pk)

        if existe.exists():
            self.add_error('asignatura', 'Esa asignatura ya está asociada al grado seleccionado.')

        es_op = asignatura.tipo_asignatura == Asignatura.TiposAsignatura.OPTATIVA
        es_grado_informatica = grado.nombre.strip().lower() == 'ingeniería informática'
        especialidad = cleaned_data.get('especialidad')

        if es_op and es_grado_informatica and not especialidad:
            self.add_error('especialidad', 'Debes elegir especialidad para asignaturas OP en Ingeniería Informática.')

        if not (es_op and es_grado_informatica):
            cleaned_data['especialidad'] = None

        return cleaned_data


class AsignaturaProfesorForm(forms.ModelForm):
    class Meta:
        model = AsignaturaProfesor
        fields = ['dni', 'asignatura', 'grado', 'coincide_con_grado_relacionado', 'grado_coincidente']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['dni'].label = 'Nombre'
        self.fields['dni'].queryset = Profesor.objects.all().order_by('nombre')
        self.fields['grado'].required = False
        self.fields['grado'].queryset = Grado.objects.none()
        self.fields['coincide_con_grado_relacionado'].required = False
        self.fields['coincide_con_grado_relacionado'].label = 'Coincide con uno de los grados relacionados'
        self.fields['grado_coincidente'].required = False
        self.fields['grado_coincidente'].queryset = Grado.objects.none()

        asignaturas_disponibles_ids = []
        for asignatura in Asignatura.objects.all().order_by('nombre'):
            grados_ids = list(GradoAsignatura.objects.filter(asignatura=asignatura).values_list('grado_id', flat=True).distinct())
            total_grados = len(grados_ids)
            relaciones = AsignaturaProfesor.objects.filter(asignatura=asignatura)

            if self.instance and self.instance.pk:
                relaciones = relaciones.exclude(pk=self.instance.pk)

            if total_grados > 1:
                grados_asignados = set(relaciones.exclude(grado__isnull=True).values_list('grado_id', flat=True))
                hay_grado_libre = any(grado_id not in grados_asignados for grado_id in grados_ids)
                if hay_grado_libre:
                    asignaturas_disponibles_ids.append(asignatura.id)
            else:
                sin_profesor_asignado = not relaciones.exists()
                if sin_profesor_asignado:
                    asignaturas_disponibles_ids.append(asignatura.id)

        queryset = Asignatura.objects.filter(id__in=asignaturas_disponibles_ids).order_by('nombre')

        if self.instance and self.instance.pk:
            queryset = (Asignatura.objects.filter(pk=self.instance.asignatura_id) | queryset).distinct().order_by('nombre')

        self.fields['asignatura'].queryset = queryset

        # Muestra los grados asociados junto al nombre de asignatura para dar contexto al admin.
        grados_por_asignatura = {
            asignatura_id: ", ".join(sorted(set(nombres_grado)))
            for asignatura_id, nombres_grado in (
                (
                    asignatura_id,
                    list(
                        GradoAsignatura.objects.filter(asignatura_id=asignatura_id)
                        .select_related('grado')
                        .values_list('grado__nombre', flat=True)
                    ),
                )
                for asignatura_id in self.fields['asignatura'].queryset.values_list('id', flat=True)
            )
        }

        def asignatura_label(asignatura):
            grados = grados_por_asignatura.get(asignatura.id)
            if grados:
                return f"{asignatura.nombre} ({grados})"
            return asignatura.nombre

        self.fields['asignatura'].label_from_instance = asignatura_label

        asignatura_id = self.data.get('asignatura')
        if asignatura_id:
            grados_ids = list(GradoAsignatura.objects.filter(asignatura_id=asignatura_id).values_list('grado_id', flat=True).distinct())
            relaciones = AsignaturaProfesor.objects.filter(asignatura_id=asignatura_id)
            if self.instance and self.instance.pk:
                relaciones = relaciones.exclude(pk=self.instance.pk)

            if len(grados_ids) > 1:
                grados_asignados = set(relaciones.exclude(grado__isnull=True).values_list('grado_id', flat=True))
                disponibles_ids = [grado_id for grado_id in grados_ids if grado_id not in grados_asignados]
                if self.instance and self.instance.pk and self.instance.grado_id:
                    disponibles_ids.append(self.instance.grado_id)
                self.fields['grado'].queryset = Grado.objects.filter(id__in=set(disponibles_ids)).order_by('nombre')
            else:
                self.fields['grado'].queryset = Grado.objects.none()
        elif self.instance and self.instance.pk and self.instance.grado_id:
            self.fields['grado'].queryset = Grado.objects.filter(id=self.instance.grado_id)

        grado_id = self.data.get('grado') or (self.instance.grado_id if self.instance and self.instance.pk else None)
        asignatura_id = self.data.get('asignatura') or (self.instance.asignatura_id if self.instance and self.instance.pk else None)
        if grado_id and asignatura_id:
            queryset_coincidente = Grado.objects.filter(
                id__in=GradoAsignatura.objects.filter(asignatura_id=asignatura_id).exclude(grado_id=grado_id).values_list('grado_id', flat=True)
            ).order_by('nombre')
            self.fields['grado_coincidente'].queryset = queryset_coincidente
        elif self.instance and self.instance.pk and self.instance.grado_coincidente_id:
            self.fields['grado_coincidente'].queryset = Grado.objects.filter(id=self.instance.grado_coincidente_id)


class AusenciaProfesorForm(forms.ModelForm):
    turno = forms.ChoiceField(
        choices=AusenciaProfesor.Turnos.choices,
        widget=forms.RadioSelect,
        label='Tipo de ausencia',
    )
    hora_inicio = forms.TimeField(
        input_formats=['%H:%M'],
        widget=forms.TimeInput(format='%H:%M', attrs={'type': 'time'}),
        required=False,
        label='Hora de inicio',
    )
    hora_fin = forms.TimeField(
        input_formats=['%H:%M'],
        widget=forms.TimeInput(format='%H:%M', attrs={'type': 'time'}),
        required=False,
        label='Hora de fin',
    )
    duracion_cuatrimestre = forms.ChoiceField(
        choices=AusenciaProfesor.DuracionAusencia.choices,
        widget=forms.RadioSelect,
        label='Duración de la ausencia',
    )

    class Meta:
        model = AusenciaProfesor
        fields = ['dia_de_la_semana', 'turno', 'hora_inicio', 'hora_fin', 'duracion_cuatrimestre']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['dia_de_la_semana'].label = 'Día de la semana'
        self.fields['dia_de_la_semana'].widget = forms.Select(choices=AusenciaProfesor.DiasSemana.choices)

    def clean(self):
        cleaned_data = super().clean()
        turno = cleaned_data.get('turno')
        hora_inicio = cleaned_data.get('hora_inicio')
        hora_fin = cleaned_data.get('hora_fin')

        if turno == AusenciaProfesor.Turnos.PERSONALIZADO:
            if not hora_inicio or not hora_fin:
                raise ValidationError('Para ausencia personalizada, debes indicar las horas de inicio y fin.')
            if hora_fin <= hora_inicio:
                raise ValidationError('La hora de fin debe ser posterior a la hora de inicio.')

        return cleaned_data

    def save(self, commit=True):
        ausencia = super().save(commit=False)
        turno = self.cleaned_data.get('turno')

        # Resetear horas si no es personalizado
        if turno == AusenciaProfesor.Turnos.MANANA:
            ausencia.hora_inicio = None
            ausencia.hora_fin = None
        elif turno == AusenciaProfesor.Turnos.TARDE:
            ausencia.hora_inicio = None
            ausencia.hora_fin = None

        if commit:
            ausencia.save()
        return ausencia
