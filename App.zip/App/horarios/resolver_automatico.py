"""
Módulo para resolver automáticamente conflictos en horarios.
"""
from datetime import datetime, time
from django.db import transaction
from .models import HorarioClase, AusenciaProfesor


def resolver_conflictos_lote(lote_id):
    """
    Intenta resolver automáticamente los conflictos en un lote.
    
    Estrategia:
    1. Para cada clase conflictiva, busca alternativas de movimiento
    2. Prefiere: mismo horario en otro día > horario adyacente > cualquier hueco
    3. Evita fragmentación (horas contiguos)
    
    Returns:
        dict con resueltos, no_resueltos, movimientos
    """
    horarios = (
        HorarioClase.objects
        .filter(lote_generacion=lote_id)
        .select_related('grado', 'asignatura', 'profesor', 'grado_asignatura')
    )
    
    if not horarios.exists():
        return {'resueltos': 0, 'no_resueltos': 0, 'movimientos': []}
    
    ausencias_aprobadas = AusenciaProfesor.objects.filter(
        estado=AusenciaProfesor.EstadoAusencia.APROBADA
    ).select_related('profesor')
    
    resueltos = 0
    no_resueltos = 0
    movimientos = []
    
    with transaction.atomic():
        horarios_list = list(horarios)
        
        # Generar espacios disponibles únicos
        dias_disponibles = set()
        horas_disponibles = set()
        
        for h in horarios_list:
            dias_disponibles.add(h.dia_de_la_semana)
            horas_disponibles.add((h.hora_inicio, h.hora_fin))
        
        horas_sorted = sorted(horas_disponibles)
        
        # Procesar cada horario
        for horario in horarios_list:
            tiene_conflicto_profesor = _tiene_conflicto_profesor(horario, horarios_list)
            tiene_conflicto_grupo = _tiene_conflicto_grupo(horario, horarios_list)
            tiene_conflicto_ausencia = _tiene_conflicto_ausencia(horario, ausencias_aprobadas)
            
            if not (tiene_conflicto_profesor or tiene_conflicto_grupo or tiene_conflicto_ausencia):
                continue
            
            # Estrategia de búsqueda en orden de preferencia
            nuevo_hueco = None
            
            # 1. Intentar: mismo horario en otro día
            for dia in dias_disponibles:
                if dia == horario.dia_de_la_semana:
                    continue
                nuevo_hueco = _verificar_hueco_seguro(
                    horario, dia, horario.hora_inicio, horario.hora_fin,
                    horarios_list, ausencias_aprobadas
                )
                if nuevo_hueco:
                    break
            
            # 2. Si falla: buscar horas adyacentes en mismo día
            if not nuevo_hueco:
                idx_actual = horas_sorted.index((horario.hora_inicio, horario.hora_fin))
                for offset in [-1, 1]:
                    idx_nuevo = idx_actual + offset
                    if 0 <= idx_nuevo < len(horas_sorted):
                        nueva_inicio, nueva_fin = horas_sorted[idx_nuevo]
                        nuevo_hueco = _verificar_hueco_seguro(
                            horario, horario.dia_de_la_semana, nueva_inicio, nueva_fin,
                            horarios_list, ausencias_aprobadas
                        )
                        if nuevo_hueco:
                            break
            
            # 3. Si falla: buscar horas adyacentes en otro día
            if not nuevo_hueco:
                idx_actual = horas_sorted.index((horario.hora_inicio, horario.hora_fin))
                for offset in [-1, 1]:
                    idx_nuevo = idx_actual + offset
                    if 0 <= idx_nuevo < len(horas_sorted):
                        nueva_inicio, nueva_fin = horas_sorted[idx_nuevo]
                        for dia in dias_disponibles:
                            if dia == horario.dia_de_la_semana:
                                continue
                            nuevo_hueco = _verificar_hueco_seguro(
                                horario, dia, nueva_inicio, nueva_fin,
                                horarios_list, ausencias_aprobadas
                            )
                            if nuevo_hueco:
                                break
                    if nuevo_hueco:
                        break
            
            # 4. Si falla: buscar cualquier hueco disponible
            if not nuevo_hueco:
                for dia in dias_disponibles:
                    for inicio, fin in horas_sorted:
                        nuevo_hueco = _verificar_hueco_seguro(
                            horario, dia, inicio, fin,
                            horarios_list, ausencias_aprobadas
                        )
                        if nuevo_hueco:
                            break
                    if nuevo_hueco:
                        break
            
            if nuevo_hueco:
                dia, inicio, fin = nuevo_hueco
                origen_dia = horario.dia_de_la_semana
                origen_inicio = horario.hora_inicio
                origen_fin = horario.hora_fin

                horario.dia_de_la_semana = dia
                horario.hora_inicio = inicio
                horario.hora_fin = fin
                horario.save()
                
                resueltos += 1
                movimientos.append({
                    'asignatura': horario.asignatura.nombre,
                    'desde': f'{origen_dia} {origen_inicio} - {origen_fin}',
                    'hacia': f'{dia} {inicio} - {fin}'
                })
            else:
                no_resueltos += 1
    
    return {
        'resueltos': resueltos,
        'no_resueltos': no_resueltos,
        'movimientos': movimientos
    }


def _verificar_hueco_seguro(horario, dia, inicio, fin, todos_horarios, ausencias_aprobadas):
    """
    Verifica si un horario específico está libre de conflictos.
    
    Returns:
        Tupla (día, inicio, fin) si es seguro, None si hay conflicto
    """
    # Crear horario temporal
    h_temp = type('obj', (object,), {
        'id': horario.id,
        'dia_de_la_semana': dia,
        'hora_inicio': inicio,
        'hora_fin': fin,
        'profesor': horario.profesor,
        'grado': horario.grado,
        'grado_asignatura': horario.grado_asignatura
    })()
    
    # Verificar conflictos
    tiene_conf_prof = _tiene_conflicto_profesor(h_temp, todos_horarios)
    tiene_conf_grupo = _tiene_conflicto_grupo(h_temp, todos_horarios)
    tiene_conf_ausencia = _tiene_conflicto_ausencia(h_temp, ausencias_aprobadas)
    
    if not (tiene_conf_prof or tiene_conf_grupo or tiene_conf_ausencia):
        return (dia, inicio, fin)
    
    return None


def _tiene_conflicto_profesor(horario, todos_horarios):
    """Verifica si un horario tiene conflicto de profesor."""
    for h in todos_horarios:
        if h.id == horario.id:
            continue
        if horario.grado_asignatura and h.grado_asignatura:
            if horario.grado_asignatura.cuatrimestre != h.grado_asignatura.cuatrimestre:
                continue
        if (h.profesor == horario.profesor and
            h.dia_de_la_semana == horario.dia_de_la_semana and
            h.hora_inicio < horario.hora_fin and
            h.hora_fin > horario.hora_inicio):
            return True
    return False


def _tiene_conflicto_grupo(horario, todos_horarios):
    """Verifica si un horario tiene conflicto de grupo (mismo año/cuatrimestre)."""
    if not horario.grado_asignatura:
        return False
    
    for h in todos_horarios:
        if h.id == horario.id:
            continue
        if not (h.grado == horario.grado and h.grado_asignatura):
            continue
        if h.grado_asignatura.anio != horario.grado_asignatura.anio or h.grado_asignatura.cuatrimestre != horario.grado_asignatura.cuatrimestre:
            continue
        if h.dia_de_la_semana != horario.dia_de_la_semana:
            continue

        if h.grado_asignatura.especialidad and horario.grado_asignatura.especialidad and h.grado_asignatura.especialidad != horario.grado_asignatura.especialidad:
            continue

        if h.hora_inicio < horario.hora_fin and h.hora_fin > horario.hora_inicio:
            return True

    return False


def _tiene_conflicto_ausencia(horario, ausencias_aprobadas):
    """Verifica si un horario coincide con una ausencia aprobada del profesor."""
    for ausencia in ausencias_aprobadas:
        if ausencia.profesor != horario.profesor:
            continue
        if ausencia.dia_de_la_semana != horario.dia_de_la_semana:
            continue
        
        cuatrimestre = horario.grado_asignatura.cuatrimestre if horario.grado_asignatura else None
        if ausencia.coincide_con_horario(horario.hora_inicio, horario.hora_fin, cuatrimestre):
            return True
    
    return False
