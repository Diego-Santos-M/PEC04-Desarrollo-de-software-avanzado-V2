from collections import defaultdict
from datetime import time
from uuid import uuid4

from django.contrib.auth import login
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.views import LoginView, LogoutView
from django.db import transaction
from django.db.models import Count, Max, Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, ListView, TemplateView, UpdateView, View

from .forms import AsignaturaForm, AsignaturaProfesorForm, AusenciaProfesorForm, GenerarHorarioForm, GradoAsignaturaForm, ProfesorForm, RegistroUsuarioForm, SolicitudCambioProfesorForm
from .models import (
    Asignatura,
    AsignaturaProfesor,
    AusenciaProfesor,
    Grado,
    GradoAsignatura,
    HorarioClase,
    PerfilUsuario,
    Profesor,
    SolicitudCambioProfesor,
)


def obtener_rol(usuario):
    if usuario.is_superuser:
        return 'admin'
    try:
        return usuario.perfilusuario.tipo_usuario.nombre.lower()
    except PerfilUsuario.DoesNotExist:
        return None


class RolRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    rol_requerido = None

    def test_func(self):
        if self.request.user.is_superuser and self.rol_requerido == 'admin':
            return True
        return obtener_rol(self.request.user) == self.rol_requerido


class SugerenciasBusquedaView(RolRequiredMixin, View):
    rol_requerido = 'admin'
    modelo = None
    campo = 'nombre'

    def get_queryset(self):
        return self.modelo.objects.all().order_by(self.campo)

    def get(self, request, *args, **kwargs):
        termino = request.GET.get('q', '').strip()
        queryset = self.get_queryset()

        if termino:
            queryset = queryset.filter(**{f'{self.campo}__icontains': termino})

        sugerencias = list(queryset.values_list(self.campo, flat=True)[:8])
        return JsonResponse({'results': sugerencias})


class RegistroView(CreateView):
    form_class = RegistroUsuarioForm
    template_name = 'horarios/registro.html'
    success_url = reverse_lazy('horarios:inicio')

    def form_valid(self, form):
        usuario = form.save()
        PerfilUsuario.objects.create(
            usuario=usuario,
            tipo_usuario=form.cleaned_data['tipo_usuario'],
            profesor=form.cleaned_data.get('profesor'),
        )
        login(self.request, usuario)
        return redirect('horarios:inicio')


class InicioView(TemplateView):
    template_name = 'horarios/inicio.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        grado_id = self.request.GET.get('grado')
        anio = self.request.GET.get('anio')
        cuatrimestre = self.request.GET.get('cuatrimestre')

        horarios = (
            HorarioClase.objects.filter(activo=True)
            .exclude(lote_generacion='')
            .select_related('grado', 'asignatura', 'profesor', 'grado_asignatura')
        )

        if grado_id:
            horarios = horarios.filter(grado_asignatura__grado_id=grado_id)
        if anio:
            horarios = horarios.filter(grado_asignatura__anio=anio)
        if cuatrimestre:
            horarios = horarios.filter(grado_asignatura__cuatrimestre=cuatrimestre)

        horarios = horarios.distinct().order_by(
            'grado__nombre',
            'grado_asignatura__anio',
            'grado_asignatura__cuatrimestre',
            'dia_de_la_semana',
            'hora_inicio',
        )

        day_to_key = {
            'LUNES': 'l',
            'MARTES': 'm',
            'MIERCOLES': 'x',
            'JUEVES': 'j',
            'VIERNES': 'v',
        }

        grupos = {}
        for horario in horarios:
            relacion = horario.grado_asignatura or GradoAsignatura.objects.filter(grado=horario.grado, asignatura=horario.asignatura).first()
            if not relacion:
                continue

            group_key = (horario.grado.id, relacion.anio, relacion.cuatrimestre)
            if group_key not in grupos:
                grupos[group_key] = {
                    'titulo': f"{horario.grado.nombre} - {relacion.anio}º - {relacion.get_cuatrimestre_display()}",
                    'rows': {},
                }

            row_key = (horario.hora_inicio, horario.hora_fin)
            if row_key not in grupos[group_key]['rows']:
                grupos[group_key]['rows'][row_key] = {
                    'hora': f"{horario.hora_inicio.strftime('%H:%M')} - {horario.hora_fin.strftime('%H:%M')}",
                    'l': [],
                    'm': [],
                    'x': [],
                    'j': [],
                    'v': [],
                }

            day_key = day_to_key.get(horario.dia_de_la_semana)
            if day_key:
                grupos[group_key]['rows'][row_key][day_key].append(
                    f"{horario.asignatura.nombre} ({horario.profesor.nombre})"
                )

        horarios_por_grupo = []
        for _, data in sorted(grupos.items(), key=lambda x: x[1]['titulo']):
            matriz = [data['rows'][key] for key in sorted(data['rows'].keys())]
            horarios_por_grupo.append({
                'titulo': data['titulo'],
                'matriz': matriz,
            })

        context['horarios_por_grupo'] = horarios_por_grupo
        context['grados'] = Grado.objects.order_by('nombre')
        context['anios'] = sorted(
            set(GradoAsignatura.objects.values_list('anio', flat=True)),
        ) or [1, 2, 3, 4, 5]
        context['cuatrimestres'] = GradoAsignatura.Cuatrimestres.choices
        context['grado_seleccionado'] = grado_id
        context['anio_seleccionado'] = anio
        context['cuatrimestre_seleccionado'] = cuatrimestre
        return context


class AppLoginView(LoginView):
    template_name = 'horarios/login.html'

    def get_success_url(self):
        rol = obtener_rol(self.request.user)
        if rol == 'admin':
            return reverse_lazy('horarios:admin_panel')
        if rol == 'profesor':
            return reverse_lazy('horarios:profesor_horarios')
        return reverse_lazy('horarios:inicio')


class AppLogoutView(LogoutView):
    next_page = reverse_lazy('horarios:login')


class AdminPanelView(RolRequiredMixin, TemplateView):
    rol_requerido = 'admin'
    template_name = 'horarios/admin_panel.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        ultimo_login_admin = self.request.user.last_login
        pendientes = AusenciaProfesor.objects.filter(estado=AusenciaProfesor.EstadoAusencia.PENDIENTE)
        context['limitaciones_pendientes_count'] = pendientes.count()
        if ultimo_login_admin:
            context['limitaciones_nuevas_count'] = pendientes.filter(creada_en__gt=ultimo_login_admin).count()
        else:
            context['limitaciones_nuevas_count'] = pendientes.count()
        return context


class GenerarHorarioView(RolRequiredMixin, View):
    rol_requerido = 'admin'
    template_name = 'horarios/generar_horario_formulario.html'

    def get(self, request, *args, **kwargs):
        initial = {
            'grado': request.GET.get('grado') or None,
            'anio': request.GET.get('anio') or None,
            'cuatrimestre': request.GET.get('cuatrimestre') or None,
            'turno': request.GET.get('turno') or None,
        }
        form = GenerarHorarioForm(initial=initial)
        return self.render_form(form)

    def post(self, request, *args, **kwargs):
        form = GenerarHorarioForm(request.POST)
        if not form.is_valid():
            return self.render_form(form)

        grado = form.cleaned_data['grado']
        anio = int(form.cleaned_data['anio'])
        cuatrimestre = form.cleaned_data['cuatrimestre']
        turno = form.cleaned_data['turno']
        resultado = self.generar_horario(grado, anio, cuatrimestre, turno)
        return self.render_form(GenerarHorarioForm(initial=form.cleaned_data), resultado)

    def render_form(self, form, resultado=None):
        grado = None
        anio = None
        cuatrimestre = None

        if form.is_bound and form.is_valid():
            grado = form.cleaned_data['grado']
            anio = int(form.cleaned_data['anio'])
            cuatrimestre = form.cleaned_data['cuatrimestre']
        elif form.initial.get('grado') and form.initial.get('anio') and form.initial.get('cuatrimestre'):
            try:
                grado = Grado.objects.get(pk=form.initial['grado'])
                anio = int(form.initial['anio'])
                cuatrimestre = str(form.initial['cuatrimestre'])
            except Exception:
                grado = None
                anio = None
                cuatrimestre = None

        lotes, horarios_generados = self.obtener_lotes_y_horarios(grado, anio, cuatrimestre)

        filtro_lote = self.request.GET.get('filtro_lote')
        if lotes:
            lote_ids = [lote['id'] for lote in lotes]
            if filtro_lote not in lote_ids:
                filtro_lote = lote_ids[0]
            horarios_generados = horarios_generados.filter(lote_generacion=filtro_lote)
        else:
            filtro_lote = ''

        matriz_horario = self.construir_matriz_horario(horarios_generados)

        context = {
            'form': form,
            'resultado': resultado,
            'lotes': lotes,
            'lotes_disponibles': lotes,
            'horarios_generados': horarios_generados,
            'filtro_lote': filtro_lote,
            'matriz_horario': matriz_horario,
            'estado_lote': self.request.GET.get('estado_lote', ''),
        }
        return render(self.request, self.template_name, context)

    def construir_matriz_horario(self, horarios):
        day_to_key = {
            'LUNES': 'l',
            'MARTES': 'm',
            'MIERCOLES': 'x',
            'JUEVES': 'j',
            'VIERNES': 'v',
        }

        rows = {}
        for horario in horarios:
            row_key = (horario.hora_inicio, horario.hora_fin)
            if row_key not in rows:
                rows[row_key] = {
                    'hora': f"{horario.hora_inicio.strftime('%H:%M')} - {horario.hora_fin.strftime('%H:%M')}",
                    'l': [],
                    'm': [],
                    'x': [],
                    'j': [],
                    'v': [],
                }

            col = day_to_key.get(horario.dia_de_la_semana)
            if col:
                rows[row_key][col].append(
                    {
                        'asignatura': horario.asignatura.nombre,
                        'texto': f"{horario.asignatura.nombre} ({horario.profesor.nombre})",
                    }
                )

        return [rows[key] for key in sorted(rows.keys())]

    def generar_horario(self, grado, anio, cuatrimestre, turno):
        relaciones = list(
            GradoAsignatura.objects.filter(grado=grado, anio=anio, cuatrimestre=cuatrimestre)
            .select_related('asignatura')
            .order_by('asignatura__nombre')
        )

        slots = self.obtener_slots(turno)
        if not slots:
            return {'generados': 0, 'advertencias': ['No hay franjas horarias para el turno elegido.']}

        with transaction.atomic():
            lote_id = uuid4().hex[:12]

            ocupacion_profesor = defaultdict(list)
            ocupacion_grupo = defaultdict(list)
            advertencias = []
            generados = 0

            preferred_days = ['LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES']

            for relacion in relaciones:
                profesor = self.obtener_profesor(relacion, grado)
                if not profesor:
                    advertencias.append(f'No hay profesor asignado para {relacion.asignatura.nombre}.')
                    continue

                pareja = self.obtener_pareja_compartida(relacion, grado, anio, cuatrimestre)
                if pareja and not self.pareja_valida(pareja[0], pareja[1], profesor, ocupacion_profesor, ocupacion_grupo):
                    pareja = None

                if not pareja:
                    pareja = self.encontrar_pareja(relacion, slots, ocupacion_profesor, ocupacion_grupo, profesor, preferred_days)
                if not pareja:
                    advertencias.append(f'No se pudo ubicar {relacion.asignatura.nombre}.')
                    continue

                guardados = []
                fallo_en_pareja = False
                for dia, inicio, fin in pareja:
                    horario = HorarioClase(
                        grado=grado,
                        asignatura=relacion.asignatura,
                        grado_asignatura=relacion,
                        profesor=profesor,
                        dia_de_la_semana=dia,
                        hora_inicio=inicio,
                        hora_fin=fin,
                        aula='',
                        lote_generacion=lote_id,
                        activo=False,
                    )
                    try:
                        horario.full_clean()
                        horario.save()
                    except Exception as exc:
                        advertencias.append(f'No se pudo guardar {relacion.asignatura.nombre}: {exc}')
                        fallo_en_pareja = True
                        break
                    guardados.append((horario, dia, inicio, fin))

                if fallo_en_pareja:
                    for horario_guardado, _, _, _ in guardados:
                        horario_guardado.delete()
                    continue

                for _, dia, inicio, fin in guardados:
                    ocupacion_profesor[(profesor.id, dia)].append((inicio, fin))
                    ocupacion_grupo[dia].append((inicio, fin))
                    generados += 1

        return {'generados': generados, 'advertencias': advertencias, 'lote_id': lote_id}

    def obtener_slots(self, turno):
        if turno == 'MANANA':
            return [
                ('LUNES', time(9, 0), time(11, 0)),
                ('LUNES', time(11, 0), time(13, 0)),
                ('LUNES', time(13, 0), time(15, 0)),
                ('MARTES', time(9, 0), time(11, 0)),
                ('MARTES', time(11, 0), time(13, 0)),
                ('MARTES', time(13, 0), time(15, 0)),
                ('MIERCOLES', time(9, 0), time(11, 0)),
                ('MIERCOLES', time(11, 0), time(13, 0)),
                ('MIERCOLES', time(13, 0), time(15, 0)),
                ('JUEVES', time(9, 0), time(11, 0)),
                ('JUEVES', time(11, 0), time(13, 0)),
                ('JUEVES', time(13, 0), time(15, 0)),
                ('VIERNES', time(9, 0), time(11, 0)),
                ('VIERNES', time(11, 0), time(13, 0)),
                ('VIERNES', time(13, 0), time(15, 0)),
            ]
        if turno == 'TARDE':
            return [
                ('LUNES', time(15, 30), time(17, 30)),
                ('LUNES', time(17, 30), time(19, 30)),
                ('LUNES', time(19, 30), time(21, 30)),
                ('MARTES', time(15, 30), time(17, 30)),
                ('MARTES', time(17, 30), time(19, 30)),
                ('MARTES', time(19, 30), time(21, 30)),
                ('MIERCOLES', time(15, 30), time(17, 30)),
                ('MIERCOLES', time(17, 30), time(19, 30)),
                ('MIERCOLES', time(19, 30), time(21, 30)),
                ('JUEVES', time(15, 30), time(17, 30)),
                ('JUEVES', time(17, 30), time(19, 30)),
                ('JUEVES', time(19, 30), time(21, 30)),
                ('VIERNES', time(15, 30), time(17, 30)),
                ('VIERNES', time(17, 30), time(19, 30)),
                ('VIERNES', time(19, 30), time(21, 30)),
            ]
        return []

    def obtener_profesor(self, relacion, grado):
        asignacion = AsignaturaProfesor.objects.filter(asignatura=relacion.asignatura, grado=grado).select_related('dni').first()
        if asignacion:
            return asignacion.dni

        asignacion = AsignaturaProfesor.objects.filter(
            asignatura=relacion.asignatura,
            grado__isnull=True,
        ).select_related('dni').first()
        if asignacion:
            return asignacion.dni

        asignacion = AsignaturaProfesor.objects.filter(
            asignatura=relacion.asignatura,
            coincide_con_grado_relacionado=True,
            grado_coincidente=grado,
        ).select_related('dni').first()
        if asignacion:
            return asignacion.dni
        return None

    def obtener_pareja_compartida(self, relacion, grado, anio, cuatrimestre):
        asignacion_compartida = AsignaturaProfesor.objects.filter(
            asignatura=relacion.asignatura,
            coincide_con_grado_relacionado=True,
        ).filter(
            Q(grado=grado) | Q(grado_coincidente=grado)
        ).select_related('grado', 'grado_coincidente').first()

        if not asignacion_compartida:
            return None

        grado_compartido = asignacion_compartida.grado_coincidente if asignacion_compartida.grado == grado else asignacion_compartida.grado
        horarios_compartidos = list(
            HorarioClase.objects.filter(
                grado=grado_compartido,
                grado_asignatura__anio=anio,
                grado_asignatura__cuatrimestre=cuatrimestre,
                asignatura=relacion.asignatura,
            ).order_by('dia_de_la_semana', 'hora_inicio')
        )

        if len(horarios_compartidos) != 2:
            return None

        return [
            (horario.dia_de_la_semana, horario.hora_inicio, horario.hora_fin)
            for horario in horarios_compartidos
        ]

    def encontrar_pareja(self, relacion, slots, ocupacion_profesor, ocupacion_grupo, profesor, preferred_days):
        pares_preferidos = []
        for dia in preferred_days:
            day_slots = [slot for slot in slots if slot[0] == dia]
            if len(day_slots) >= 2:
                pares_preferidos.append((day_slots[0], day_slots[1]))
                if len(day_slots) >= 3:
                    pares_preferidos.append((day_slots[1], day_slots[2]))
            if len(day_slots) >= 3:
                pares_preferidos.append((day_slots[0], day_slots[2]))

        for i, slot_a in enumerate(slots):
            for slot_b in slots[i + 1:]:
                pares_preferidos.append((slot_a, slot_b))

        for slot_a, slot_b in pares_preferidos:
            if self.pareja_valida(slot_a, slot_b, profesor, ocupacion_profesor, ocupacion_grupo):
                return [slot_a, slot_b]
        return None

    def pareja_valida(self, slot_a, slot_b, profesor, ocupacion_profesor, ocupacion_grupo):
        if slot_a[0] == slot_b[0]:
            return False
        for slot in [slot_a, slot_b]:
            if self.profesor_ocupado(profesor, slot, ocupacion_profesor):
                return False
            if self.grupo_ocupado(slot, ocupacion_grupo):
                return False
            if self.profesor_en_ausencia(profesor, slot):
                return False
        return True

    def profesor_ocupado(self, profesor, slot, ocupacion):
        return any(self.solapa(slot[1], slot[2], inicio, fin) for inicio, fin in ocupacion.get((profesor.id, slot[0]), []))

    def grupo_ocupado(self, slot, ocupacion_grupo):
        return any(self.solapa(slot[1], slot[2], inicio, fin) for inicio, fin in ocupacion_grupo.get(slot[0], []))

    def profesor_en_ausencia(self, profesor, slot):
        es_manana = slot[1] < time(15, 0)
        es_tarde = slot[1] >= time(15, 30)

        qs = AusenciaProfesor.objects.filter(
            profesor=profesor,
            dia_de_la_semana=slot[0],
            estado=AusenciaProfesor.EstadoAusencia.APROBADA,
        )

        if qs.filter(turno=AusenciaProfesor.Turnos.TODO_EL_DIA).exists():
            return True

        if es_manana and qs.filter(turno=AusenciaProfesor.Turnos.MANANA).exists():
            return True

        if es_tarde and qs.filter(turno=AusenciaProfesor.Turnos.TARDE).exists():
            return True

        return qs.filter(
            turno=AusenciaProfesor.Turnos.PERSONALIZADO,
            hora_inicio__lt=slot[2],
            hora_fin__gt=slot[1],
        ).exists()

    @staticmethod
    def solapa(inicio_a, fin_a, inicio_b, fin_b):
        return inicio_a < fin_b and fin_a > inicio_b

    def obtener_lotes_y_horarios(self, grado=None, anio=None, cuatrimestre=None):
        qs = HorarioClase.objects.exclude(lote_generacion='').select_related('asignatura', 'profesor', 'grado', 'grado_asignatura')

        if grado is not None:
            qs = qs.filter(grado=grado)
        if anio is not None:
            qs = qs.filter(grado_asignatura__anio=anio)
        if cuatrimestre is not None:
            qs = qs.filter(grado_asignatura__cuatrimestre=cuatrimestre)

        lotes = list(
            qs.values(
                'lote_generacion',
                'grado_id',
                'grado__nombre',
                'grado_asignatura__anio',
                'grado_asignatura__cuatrimestre',
            )
            .annotate(clases=Count('id'), activo=Max('activo'), ultimo_horario_id=Max('id'))
            .order_by('-ultimo_horario_id')
        )

        for lote in lotes:
            lote['id'] = lote.pop('lote_generacion')
            lote['grado_nombre'] = lote.pop('grado__nombre')
            lote['anio'] = lote.pop('grado_asignatura__anio')
            lote['cuatrimestre'] = lote.pop('grado_asignatura__cuatrimestre')

        activos_por_scope = {}
        for lote in lotes:
            scope = (lote['grado_id'], lote['anio'], lote['cuatrimestre'])
            if lote['activo']:
                activos_por_scope[scope] = activos_por_scope.get(scope, 0) + 1

        for lote in lotes:
            scope = (lote['grado_id'], lote['anio'], lote['cuatrimestre'])
            lote['puede_activar'] = lote['activo'] or activos_por_scope.get(scope, 0) == 0

        horarios = qs.order_by('-lote_generacion', 'dia_de_la_semana', 'hora_inicio')
        return lotes, horarios


class ActivarLoteHorarioView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request):
        grado_id = request.POST.get('grado_id')
        anio = request.POST.get('anio')
        cuatrimestre = request.POST.get('cuatrimestre')
        lote_id = request.POST.get('lote_id')

        if not (grado_id and anio and cuatrimestre and lote_id):
            return redirect('horarios:admin_horario_generar')

        redirect_url = (
            f"{reverse_lazy('horarios:admin_horario_generar')}"
            f"?grado={grado_id}&anio={anio}&cuatrimestre={cuatrimestre}&filtro_lote={lote_id}"
        )

        qs = HorarioClase.objects.filter(
            grado_id=grado_id,
            grado_asignatura__anio=anio,
            grado_asignatura__cuatrimestre=cuatrimestre,
        ).exclude(lote_generacion='')

        if qs.filter(lote_generacion=lote_id, activo=True).exists():
            return redirect(f'{redirect_url}&estado_lote=ya_activo')

        if qs.exclude(lote_generacion=lote_id).filter(activo=True).exists():
            return redirect(f'{redirect_url}&estado_lote=otro_activo')

        qs.filter(lote_generacion=lote_id).update(activo=True)

        return redirect(f'{redirect_url}&estado_lote=activado')


class DesactivarLoteHorarioView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request):
        grado_id = request.POST.get('grado_id')
        anio = request.POST.get('anio')
        cuatrimestre = request.POST.get('cuatrimestre')
        lote_id = request.POST.get('lote_id')

        if not (grado_id and anio and cuatrimestre and lote_id):
            return redirect('horarios:admin_horario_generar')

        redirect_url = (
            f"{reverse_lazy('horarios:admin_horario_generar')}"
            f"?grado={grado_id}&anio={anio}&cuatrimestre={cuatrimestre}&filtro_lote={lote_id}"
        )

        qs = HorarioClase.objects.filter(
            grado_id=grado_id,
            grado_asignatura__anio=anio,
            grado_asignatura__cuatrimestre=cuatrimestre,
            lote_generacion=lote_id,
        ).exclude(lote_generacion='')

        if not qs.filter(activo=True).exists():
            return redirect(f'{redirect_url}&estado_lote=ya_inactivo')

        qs.update(activo=False)

        return redirect(f'{redirect_url}&estado_lote=desactivado')


class EliminarLoteHorarioView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request):
        grado_id = request.POST.get('grado_id')
        anio = request.POST.get('anio')
        cuatrimestre = request.POST.get('cuatrimestre')
        lote_id = request.POST.get('lote_id')

        if not (grado_id and anio and cuatrimestre and lote_id):
            return redirect('horarios:admin_horario_generar')

        HorarioClase.objects.filter(
            grado_id=grado_id,
            grado_asignatura__anio=anio,
            grado_asignatura__cuatrimestre=cuatrimestre,
            lote_generacion=lote_id,
        ).delete()

        return redirect(f"{reverse_lazy('horarios:admin_horario_generar')}?grado={grado_id}&anio={anio}&cuatrimestre={cuatrimestre}")


class GradoListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = Grado
    template_name = 'horarios/grado_lista.html'
    context_object_name = 'grados'
    paginate_by = 6

    def get_queryset(self):
        queryset = Grado.objects.all().order_by('nombre')
        search_query = self.request.GET.get('q', '').strip()
        if search_query:
            queryset = queryset.filter(nombre__icontains=search_query)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        grados_query = self.get_queryset()
        context['search_query'] = self.request.GET.get('q', '').strip()
        context['total_grados'] = grados_query.count()

        page_obj = context.get('page_obj')
        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        return context
    paginate_by = 6

    def get_queryset(self):
        queryset = Grado.objects.all().order_by('nombre')
        search_query = self.request.GET.get('q', '').strip()
        if search_query:
            queryset = queryset.filter(nombre__icontains=search_query)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        grados_query = self.get_queryset()
        context['search_query'] = self.request.GET.get('q', '').strip()
        context['total_grados'] = grados_query.count()

        page_obj = context.get('page_obj')
        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        return context


class GradoCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'admin'
    model = Grado
    fields = ['nombre']
    template_name = 'horarios/formulario_generico.html'
    success_url = reverse_lazy('horarios:admin_grados')


class GradoUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'admin'
    model = Grado
    fields = ['nombre']
    template_name = 'horarios/formulario_generico.html'
    success_url = reverse_lazy('horarios:admin_grados')


class GradoDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        grado = get_object_or_404(Grado, pk=pk)
        grado.delete()
        return redirect('horarios:admin_grados')


class AsignaturaListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = Asignatura
    template_name = 'horarios/asignatura_lista.html'
    context_object_name = 'asignaturas'
    paginate_by = 6

    def get_queryset(self):
        queryset = Asignatura.objects.all().order_by('nombre')
        search_query = self.request.GET.get('q', '').strip()
        if search_query:
            queryset = queryset.filter(nombre__icontains=search_query)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        asignaturas_query = self.get_queryset()
        context['search_query'] = self.request.GET.get('q', '').strip()
        context['total_asignaturas'] = asignaturas_query.count()
        page_obj = context.get('page_obj')

        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        return context


class AsignaturaCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'admin'
    model = Asignatura
    form_class = AsignaturaForm
    template_name = 'horarios/asignatura_formulario.html'
    success_url = reverse_lazy('horarios:admin_asignaturas')


class AsignaturaUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'admin'
    model = Asignatura
    form_class = AsignaturaForm
    template_name = 'horarios/asignatura_formulario.html'
    success_url = reverse_lazy('horarios:admin_asignaturas')


class AsignaturaDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        asignatura = get_object_or_404(Asignatura, pk=pk)
        asignatura.delete()
        return redirect('horarios:admin_asignaturas')


class ProfesorListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = Profesor
    template_name = 'horarios/profesor_lista.html'
    context_object_name = 'profesores'
    paginate_by = 6

    def get_queryset(self):
        queryset = Profesor.objects.all().order_by('nombre')
        search_query = self.request.GET.get('q', '').strip()
        if search_query:
            queryset = queryset.filter(Q(nombre__icontains=search_query) | Q(dni__icontains=search_query))
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profesores_query = self.get_queryset()
        context['search_query'] = self.request.GET.get('q', '').strip()
        context['total_profesores'] = profesores_query.count()
        context['profesores_indefinidos'] = profesores_query.filter(contrato_indefinido=True).count()
        context['profesores_temporales'] = profesores_query.filter(contrato_indefinido=False).count()

        page_obj = context.get('page_obj')
        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        return context


class ProfesorCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'admin'
    model = Profesor
    form_class = ProfesorForm
    template_name = 'horarios/profesor_formulario.html'
    success_url = reverse_lazy('horarios:admin_profesores')


class ProfesorUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'admin'
    model = Profesor
    form_class = ProfesorForm
    template_name = 'horarios/profesor_formulario.html'
    success_url = reverse_lazy('horarios:admin_profesores')


class ProfesorDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        profesor = get_object_or_404(Profesor, pk=pk)
        profesor.delete()
        return redirect('horarios:admin_profesores')


class GradoSuggestionsView(SugerenciasBusquedaView):
    modelo = Grado


class AsignaturaSuggestionsView(SugerenciasBusquedaView):
    modelo = Asignatura


class ProfesorSuggestionsView(SugerenciasBusquedaView):
    modelo = Profesor


class HorarioAdminListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = HorarioClase
    template_name = 'horarios/horario_admin_lista.html'
    context_object_name = 'horarios'


class HorarioAdminCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'admin'
    model = HorarioClase
    fields = ['grado', 'asignatura', 'profesor', 'dia_de_la_semana', 'hora_inicio', 'hora_fin', 'aula', 'activo']
    template_name = 'horarios/formulario_generico.html'
    success_url = reverse_lazy('horarios:admin_horarios')


class HorarioAdminUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'admin'
    model = HorarioClase
    fields = ['grado', 'asignatura', 'profesor', 'dia_de_la_semana', 'hora_inicio', 'hora_fin', 'aula', 'activo']
    template_name = 'horarios/formulario_generico.html'
    success_url = reverse_lazy('horarios:admin_horarios')


class HorarioAdminDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        horario = get_object_or_404(HorarioClase, pk=pk)
        horario.delete()
        return redirect('horarios:admin_horarios')


class GradoAsignaturaListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = GradoAsignatura
    template_name = 'horarios/grado_asignatura_lista.html'
    context_object_name = 'relaciones'
    paginate_by = 6

    def get_queryset(self):
        queryset = GradoAsignatura.objects.select_related('grado', 'asignatura').order_by('grado__nombre', 'anio', 'cuatrimestre', 'asignatura__nombre')

        grado_id = self.request.GET.get('grado', '').strip()
        anio = self.request.GET.get('anio', '').strip()
        cuatrimestre = self.request.GET.get('cuatrimestre', '').strip()
        turno = self.request.GET.get('turno', '').strip()

        if grado_id:
            queryset = queryset.filter(grado_id=grado_id)

        if anio:
            queryset = queryset.filter(anio=anio)

        if cuatrimestre:
            queryset = queryset.filter(cuatrimestre=cuatrimestre)

        if turno == 'MANANA':
            queryset = queryset.filter(
                horarios__hora_inicio__lt=time(15, 0),
                horarios__hora_fin__gt=time(9, 0),
            )
        elif turno == 'TARDE':
            queryset = queryset.filter(
                horarios__hora_inicio__lt=time(21, 30),
                horarios__hora_fin__gt=time(15, 30),
            )

        return queryset.distinct()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        relaciones_query = self.get_queryset()

        context['filtro_grado'] = self.request.GET.get('grado', '').strip()
        context['filtro_anio'] = self.request.GET.get('anio', '').strip()
        context['filtro_cuatrimestre'] = self.request.GET.get('cuatrimestre', '').strip()
        context['filtro_turno'] = self.request.GET.get('turno', '').strip()

        context['grados_disponibles'] = Grado.objects.order_by('nombre')
        context['anios_disponibles'] = [1, 2, 3, 4, 5]
        context['cuatrimestres_disponibles'] = GradoAsignatura.Cuatrimestres.choices
        context['total_relaciones_filtradas'] = relaciones_query.count()

        page_obj = context.get('page_obj')
        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        return context


class GradoAsignaturaCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'admin'
    model = GradoAsignatura
    form_class = GradoAsignaturaForm
    template_name = 'horarios/grado_asignatura_formulario.html'
    success_url = reverse_lazy('horarios:admin_grado_asignaturas')


class GradoAsignaturaUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'admin'
    model = GradoAsignatura
    form_class = GradoAsignaturaForm
    template_name = 'horarios/grado_asignatura_formulario.html'
    success_url = reverse_lazy('horarios:admin_grado_asignaturas')


class AsignaturasDisponiblesPorGradoView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def get(self, request, grado_id):
        asignatura_actual_id = request.GET.get('actual')
        usadas = GradoAsignatura.objects.filter(grado_id=grado_id).values_list('asignatura_id', flat=True)
        queryset = Asignatura.objects.exclude(id__in=usadas)
        if asignatura_actual_id:
            queryset = (Asignatura.objects.filter(id=asignatura_actual_id) | queryset).distinct()

        data = [
            {
                'id': asignatura.id,
                'nombre': asignatura.nombre,
                'tipo_asignatura': asignatura.tipo_asignatura,
            }
            for asignatura in queryset.order_by('nombre')
        ]
        return JsonResponse({'asignaturas': data})


class GradoAsignaturaDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        relacion = get_object_or_404(GradoAsignatura, pk=pk)
        relacion.delete()
        return redirect('horarios:admin_grado_asignaturas')


class AsignaturaProfesorListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    model = AsignaturaProfesor
    template_name = 'horarios/asignatura_profesor_lista.html'
    context_object_name = 'relaciones'

    def get_queryset(self):
        return AsignaturaProfesor.objects.select_related('dni', 'asignatura', 'grado')


class AsignaturaProfesorCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'admin'
    model = AsignaturaProfesor
    form_class = AsignaturaProfesorForm
    template_name = 'horarios/asignatura_profesor_formulario.html'
    success_url = reverse_lazy('horarios:admin_asignatura_profesores')


class AsignaturaProfesorUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'admin'
    model = AsignaturaProfesor
    form_class = AsignaturaProfesorForm
    template_name = 'horarios/asignatura_profesor_formulario.html'
    success_url = reverse_lazy('horarios:admin_asignatura_profesores')


class GradosDisponiblesPorAsignaturaView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def get(self, request, asignatura_id):
        relacion_actual_id = request.GET.get('actual_relacion')

        grados_ids = list(GradoAsignatura.objects.filter(asignatura_id=asignatura_id).values_list('grado_id', flat=True).distinct())
        total_grados = len(grados_ids)

        if total_grados <= 1:
            return JsonResponse({'requiere_grado': False, 'grados': []})

        relaciones = AsignaturaProfesor.objects.filter(asignatura_id=asignatura_id)
        if relacion_actual_id:
            relaciones = relaciones.exclude(pk=relacion_actual_id)

        grados_asignados = set(relaciones.exclude(grado__isnull=True).values_list('grado_id', flat=True))
        disponibles_ids = [grado_id for grado_id in grados_ids if grado_id not in grados_asignados]

        grado_actual = None
        if relacion_actual_id:
            try:
                grado_actual = AsignaturaProfesor.objects.values_list('grado_id', flat=True).get(pk=relacion_actual_id)
            except AsignaturaProfesor.DoesNotExist:
                grado_actual = None
            if grado_actual:
                disponibles_ids.append(grado_actual)

        grados = Grado.objects.filter(id__in=set(disponibles_ids)).order_by('nombre')
        data = [{'id': grado.id, 'nombre': grado.nombre} for grado in grados]
        return JsonResponse({'requiere_grado': True, 'grados': data})


class GradosCoincidentesPorAsignaturaView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def get(self, request, asignatura_id, grado_id):
        grados = Grado.objects.filter(
            id__in=GradoAsignatura.objects.filter(asignatura_id=asignatura_id).exclude(grado_id=grado_id).values_list('grado_id', flat=True)
        ).order_by('nombre')
        data = [{'id': grado.id, 'nombre': grado.nombre} for grado in grados]
        return JsonResponse({'grados': data})


class AsignaturaProfesorDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk):
        relacion = get_object_or_404(AsignaturaProfesor, pk=pk)
        relacion.delete()
        return redirect('horarios:admin_asignatura_profesores')


class AlumnoHorarioListView(RolRequiredMixin, ListView):
    rol_requerido = 'alumno'
    model = HorarioClase
    template_name = 'horarios/alumno_horarios.html'
    context_object_name = 'horarios'

    def get_queryset(self):
        return HorarioClase.objects.filter(activo=True).select_related('grado', 'asignatura', 'profesor')


class ProfesorHorarioListView(RolRequiredMixin, ListView):
    rol_requerido = 'profesor'
    model = HorarioClase
    template_name = 'horarios/profesor_horarios.html'
    context_object_name = 'horarios'

    def get_queryset(self):
        perfil = self.request.user.perfilusuario
        if perfil.profesor:
            return HorarioClase.objects.filter(profesor=perfil.profesor, activo=True).select_related('grado', 'asignatura', 'profesor')
        return HorarioClase.objects.none()


class SolicitudProfesorCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'profesor'
    form_class = SolicitudCambioProfesorForm
    template_name = 'horarios/solicitud_formulario.html'
    success_url = reverse_lazy('horarios:profesor_horarios')

    def dispatch(self, request, *args, **kwargs):
        self.horario = get_object_or_404(HorarioClase, pk=kwargs['horario_id'])
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        perfil = self.request.user.perfilusuario
        if not perfil.profesor:
            form.add_error(None, 'Tu usuario no está vinculado a un profesor.')
            return self.form_invalid(form)
        solicitud = form.save(commit=False)
        solicitud.profesor = perfil.profesor
        solicitud.horario = self.horario
        solicitud.save()
        self.object = solicitud
        return redirect(self.success_url)


class SolicitudAdminListView(RolRequiredMixin, ListView):
    rol_requerido = 'admin'
    template_name = 'horarios/solicitudes_admin.html'
    context_object_name = 'profesores'
    paginate_by = 6

    def get_queryset(self):
        queryset = Profesor.objects.all().order_by('nombre')
        search_query = self.request.GET.get('q', '').strip()
        if search_query:
            queryset = queryset.filter(Q(nombre__icontains=search_query) | Q(dni__icontains=search_query))
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profesores = list(context['profesores'])
        ultimo_login_admin = self.request.user.last_login
        profesor_id = self.request.GET.get('profesor')
        context['search_query'] = self.request.GET.get('q', '').strip()
        filtered_queryset = self.get_queryset()

        profesores_info = []
        for profesor in profesores:
            ausencias_profesor = AusenciaProfesor.objects.filter(profesor=profesor)
            pendientes = ausencias_profesor.filter(estado=AusenciaProfesor.EstadoAusencia.PENDIENTE)
            nuevas_pendientes = pendientes
            if ultimo_login_admin:
                nuevas_pendientes = pendientes.filter(creada_en__gt=ultimo_login_admin)
            profesores_info.append({
                'profesor': profesor,
                'pendientes': pendientes.count(),
                'nuevas_pendientes': nuevas_pendientes.count(),
            })

        profesor_seleccionado = None
        if profesor_id:
            profesor_seleccionado = filtered_queryset.filter(pk=profesor_id).first()
        elif profesores:
            profesor_seleccionado = profesores[0]

        context['profesor_seleccionado'] = profesor_seleccionado
        context['profesores_info'] = profesores_info
        context['ultimo_login_admin'] = ultimo_login_admin

        if profesor_seleccionado:
            ausencias = list(
                AusenciaProfesor.objects.filter(profesor=profesor_seleccionado).order_by('estado', 'dia_de_la_semana', 'turno', 'hora_inicio')
            )
            for ausencia in ausencias:
                if ultimo_login_admin and ausencia.creada_en:
                    ausencia.es_nueva_desde_ultimo_login = (
                        ausencia.creada_en > ultimo_login_admin
                        and ausencia.estado == AusenciaProfesor.EstadoAusencia.PENDIENTE
                    )
                else:
                    ausencia.es_nueva_desde_ultimo_login = ausencia.estado == AusenciaProfesor.EstadoAusencia.PENDIENTE
            context['ausencias'] = ausencias
        else:
            context['ausencias'] = []

        page_obj = context.get('page_obj')
        if page_obj is not None:
            total_pages = page_obj.paginator.num_pages
            current_page = page_obj.number
            block_size = 10
            block_start = ((current_page - 1) // block_size) * block_size + 1
            block_end = min(block_start + block_size - 1, total_pages)

            context['page_block_range'] = range(block_start, block_end + 1)
            context['previous_block_page'] = block_start - 1 if block_start > 1 else None
            context['next_block_page'] = block_end + 1 if block_end < total_pages else None

        context['total_profesores_filtrados'] = filtered_queryset.count()
        pendientes_qs = AusenciaProfesor.objects.filter(
            profesor__in=filtered_queryset,
            estado=AusenciaProfesor.EstadoAusencia.PENDIENTE,
        )
        context['total_pendientes_filtradas'] = pendientes_qs.count()

        pendientes_por_profesor = {
            profesor_id_val: total
            for profesor_id_val, total in pendientes_qs.values_list('profesor_id').annotate(total=Count('id'))
        }
        profesores_con_pendientes = []
        for profesor in filtered_queryset:
            total = pendientes_por_profesor.get(profesor.id, 0)
            if total:
                profesores_con_pendientes.append({'profesor': profesor, 'pendientes': total})

        profesores_con_pendientes.sort(key=lambda item: (-item['pendientes'], item['profesor'].nombre.lower()))
        context['profesores_con_pendientes'] = profesores_con_pendientes

        try:
            pendiente_idx = int(self.request.GET.get('pendiente_idx', '0'))
        except ValueError:
            pendiente_idx = 0

        total_pendientes_profesores = len(profesores_con_pendientes)
        if total_pendientes_profesores > 0:
            pendiente_idx = max(0, min(pendiente_idx, total_pendientes_profesores - 1))
            context['pendiente_actual'] = profesores_con_pendientes[pendiente_idx]
        else:
            pendiente_idx = 0
            context['pendiente_actual'] = None

        context['pendiente_idx'] = pendiente_idx
        context['total_profesores_con_pendientes'] = total_pendientes_profesores
        return context


class AusenciaProfesorCambiarEstadoView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, pk, estado):
        ausencia = get_object_or_404(AusenciaProfesor, pk=pk)
        if estado in AusenciaProfesor.EstadoAusencia.values:
            ausencia.estado = estado
            ausencia.save(update_fields=['estado'])
        return redirect(f"{reverse_lazy('horarios:admin_solicitudes')}?profesor={ausencia.profesor_id}")


class SolicitudCambiarEstadoView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, solicitud_id, estado):
        solicitud = get_object_or_404(SolicitudCambioProfesor, pk=solicitud_id)
        if estado in ['APROBADA', 'RECHAZADA']:
            solicitud.estado = estado
            solicitud.save(update_fields=['estado'])
        return redirect('horarios:admin_solicitudes')


class SolicitudDeleteView(RolRequiredMixin, View):
    rol_requerido = 'admin'

    def post(self, request, solicitud_id):
        solicitud = get_object_or_404(SolicitudCambioProfesor, pk=solicitud_id)
        solicitud.delete()
        return redirect('horarios:admin_solicitudes')


class AusenciaProfesorListView(RolRequiredMixin, ListView):
    rol_requerido = 'profesor'
    model = AusenciaProfesor
    template_name = 'horarios/ausencia_profesor_lista.html'
    context_object_name = 'ausencias'
    paginate_by = 20

    def get_queryset(self):
        perfil = self.request.user.perfilusuario
        if perfil.profesor:
            return AusenciaProfesor.objects.filter(profesor=perfil.profesor).order_by('estado', 'dia_de_la_semana', 'turno', 'hora_inicio')
        return AusenciaProfesor.objects.none()


class AusenciaProfesorCreateView(RolRequiredMixin, CreateView):
    rol_requerido = 'profesor'
    model = AusenciaProfesor
    form_class = AusenciaProfesorForm
    template_name = 'horarios/ausencia_profesor_formulario.html'
    success_url = reverse_lazy('horarios:profesor_ausencias')

    def form_valid(self, form):
        perfil = self.request.user.perfilusuario
        if not perfil.profesor:
            form.add_error(None, 'Tu usuario no está vinculado a un profesor.')
            return self.form_invalid(form)
        ausencia = form.save(commit=False)
        ausencia.profesor = perfil.profesor
        ausencia.save()
        return redirect(self.success_url)


class AusenciaProfesorUpdateView(RolRequiredMixin, UpdateView):
    rol_requerido = 'profesor'
    model = AusenciaProfesor
    form_class = AusenciaProfesorForm
    template_name = 'horarios/ausencia_profesor_formulario.html'
    success_url = reverse_lazy('horarios:profesor_ausencias')

    def get_queryset(self):
        perfil = self.request.user.perfilusuario
        if perfil.profesor:
            return AusenciaProfesor.objects.filter(profesor=perfil.profesor)
        return AusenciaProfesor.objects.none()


class AusenciaProfesorDeleteView(RolRequiredMixin, View):
    rol_requerido = 'profesor'

    def post(self, request, pk):
        perfil = request.user.perfilusuario
        if not perfil.profesor:
            return redirect('horarios:profesor_ausencias')
        ausencia = get_object_or_404(AusenciaProfesor, pk=pk, profesor=perfil.profesor)
        ausencia.delete()
        return redirect('horarios:profesor_ausencias')
