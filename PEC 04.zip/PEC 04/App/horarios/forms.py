from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import Asignatura, AsignaturaProfesor, AusenciaProfesor, Grado, GradoAsignatura, Profesor, SolicitudCambioProfesor, TipoUsuario


class RegistroUsuarioForm(UserCreationForm):
    tipo_usuario = forms.ModelChoiceField(queryset=TipoUsuario.objects.all())
    profesor = forms.ModelChoiceField(queryset=Profesor.objects.all(), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for nombre_tipo in ['admin', 'profesor']:
            TipoUsuario.objects.get_or_create(nombre=nombre_tipo)
        self.fields['tipo_usuario'].queryset = TipoUsuario.objects.filter(nombre__in=['admin', 'profesor']).order_by('nombre')
        self.fields['profesor'].queryset = Profesor.objects.all().order_by('nombre')

    class Meta:
        model = User
        fields = ('username', 'password1', 'password2', 'tipo_usuario', 'profesor')

    def clean(self):
        cleaned_data = super().clean()
        tipo_usuario = cleaned_data.get('tipo_usuario')
        profesor = cleaned_data.get('profesor')

        if tipo_usuario and tipo_usuario.nombre.lower() == 'profesor' and not profesor:
            self.add_error('profesor', 'Debes vincular un profesor para este tipo de usuario.')

        return cleaned_data


class SolicitudCambioProfesorForm(forms.ModelForm):
    class Meta:
        model = SolicitudCambioProfesor
        fields = ['mensaje']
        widgets = {
            'mensaje': forms.Textarea(attrs={'rows': 4}),
        }


class GenerarHorarioForm(forms.Form):
    grado = forms.ModelChoiceField(queryset=Grado.objects.all())
    anio = forms.ChoiceField(choices=[(i, str(i)) for i in range(1, 6)])
    cuatrimestre = forms.ChoiceField(choices=GradoAsignatura.Cuatrimestres.choices)
    turno = forms.ChoiceField(choices=[('MANANA', 'Mañana'), ('TARDE', 'Tarde')], widget=forms.RadioSelect)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['grado'].label = 'Grado'
        self.fields['anio'].label = 'Año'
        self.fields['cuatrimestre'].label = 'Cuatrimestre'
        self.fields['turno'].label = 'Turno'


class AsignaturaForm(forms.ModelForm):
    tipo_asignatura = forms.ChoiceField(choices=[('B', 'B'), ('OB', 'OB'), ('OP', 'OP'), ('TFG', 'TFG')])

    class Meta:
        model = Asignatura
        fields = ['nombre', 'tipo_asignatura']


class ProfesorForm(forms.ModelForm):
    contrato_indefinido = forms.BooleanField(required=False)
    contrato_hasta = forms.DateField(
        input_formats=['%d/%m/%Y'],
        widget=forms.DateInput(format='%d/%m/%Y', attrs={'placeholder': 'dd/mm/aaaa'}),
        required=False,
    )

    class Meta:
        model = Profesor
        fields = ['nombre', 'contrato_indefinido', 'contrato_hasta']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['contrato_indefinido'].label = 'Indefinido'
        self.fields['contrato_hasta'].help_text = 'Formato: dd/mm/aaaa. Déjalo vacío si es indefinido.'

    def clean(self):
        cleaned_data = super().clean()
        contrato_indefinido = cleaned_data.get('contrato_indefinido')
        contrato_hasta = cleaned_data.get('contrato_hasta')

        if contrato_indefinido:
            cleaned_data['contrato_hasta'] = None
        elif not contrato_hasta:
            self.add_error('contrato_hasta', 'Debes indicar una fecha en formato dd/mm/aaaa o marcar indefinido.')

        return cleaned_data

    def save(self, commit=True):
        profesor = super().save(commit=False)
        profesor.contrato_indefinido = self.cleaned_data.get('contrato_indefinido', False)
        profesor.contrato_hasta = self.cleaned_data.get('contrato_hasta')
        if commit:
            profesor.save()
        return profesor


class GradoAsignaturaForm(forms.ModelForm):
    anio = forms.ChoiceField(choices=[(i, str(i)) for i in range(1, 6)])
    cuatrimestre = forms.ChoiceField(choices=[('1', '1º'), ('2', '2º')])

    class Meta:
        model = GradoAsignatura
        fields = ['grado', 'asignatura', 'anio', 'cuatrimestre', 'especialidad']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['asignatura'].queryset = Asignatura.objects.none()
        self.fields['especialidad'].required = False

        grado_id = self.data.get('grado')
        if grado_id:
            usadas = GradoAsignatura.objects.filter(grado_id=grado_id).values_list('asignatura_id', flat=True)
            queryset = Asignatura.objects.exclude(id__in=usadas)
            if self.instance and self.instance.pk and str(self.instance.grado_id) == str(grado_id):
                queryset = Asignatura.objects.filter(id=self.instance.asignatura_id) | queryset
            self.fields['asignatura'].queryset = queryset.distinct().order_by('nombre')
        elif self.instance and self.instance.pk:
            self.fields['asignatura'].queryset = Asignatura.objects.filter(id=self.instance.asignatura_id)

    def clean(self):
        cleaned_data = super().clean()
        grado = cleaned_data.get('grado')
        asignatura = cleaned_data.get('asignatura')
        if not grado or not asignatura:
            return cleaned_data

        existe = GradoAsignatura.objects.filter(grado=grado, asignatura=asignatura)
        if self.instance and self.instance.pk:
            existe = existe.exclude(pk=self.instance.pk)

        if existe.exists():
            self.add_error('asignatura', 'Esa asignatura ya está asociada al grado seleccionado.')

        es_op = asignatura.tipo_asignatura == Asignatura.TiposAsignatura.OPTATIVA
        es_grado_informatica = grado.nombre.strip().lower() == 'ingeniería informática'
        especialidad = cleaned_data.get('especialidad')

        if es_op and es_grado_informatica and not especialidad:
            self.add_error('especialidad', 'Debes elegir especialidad para asignaturas OP en Ingeniería Informática.')

        if not (es_op and es_grado_informatica):
            cleaned_data['especialidad'] = None

        return cleaned_data


class AsignaturaProfesorForm(forms.ModelForm):
    class Meta:
        model = AsignaturaProfesor
        fields = ['dni', 'asignatura', 'grado', 'coincide_con_grado_relacionado', 'grado_coincidente']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['dni'].label = 'Nombre'
        self.fields['dni'].queryset = Profesor.objects.all().order_by('nombre')
        self.fields['grado'].required = False
        self.fields['grado'].queryset = Grado.objects.none()
        self.fields['coincide_con_grado_relacionado'].required = False
        self.fields['coincide_con_grado_relacionado'].label = 'Coincide con uno de los grados relacionados'
        self.fields['grado_coincidente'].required = False
        self.fields['grado_coincidente'].queryset = Grado.objects.none()

        asignaturas_disponibles_ids = []
        for asignatura in Asignatura.objects.all().order_by('nombre'):
            grados_ids = list(GradoAsignatura.objects.filter(asignatura=asignatura).values_list('grado_id', flat=True).distinct())
            total_grados = len(grados_ids)
            relaciones = AsignaturaProfesor.objects.filter(asignatura=asignatura)

            if self.instance and self.instance.pk:
                relaciones = relaciones.exclude(pk=self.instance.pk)

            if total_grados > 1:
                grados_asignados = set(relaciones.exclude(grado__isnull=True).values_list('grado_id', flat=True))
                hay_grado_libre = any(grado_id not in grados_asignados for grado_id in grados_ids)
                if hay_grado_libre:
                    asignaturas_disponibles_ids.append(asignatura.id)
            else:
                sin_profesor_asignado = not relaciones.exists()
                if sin_profesor_asignado:
                    asignaturas_disponibles_ids.append(asignatura.id)

        queryset = Asignatura.objects.filter(id__in=asignaturas_disponibles_ids).order_by('nombre')

        if self.instance and self.instance.pk:
            queryset = (Asignatura.objects.filter(pk=self.instance.asignatura_id) | queryset).distinct().order_by('nombre')

        self.fields['asignatura'].queryset = queryset

        # Muestra los grados asociados junto al nombre de asignatura para dar contexto al admin.
        grados_por_asignatura = {
            asignatura_id: ", ".join(sorted(set(nombres_grado)))
            for asignatura_id, nombres_grado in (
                (
                    asignatura_id,
                    list(
                        GradoAsignatura.objects.filter(asignatura_id=asignatura_id)
                        .select_related('grado')
                        .values_list('grado__nombre', flat=True)
                    ),
                )
                for asignatura_id in self.fields['asignatura'].queryset.values_list('id', flat=True)
            )
        }

        def asignatura_label(asignatura):
            grados = grados_por_asignatura.get(asignatura.id)
            if grados:
                return f"{asignatura.nombre} ({grados})"
            return asignatura.nombre

        self.fields['asignatura'].label_from_instance = asignatura_label

        asignatura_id = self.data.get('asignatura')
        if asignatura_id:
            grados_ids = list(GradoAsignatura.objects.filter(asignatura_id=asignatura_id).values_list('grado_id', flat=True).distinct())
            relaciones = AsignaturaProfesor.objects.filter(asignatura_id=asignatura_id)
            if self.instance and self.instance.pk:
                relaciones = relaciones.exclude(pk=self.instance.pk)

            if len(grados_ids) > 1:
                grados_asignados = set(relaciones.exclude(grado__isnull=True).values_list('grado_id', flat=True))
                disponibles_ids = [grado_id for grado_id in grados_ids if grado_id not in grados_asignados]
                if self.instance and self.instance.pk and self.instance.grado_id:
                    disponibles_ids.append(self.instance.grado_id)
                self.fields['grado'].queryset = Grado.objects.filter(id__in=set(disponibles_ids)).order_by('nombre')
            else:
                self.fields['grado'].queryset = Grado.objects.none()
        elif self.instance and self.instance.pk and self.instance.grado_id:
            self.fields['grado'].queryset = Grado.objects.filter(id=self.instance.grado_id)

        grado_id = self.data.get('grado') or (self.instance.grado_id if self.instance and self.instance.pk else None)
        asignatura_id = self.data.get('asignatura') or (self.instance.asignatura_id if self.instance and self.instance.pk else None)
        if grado_id and asignatura_id:
            queryset_coincidente = Grado.objects.filter(
                id__in=GradoAsignatura.objects.filter(asignatura_id=asignatura_id).exclude(grado_id=grado_id).values_list('grado_id', flat=True)
            ).order_by('nombre')
            self.fields['grado_coincidente'].queryset = queryset_coincidente
        elif self.instance and self.instance.pk and self.instance.grado_coincidente_id:
            self.fields['grado_coincidente'].queryset = Grado.objects.filter(id=self.instance.grado_coincidente_id)


class AusenciaProfesorForm(forms.ModelForm):
    turno = forms.ChoiceField(
        choices=AusenciaProfesor.Turnos.choices,
        widget=forms.RadioSelect,
        label='Tipo de ausencia',
    )
    hora_inicio = forms.TimeField(
        input_formats=['%H:%M'],
        widget=forms.TimeInput(format='%H:%M', attrs={'type': 'time'}),
        required=False,
        label='Hora de inicio',
    )
    hora_fin = forms.TimeField(
        input_formats=['%H:%M'],
        widget=forms.TimeInput(format='%H:%M', attrs={'type': 'time'}),
        required=False,
        label='Hora de fin',
    )

    class Meta:
        model = AusenciaProfesor
        fields = ['dia_de_la_semana', 'turno', 'hora_inicio', 'hora_fin']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['dia_de_la_semana'].label = 'Día de la semana'
        self.fields['dia_de_la_semana'].widget = forms.Select(choices=AusenciaProfesor.DiasSemana.choices)

    def clean(self):
        cleaned_data = super().clean()
        turno = cleaned_data.get('turno')
        hora_inicio = cleaned_data.get('hora_inicio')
        hora_fin = cleaned_data.get('hora_fin')

        if turno == AusenciaProfesor.Turnos.PERSONALIZADO:
            if not hora_inicio or not hora_fin:
                raise ValidationError('Para ausencia personalizada, debes indicar las horas de inicio y fin.')
            if hora_fin <= hora_inicio:
                raise ValidationError('La hora de fin debe ser posterior a la hora de inicio.')

        return cleaned_data

    def save(self, commit=True):
        ausencia = super().save(commit=False)
        turno = self.cleaned_data.get('turno')

        # Resetear horas si no es personalizado
        if turno == AusenciaProfesor.Turnos.MANANA:
            ausencia.hora_inicio = None
            ausencia.hora_fin = None
        elif turno == AusenciaProfesor.Turnos.TARDE:
            ausencia.hora_inicio = None
            ausencia.hora_fin = None

        if commit:
            ausencia.save()
        return ausencia
